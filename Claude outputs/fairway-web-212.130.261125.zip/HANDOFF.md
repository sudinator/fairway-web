## 212.108.261114 — approved Summary filters and analytics follow-ups

Use the owner-approved three descending horizontal lines beside the time-range controls; green without a course/tee filter and yellow after Apply. Popup criteria are course and dependent tee only. Remove the round-length selector while keeping raw nine-/eighteen-hole comparisons separate. Partner table and highlighted record now rank by qualified points rate, not accumulated points. Fairway/GIR peer verdicts require five rounds plus fifty recorded opportunities. Penalty averages/trends/coaching use explicitly confirmed complete cards; legacy/default zeros remain unknown. Round-detail confirmation is acknowledged, reversible and invalidated by later score/penalty edits.

Migration 0236 required. All earlier SQL migrations remain byte-identical. Includes all 212.102–107 work relative to the reported production 212.101 baseline; verify actual applied migration IDs before any production SQL. See ANALYTICS_212.108.md and RELEASE_VERIFICATION_212.108.md. Native staging/production gates remain required; no production approval or merge has occurred.

## 212.107.261114 — analytics quality and repeat use

212.106 GitHub CI is green per the owner. This candidate implements the approved analytics cleanup in the existing screens: missing-handicap net awards, complete putting samples, established-index trends, separate raw 9/18-hole comparisons, course/tee/length scope, prior-period Insights, tied personal bests, per-stat evidence and bounded peer proxies, scope-aware AI, consistent admin populations, mature activation/retention cohorts, cleanup-stable game lifecycle counts, observed feature/repeat/reminder outcomes and visible error/retry/freshness states. See ANALYTICS_212.107.md for definitions and preserved contracts.

Migration 0235 required; all earlier migration SQL remains unchanged. Full local release evidence is recorded in RELEASE_VERIFICATION_212.107.md. Native GitHub/Supabase CI, Vercel staging and the existing production data-profile review remain external release gates. This is not production approval.

## 212.106.261114 — scheduler permission-test correction

Staging test candidate. Native GitHub/Supabase CI and Vercel staging validation remain blocking release gates; this is not production approval.

The concurrency helper directly updated provider-owned cron.job to pause and restore the daily job. Supabase rejects both writes, producing the two errors in the reported CI failure. Replace both writes with cron.alter_job, restore the original enabled state independently of fixture-cleanup success, and verify restoration. Extend the existing recurrence guard to reject direct scheduler metadata writes, including multiline SQL.

Local evidence includes the full 232-migration chain and a restricted non-superuser reproduction: the old helper fails with the two reported errors; the corrected helper passes actual competing sessions with initially enabled and disabled jobs; an injected setup failure remains a failure and restores the scheduler. These checks supplement the native Supabase gate.

No additional migration. All existing SQL migrations, including 0234, and application behavior source remain byte-identical to 212.105. Generated version metadata advances to 212.106. Analytics is paused and no analytics changes are included. See RELEASE_VERIFICATION_212.106.md.

# 212.105 candidate — revoked-function test regression

Use the central server-only catalogue in ci/assert-no-app-call-to-revoked.sql. Never call these functions under anon/authenticated to test denial. ci/check_recurrence_guards.py now checks direct calls in app-role SQL sections. Migration 0234 is unchanged. See RELEASE_VERIFICATION_212.105.md for evidence and remaining external gates.

# 212.101 candidate — diagnostic summary, context and last update outcome

Login owns a vertical scroll context because globals.css locks body scrolling. Test natural wheel/touch access to both sign-in and the expanded support controls; locator auto-scroll alone is not sufficient. The signed-in Home scroll container is unchanged.

The existing updater already verifies the loaded version and shows transient success. Keep that eight-second banner expiry and retain the structured Last update attempt separately; a retained result must not become a new pending banner. bnn-update-result-v1 holds only bounded, validated status/target/running-version/phase/time in sessionStorage, up to seven days, with memory fallback. Restoration is not evidence that a new update occurred. Do not change score gates, worker activation or deployment authentication. Specific failure phase is observational; retries still execute the existing update path.

Diagnostics summary uses the same bounded read-only workerSnapshot as export. The optional userDescription (500 characters) is only included on manual export; never log or persist it. Automatic redaction guarantees apply to technical records; user-written context contains what the user chose to type. Summary refresh checks the deployed version without activating a worker. See RELEASE_VERIFICATION_212.101.md for contracts, validation and pending same-installation phone gates.

# 212.100 candidate — phone diagnostics

Shared local evidence lives in lib/phone-diagnostics.ts and is mounted by PhoneDiagnosticsRecorder in RootLayout. Export panel is available to every member via App version & updates, on sign-in, and in Admin Diagnostics. Exports are manual JSON/share/download, never a remote upload. Do not add raw bodies, auth headers, cookies, query strings, names, score values or raw legacy trace strings. Unknown metadata fields are dropped at write AND export; persisted history is filtered by current account. Storage failures retain memory evidence and never evict score data. Sign-out clears logs through lib/sign-out (signOutSafely → resetPhoneDiagnostics, after the sign-out succeeded), and direct account switches isolate old history. Budgets: 150 events / 48 KiB text per session, four sessions, seven days. Existing raw opt-in tools remain separate.

Save instrumentation must preserve baseline helpers in ci/fixtures/*-21299.ts.txt; npm run test:diagnostics executes baseline/current comparisons and recorder/browser contracts. HTTP outcomes are transport evidence, not automatic business-success claims. Realtime state is sampled read-only. The worker status query returns only its compiled version, with no activation/cache action. Best-effort worker failure notifications contain only fixed phase/status/error-class/version metadata and never change install/cache outcomes. Reports can expose page/worker-version differences while a worker is waiting; that difference alone is not a failed update.

Records cannot reconstruct the old 212.97 phone session. External GitHub/Vercel and same-installation iPhone tests remain required; see RELEASE_VERIFICATION_212.100.md. No production-ready claim before those gates pass.

# 212.99 candidate — redirect handling and release hold

Navigation redirects are forwarded to the browser, never substituted with cached Home. Followed redirects are not cached as the application shell. Explicit Update, offline fallback and score persistence are retained. Test redirects with ci/test-update-redirect-browser.cjs; default Chromium runs in mandatory CI and BNN_UPDATE_BROWSER=webkit runs the same suite in WebKit when installed (failure is never silently skipped). The login fixture is cross-origin and the callback is outside /auth/, so it cannot accidentally bypass the navigation handler under test.

Physical testing must use the owner's existing working 212.98 Home Screen installation; no replacement shortcut. The original 212.97 session incident is unresolved and must not be described as repaired by this candidate. No production readiness until the external gates in RELEASE_VERIFICATION_212.99.md pass. No migration or Vercel protection change.

<!-- 212.87: pending update banners have Update now only, no Later/Dismiss. Failed attempts retain retry feedback. Confirmed success expires after8seconds only when no newer release is pending. Supersedes dismissal guidance below. -->
# Current update policy — 212.87
The pending-update banner offers Update now only, with no Later/Dismiss control. Downloaded workers wait for that action to activate while app pages remain open. Failed attempts keep retry feedback visible. Confirmed success expires after8seconds only when no newer release is pending. Explicit action reloads; deployment/focus/controller changes never force an open page to restart. Unfinished rounds never gate updating. Confirm success from the version actually loaded; report failures/timeouts and keep all drafts/outboxes. This supersedes earlier no-banner guidance below.

<!-- 212.85.261102: refreshed member capabilities/Help and one-pagers; automatic updates remain quiet. See RELEASE_VERIFICATION_212.85.md. -->
<!-- 212.84.261101: automatic updates on fresh open/refresh; manual update deferral is superseded. See RELEASE_VERIFICATION_212.84.md. -->
<!-- 212.83.261101: correction warnings link to the exact game/round and show its club; see RELEASE_VERIFICATION_212.83.md. -->
<!-- 212.82.261101: saved-score verification and guarded recovery; see RELEASE_VERIFICATION_212.82.md. -->
<!-- 212.81.261101: recap stat corrections; see RELEASE_VERIFICATION_212.81.md. -->
<!-- 212.80.261101: update feedback/dismissal candidate; see RELEASE_VERIFICATION_212.80.md. -->
<!-- 212.79.261101 candidate: updates are deferred during scoring. See RELEASE_VERIFICATION_212.79.md; full source ZIP delivery. -->
# Birdie Num Num (BNN) — Developer Handoff

**Read this first.** It's the onboarding brief for continuing BNN development in a fresh chat with no
prior context. The uploaded `.zip` is the complete source at the current version. When in doubt about
how anything works, **open the file and read it** — never answer from assumption.

---

## Current candidate: 212.81.261101 — staging/GitHub verification pending

212.77 is deployed per user confirmation. The new 212.78 candidate fixes missing/manual-handicap differential comparisons; no database migration. See RELEASE_VERIFICATION_212.78.md for executed local checks and outstanding game-specific/GitHub/staging verification. No production deployment of 212.78 has been performed.

- RULE: every new column that refers to an account goes into account_reference_columns (ci/assert-account-merge.sql fails otherwise).
- RULE: guards are judged by the account/data affected, never by current_user (definer functions run as owner) and never by a session flag.
- RULE: account changes are server functions that refuse out loud; no browser-side multi-step deletes.
- STAGING: deliberately sends no push notifications — no notifications webhook in staging's Supabase (owner, Oct 2026). Not a fault; don't "fix" it.
- RULE (owner, Oct 21 2026 — no compromise): THE SECURITY CONTRACT (ci/check_security_contract.py) runs on every release against the fully migrated database: RLS on every table; every policy, table grant and privileged-function EXECUTE matches ci/security_contract.json; every SECURITY DEFINER pins search_path; every member-writable table has guard_active_account (exceptions: profiles, notifications). A permission change is recorded deliberately with --update and reviewed in the release diff.
- RULE: from 0205, a migration touching security (privileged functions, grants, policies, RLS, triggers) carries `-- TESTS: ci/assert-….sql`, and that test runs in both chain checks.
- RULE: ci/assert-club-isolation.sql proves cross-club isolation on every release; a new club-scoped table is added to it, with its positive control.
- RULE: badges and player cards are computed by the SERVER (lib/member-stats-server, /api/member-stats) — never written by the phone (ci/check_server_only_stats.py). A calculated result that others rely on is the server's to compute.
- LEARNING (211.5): before removing a write permission, search for writes across line breaks (a `.from("x")` on one line, `.upsert(` on the next).
- RULE (211.7): a new format ships with a rendered test of the WHOLE setup flow — control center → each step as an organizer clicks it — not only its editors in isolation.
- RULE (212.0): every editable field spreads inputStyle (ci/check_field_style.py ratchet; DISPLAY_RULES.md §2).
- RULE (212.16, owner — "basic design choices you should be proactively looking to implement"): every new or changed screen gets an entry in lib/design-gallery.tsx and is PHOTOGRAPHED at phone width (npm run gallery) and reviewed as a member would see it BEFORE it ships — is the important number obvious, do names fit, is anything squeezed or wasted, does it scroll further than it needs to, is any text repeated or in the wrong place. Tests check what a screen shows; only looking checks whether it reads well. Layout changes ship with before/after screenshots.
- RULE (212.8): the security contract runs on PRODUCTION nightly and on every pull request (security_contract_state, 0214) — a production migration must be applied before its pull request's checks. Storage rules and bucket settings are in the contract.
- RULE (212.8): a server-key route has a recognised gate and passes the signed-in user as any actor (ci/check_server_routes.py).
- RULE: a notification link must be one lib/app-links.ts understands (?tab=<APP_TABS>, club=, game=, tt=, wrapped=) — ci/assert-notification-links.sql checks every link the database sends.
- RULE: statistics code decides what a round is ONLY through lib/round-rules (ci/check_round_rules.py).
- RULE: every statistics feature runs through lib/test-fixtures/messy-games (lib/messy-data.test.ts) — add a case when real data surprises us.
- RULE: before a statistics feature ships, the owner runs docs/sql/data_profile.sql on production and we review it together.
- RULE: every list read goes through lib/fetch-all (fetchAll / fetchAllIn / rpcAll) or carries `// bounded: <why>` — Supabase caps a request at 1,000 rows (ci/check_paged_reads.py).
- RULE: a new directly-writable table gets the guard_active_account trigger (0197) — pending / suspended accounts must not write directly.
- RULE: never test a refusal by CALLING a function an app role lacks EXECUTE on — it crashes Supabase PG 17.6 ≤ 17.6.1.111 (supautils). Check has_function_privilege instead.

## Previous: 207.3.261015

- 207.3 = 207.2 renumbered (an older 207.2 build was on staging). No code change.

## Previous: 207.2.261013

- RULE: game results (standings, recap, announcement) come ONLY from lib/game-results + lib/game-recap + lib/player-scoring. No result logic in SQL or in view components.
- 207.0–207.2 ship together (owner, Oct 13): migrations 0186, 0187, 0188.

## Previous: 207.1.261013

- Admin course row wording lives ONLY in lib/course-status.ts. Next: 207.2 completion recap.

## Previous: 207.0.261013

- Course history: ALL shared-course content changes are versioned by trigger (0186). A function that knows why a change happens sets bnn.course_change (source/reason/ref) immediately before its update; the trigger consumes it.
- Next: 207.1 Admin → Courses status redesign (uses course_versions for 'last update applied'), then 207.2 completion recap.

## Previous: 206.2.261013

- LESSON (second-pass review): a fix to one path is not done until every path with the same shape is found — grep for the pattern, not the instance (two recorders, two team writers, six ledger queries).

## Previous: 206.1.261013

- RULES: a query error is never "no rows" (money: all-or-nothing, last good data kept); multi-row game setup writes go through apply_game_structure (one transaction); autosaves use lib/latest-saver; the push sender distinguishes lookup / permanent / retryable and retries only undelivered devices.
- External review of Oct 13: all 10 findings addressed (205.4, 206.0, 206.1).

## Previous: 206.0.261013

- RULE: provider (GolfCourseAPI) data is fetched, validated and compared on the SERVER only; the browser names a course, never supplies its content. Approvals name the reviewed revision.
- Known stale: ci/test-notifications-isolated.sh (manual, not in CI) applies only 0165 and has failed on game-added wording since 0174; the full-chain assert-notifications.sql is authoritative.
- Review remaining: 4, 9 → 206.1; 5, 10 → 206.2.

## Previous: 205.4.261013

- RULE: a Supabase request is lazy — never `void client.rpc()/from()`; await it and handle the error.
- External review (Oct 13), 10 findings: 7, 8 fixed here; 1, 2, 3, 6 → 206.0; 4, 9 → 206.1; 5, 10 → 206.2.

## Previous: 205.3.261013

- SECURITY RULE: no schema change on production outside a migration — one-off fixes included. A temporary table is created AND dropped in the same migration. The live parity check (every merge) and the nightly production-security workflow fail on any public table with RLS off or not in ci/public_tables.json. Adding a table = a migration + the list entry (the full chain enforces the list).

## Previous: 205.2.261013

- 0181: per-club round counts by rounds.group_id; per-account seen years; wording. Apply 0181 (after 0180) before the code.

## Previous: 205.1.261013

- Season charts: month ticks. Carries 205.0 (apply 0180 first if not yet applied).

## Previous: 205.0.261013

- Season Wrapped. RULE: any stat surface prepares rounds with lib/round-prep (stroke allocation) and applies the Dashboard's exclusions — never a parallel definition. Apply 0180 before the code. Public season link is backlog.

## Previous: 204.3.261013

- Outlook line hidden when nothing is still out.

## Previous: 204.2.261013

- 0179 finish_game clock fix (BN163). Staging-only auto-score gated on html[data-env] (guard F). Apply 0179 before the code.

## Previous: 204.1.261012

- lib/grouping.balancedTeamMatchups (like v like) beside balancedTeamGroups (even groups). Trifecta swap set so singles are strong v strong.

## Previous: 204.0.261012

- Standings convention: big = decided, line = if ended now, clinch line = still out (all team formats). Singles table for all singles. Embedded group Results card under the scorecard (FourballView onlyFoursomeId/embedded).

## Previous: 203.4.261012

- Balance: equal counts enforced before handicap balance; swap pass. Property-tested over random fields.

## Previous: 203.3.261011

- Ryder Cup roster: In tick per player; balance deals only players who are in.

## Previous: 203.2.261011

- Team names save as you type (no Save button); errors shown inline.
- RETIRED CONVENTIONS: per-release `RELEASE_VERIFICATION_<v>.md` sheets (177.13–193.2) and `WORKFLOW_SIMULATION_REPORT_<v>.md` (49 files) are no longer written. The executed proof for a release lives in its DEPLOY_NOTES entry (chain/assertion/harness counts, preflight timings) and permanently in the guards and assertion files. The 152 historical files moved to `docs/history/`; nothing executable referenced them.

## Previous: 203.1.261011

- Balance blocked on missing handicaps; Ryder Cup roster balance by index at creation. Balanced session MATCHUPS is a separate backlog item.

## Previous: 203.0.261010

- Balance teams by handicap (lib/balance-teams.ts; Teams tab). Basis = playing handicap via the engine.

## Previous: 202.6.261009

- Team band tint 0.70 cream (Amit's choice, Oct 9).

## Previous: 202.5.261009

- RULE: a text-styled <button> needs appearance:none or iOS boxes it.

## Previous: 202.4.261009

- Team colour on line-up rows = tint band (lib/team-tint.ts). Chosen by Amit from rendered options A–D on Oct 9.

## Previous: 202.3.261009

- Line-up arithmetic toggle is a button. RULE: a 'tap for…' affordance IS the tap target, never text beside one.

## Previous: 202.2.261009

- lib/short-names.ts is the one name-shortening rule; guarded (E). Readable-word slugs were considered on Oct 8 and DECLINED (single words are guessable); keep the six-character code.

## Previous: 202.1.261008

- 0178 readable live/competition links; next 16.3.8, js-yaml 4.3.2, sharp 0.35.5. Apply 0178 before the code. Dependabot security PRs: never merge the bot's commit; take the bumps through a drop.

## Previous: 202.0.261008

- 0177 readable line-up slug. Apply 0177 before the code. Follow-up: parity job should open an issue when red (missed twice this week).

## Previous: 201.8.261008

- 0176: line-up link shows games.played_at (a DATE — never apply `at time zone` to it). Apply 0176 before the code.

## Previous: 201.7.261008

- Picker lists only populated groups. Allowance basis SETTLED: WHS 2024 Rule 6.2a applies the allowance to the UNROUNDED course handicap and rounds once (.5 up) — exactly what the engine does. Do not reopen.

## Previous: 201.6.261008

- Line-up arithmetic uses chBasis's unrounded CH; groups in game order. OPEN QUESTION for Amit: should CH be rounded before the allowance (WHS 6.2a)? Engine currently applies allowance to the unrounded figure.

## Previous: 201.5.261008

- RULE: public share routes (/live/, /lineup/, any future one) are bypassed by the service worker and carry server-side metadata (a layout.tsx with generateMetadata). Guarded in ci/check_public_routes_scroll.py. A public page shows APP_VERSION in its footer.

## Previous: 201.4.261008

- RULE: every incident that could recur becomes an executable guard (npm run guards or the full chain), negative-tested, in the release that fixes it. Prose in notes/APP_RULES explains; it never enforces. See ci/check_recurrence_guards.py and ci/assert-no-rpc-overloads.sql for the current set.

## Previous: 201.3.261007 (HOTFIX)

- RULE: any page outside .app-shell (public share routes) owns its scroll container (`className="live-scroll"`); html/body are locked. Guarded by ci/check_public_routes_scroll.py. Second occurrence (184.1, 201.2) — read globals.css before adding a route.

## Previous: 201.2.261007

- 0175 organizer gets game_added. RULE for SQL assertions: compare with `is distinct from` / `is null or not like`; a NULL never raises.

## Previous: 201.1.261007

- Game deep link `/?game=<code>` (home.tsx); line-up page button per platform; 0174 notification link. Apply 0173 and 0174 before the code.

## Previous: 201.0.261007

- 0173 live line-up link + per-group card; lib/lineup.ts is the one source for line-up numbers. Apply 0173 before the code.

## Superseded (never shipped): 200.0.261007

- Line-up card rebuilt on lib/lineup.ts (engine arithmetic). Client only.

## Previous: 199.5.261006 (199.4 confirmed on device)

- Diag's navBottom_vs_visible now uses the shell's reference height. Rule recorded in APP_RULES.md.

## Previous: 199.4.261005

- RULE: the installed app's shell height comes from the layout viewport (`innerHeight`), never `visualViewport.height`, which iOS leaves stale in Home Screen apps. `lib/viewport-height.ts` is the one decision; `check_shell_geometry.py` guards it. Any viewport change is verified with the on-device VIEWPORT DIAG readout (Admin → Diagnostics), never from a screenshot alone — and the readout from each incident is pasted into the release note.

## Previous: 199.3.261005

- Bottom nav hidden in portrait: the keyboard heuristic fired without a keyboard. Gate is now focused-editable AND viewport shrunk. Any future viewport heuristic must be gated on a signal iOS cannot move.

## Previous: 199.2.261005

- Server-side code never formats a wall-clock time for display: Vercel runs in UTC. Format on the device, or in SQL with `at time zone 'America/New_York'`.

## Previous: 199.1.261005

- 0172 push delivery log; `/api/push/test`; shared sender `lib/push-send.ts`. Apply 0172 before the code.

## Previous: 199.0.261005

- 0171 attempt log + Course data row actions (refresh, apply, dismiss, log). Apply 0171 before the code.

## Previous: 198.1.261005

- 0170: push endpoints classified failing vs dormant; nightly 60-day prune. Apply 0170 before the code.

## Previous: 198.0.261005

- 0169 + Admin → Course data screen (all courses, verification, pending updates, pending corrections). Apply 0169 before the code on each environment.

## Previous: 197.2.261003

- RULE: CI helper processes never choose fixed ports; bind 0 and pass the assigned port on. The runner shares the network namespace with the Supabase CLI stack, whose ports change with the CLI version — a collision the local replay cannot reproduce.

## Previous: 197.1.261003

- 0168: freshness functions key on group_courses links (favorite_courses.group_id is legacy and may be null). Apply 0168 before the code on each environment.

## Previous: 197.0.261002

- 0167: cross-club course review queue; reopen on new diff; apply via RPC (club admins included). Apply 0167 before the code on each environment.

## Previous: 196.3.261002

- Course view relative date counts local calendar days (was a 24h window). Client only.

## Previous: 196.2.261002

- RULE (second CI failure of this stretch, 196.1): the local full-chain replay must mirror CI's ENVIRONMENT as well as its database — it now runs from a scratch working directory like `test_fresh_db_rebuild.sh`. When a script is added to a CI job, run it the way that job runs it: same cwd, same installed state. "It passed locally" with a different cwd is not evidence.

## Previous: 196.1.261002

- The GolfCourseAPI monitor's set is the LIBRARY (favorite_courses with external_id), read per run; one request per course; budget 8/day. The golden JSON is harness stub data only.

## Previous: 196.0.261002

- 0166: device heartbeat (6h idle supersession), scheduled course freshness via the daily monitor (one shared body with the New Round path), bet-stale notice carries the per-member money movement. Full-chain local replay run before packaging; see DEPLOY_NOTES.

## Previous: 195.1.261001

- RULE, added after 195.0 failed CI on a modelled fixture: **before handing over any drop that adds a migration or a `ci/assert-*.sql` file, run `BNN_SCRATCH_DATABASE_URL=... bash ci/test_fresh_db_local.sh`** and quote its output. It replays all committed migrations on real PostgreSQL and runs the rebuild's assertion files in CI's order. An isolated fixture is a convenience for iterating, never evidence.

## Superseded: 195.0.261001

- Migration 0165: every notification rewritten with specifics (see DEPLOY_NOTES). `ci/assert-notifications.sql` asserts exact text; run `BNN_SCRATCH_DATABASE_URL=... bash ci/test-notifications-isolated.sh` for a 5-second local check, and it also runs inside the fresh-database rebuild.
- Courses shows a "Needs review" section for club admins (pending GolfCourseAPI changes); Admin shows sign-up dates. Apply 0165 before the code on each environment.

## Previous candidate: 194.0.261001

- Migration 0164 fixes the course-API ledger: a claim is no longer counted as a verification (freshness = `last_success_at`); stranded claims are released by the monitor; every exit path records an outcome with the real HTTP status; the course view shows "Last verified against GolfCourseAPI". Apply 0164 to production BEFORE merging — the new monitor calls functions that only exist after it.
- Same-device relaunch no longer prompts "make this device primary" (localStorage owner token presented online; duplicate tabs detected via BroadcastChannel). Server liveness is still a backlog item.
- Verified locally: migration applied twice to a real PostgreSQL 16, `ci/assert-course-api-checks.sql` green (and it now exercises the stranded-claim case it used to mask), harness modes ok/drift/midquota/quota/keyrejected/detail404/ledgerdown with expected exit codes, device test red-then-green.
- Run GitHub CI (fresh-database rebuild now also runs the harness) before staging.

## Previous staging candidate: 179.7.260902

- v179.7 corrects the manual Staging integration workflow so its build receives the same public VAPID-key input as normal CI.
- The previous v179.6 manual run stopped before `npm run test:staging`; it created no temporary integration users or records.
- Rerun the workflow on the `staging` branch with mutation confirmation `YES`. Production promotion remains blocked until it is green.

- v179.6 corrects the v179.5 incremental-package mismatch by including the three v179.4 runtime files required by the v179.5 UI: `lib/competition.ts`, `lib/competition.test.ts`, and `components/game/scoring-views.tsx`.
- The Vercel failure was a compile-time missing export (`competitionOutcome`), not a database or Node runtime defect.
- (historical) 179.7 verification sheet is in docs/history/; migration 0143 was the latest schema change at the time.

- The user-facing multi-session team feature is named **Ryder Cup**; internal `competitions` tables, RPCs, and types intentionally retain their established names.
- Games explains the distinction in place: a Game is one round/format/scorecard; a Ryder Cup combines several team sessions into one overall match score.
- A game launched from a Ryder Cup session passes `sideContestsEnabled: false` to both the game payload and player-row builders. This persists `leg_config.scheme = "none"` and `bets = false` for every participant. No `game_contests` rows are created by default.
- Standalone Game defaults are unchanged. No migration is added beyond 0143.
- (historical) 179.6 verification sheet is in docs/history/; product/legal approval for the third-party `Ryder Cup` name remains the owner's call.

---

## 0. ACTION REQUIRED AT THE NEXT PRODUCTION MERGE

**`migrations/0139_nine_hole_round_basis.sql` must be applied to PRODUCTION when the databases are
merged.** It redefines three functions (`post_game_rounds_internal`, `post_group_rounds`,
`set_game_played_date`) so a nine-hole game posts a round on a nine-hole basis: rating, par and
course handicap halved, **slope unchanged**.

Migrations deploy BEFORE the code that depends on them. Until this runs in production, a nine-hole
game posted there writes a wrong differential into the player's handicap record — 9 holes against
par 72 with an eighteen-hole handicap, which falls into the partial-round path and fills nine
phantom holes with net par.

Requested by Amit, 177.95. Delete this section once it is applied.

## 0. The one rule that overrides everything
**Verify every claim about app behavior from the actual code before stating it or acting on it.** Do not
describe what the app does from memory or inference. Open the file, read it, then respond. This is the
single most important habit — it has caught countless bugs.

### What "verify" means in practice
Before writing code that touches a component, read its ACTUAL signature and body. Before writing a
test fixture, read the field names off the type. Before claiming a check passes, read the exit code
from the process — not from a pipeline, and not from output piped to `head` or `tail`.

### Assumptions that reached the user, each avoidable by opening one file
| Assumed | Actually |
|---|---|
| `RoundsList` takes `course_name` | the field is `course` — the name rendered blank |
| a round row carries `gross` | gross is DERIVED from the holes; the row field is ignored |
| `SegmentBoard` renders an open board | it is a COLLAPSED accordion — names hidden until expanded |
| its segments are front/back nine | three blocks of six (1-6, 7-12, 13-18) |
| `ShotSynthesis` always renders | returns null twice over: no index, and no qualifying sample |
| `LeaderRow` takes plain fields | it takes CALLBACKS — playerNet, parThru, relToParStr |
| components with no `supabase.` calls are prop-only | several construct a client at MODULE scope |
| `100lvh` equals the visible viewport when installed | it is larger by exactly safe-area-inset-top |
| `cmd \| tail` shows me whether cmd passed | it reports TAIL's status — hid a suite that hung forever |

### The shape of the mistake
It is never "I could not have known". It is always "I did not look, because I was confident."
Confidence about a file you have not opened in this session is worth nothing.

### Standing checks
- `python3 ci/preflight.py` before packaging anything — runs the real pipeline, timed, and fails a
  step that is stuck rather than slow.
- `python3 ci/preflight.py --zip <drop> --base <baseline>` before handing a drop over, so what is
  verified is the artifact, not a working tree that happens to have a file the zip forgot.
- Quote the measured timings in the handover. "The gates passed" is not evidence.

## 1. What BNN is + your role
- **Birdie Num Num**: a golf-scoring Progressive Web App for a golf group — scorecards, games/tournaments,
  handicaps (WHS-style), betting/money settle-up, tee-time scheduling, badges, and admin analytics.
- **Owner: Amit Sud (non-technical).** You (Claude) are the **sole developer**. You write the code, ship
  it, and give Amit clear copy-paste steps. He can't debug — precision and clear instructions matter.
- Amit also uses these chats for sophisticated **investment research**; for factual/investment questions
  he wants **sourced** answers (SEC filings + management commentary prioritized). Separate from BNN, but
  it may come up in the same chat.

## 2. Stack + infrastructure
- **Next.js 16.3** (App Router) + React 19 + TypeScript.
- **Supabase** (Postgres + Auth + Row-Level Security). Project ref `epmbsmykyrnoiccwnoxq`. **FREE tier** —
  mind quotas.
- **Vercel** hosting. Repo: `sudinator/fairway-web`. Live: `birdienumnum.vercel.app`.

### GOLF_API_KEY lives in THREE places

The GolfCourseAPI key is needed by two independent systems and is unreadable from both once set.
This bit us: it was set in June, never written down, and could not be recovered — Vercel marks it
Sensitive (write-only) and GolfCourseAPI does not display an existing key.

| Where | Why | Notes |
|---|---|---|
| **Vercel** env var `GOLF_API_KEY` | the app's course search (`app/api/courses/route.ts`) | Sensitive, Production + Preview. Changing it requires a REDEPLOY |
| **GitHub** repository secret `GOLF_API_KEY` | the weekly contract monitor | repository secret is fine; the workflow declares `environment: production` for the ledger secrets and still reads repository secrets |
| **Password manager** | so it can be recovered | the step that was skipped |

Account is at golfcourseapi.com — free, sign-in is by emailed link, no password.

If it ever needs replacing: regenerate, save to the password manager FIRST, then Vercel, then
redeploy, then GitHub. Course search is the only thing affected and it fails with a clear message,
not silently. Verify with `https://birdienumnum.vercel.app/api/courses?q=francis+byrne`.
- **PWA** (installable; service worker at `public/sw.js`, version-stamped).
- Sister app "Fairway Card" (separate repo, `fairway-web-eosin.vercel.app`) is occasionally referenced —
  not this project.

## 2b. Environments

| | URL |
|---|---|
| **Production** | `https://birdienumnum.vercel.app` |
| **Staging** | `https://birdienumnum-git-staging-amit-sud-s-projects.vercel.app` |

Staging is the Vercel branch deployment of `staging`, not a separate project, and it carries a
STAGING ribbon in the corner. Both were previously undocumented here, which cost real time: a
screenshot showing a bug is ambiguous about which environment produced it, and a fix can be
verified against the wrong one.

The staging Supabase database is separate from production and is reached through
`BNN_STAGING_SUPABASE_URL`; migrations must be applied to each independently.

## 2c. GolfCourseAPI budget

The free tier allows **35 requests per DAY**, shared by the app and CI. The contract monitor claims
**ten courses a day** from `course_api_checks` (0156), oldest first, skipping anything verified in
the last seven days; a full pass takes about a week and then idles. A successful `/api/courses`
lookup records itself as a verification, so app traffic reduces the monitor's work.

The monitor reads the ledger with the EXISTING `BNN_PRODUCTION_SUPABASE_URL` and
`BNN_PRODUCTION_SUPABASE_SERVICE_ROLE_KEY` secrets rather than a duplicate pair. Those are
**environment** secrets, so the job declares `environment: production` — without that they resolve
to empty strings silently, which is exactly how a Dependabot pull request once looked like a code
failure. The ledger is production's because the app's verifications land there.

When debugging, use `/api/courses?raw=1` (admin only) — ONE request, the provider's response
untouched. Do not re-run the contract workflow repeatedly: each run spends ten of the day's budget.

## 3. Deploy flow (staging first)
1. Start from a clean `staging` branch synchronized from `main`.
2. Apply the reviewed candidate/overlay to `staging`; inspect the exact changed-file set before commit.
3. Push `staging`; GitHub CI/guards and the Vercel Preview deployment must pass.
4. Run required staging/browser validation where the staging data/environment can exercise the feature.
5. Open `staging -> main`; required PR checks must pass before merge.
6. Confirm Vercel Production is Ready, then run a small non-destructive Production smoke test.
7. Merge/sync the new `main` state back into `staging` before the next release.
8. Database migrations are pasted/run manually in the Supabase SQL editor as database owner/postgres, with staging first for destructive/integration validation.

Because Amit is non-technical: **always print migration SQL inline for copy-paste**, and give plain, numbered instructions.

## 4. Pre-ship pipeline — run EVERY release
The release is not deployable until every **BLOCKING** required gate is green. **ADVISORY** checks must execute and be documented, but advisory findings alone do not block deployment.

1. **Consistency / source-contract review:** inspect the actual changed code, inputs, outputs, side effects, dependencies, and reverse/re-entry paths.
2. **Type-check:** `npx tsc --noEmit` -> rc 0.
3. **Unit + differential tests:** `npm test` -> rc 0.
4. **Guards:** `npm run guards` -> rc 0. This includes migration/security, UI, refactor reachability/state/dependency, external-provider, PWA, and feature-specific contracts. Individual explicitly-advisory debt checks may report findings while returning rc 0; their findings must be documented.
5. **Build:** `npm run build` -> rc 0. `prebuild` verifies VAPID-key consistency when the environment key is present and stamps the app version.
6. **One-command local/CI gate:** `npm run ci` runs hook lint, typecheck, guards, tests, and build.
7. **Simulated testing:** run normal, edge, invalid-input, state-transition, retry/re-entry, failure/rollback, and adjacent-flow scenarios. Label evidence MODELLED, EXECUTED, or BROWSER-VALIDATED.
8. **Version/docs:** bump `FEATURE.EDIT.YYMMDD`; update DEPLOY_NOTES, release verification, workflow simulation report, APP_RULES/HANDOFF/MIGRATIONS/SCHEMA/BACKLOG as applicable.
9. **Migration ledger:** if migrations changed, run `python3 ci/gen-migrations-checklist.py` twice and require byte-identical second output. Every migration >=0113 self-records semantically.
10. **Packaging:** preserve repository line endings; exclude `.git`, `node_modules`, `.next`, `.testout`, generated reports and all `.env*` secrets. Leak-scan before handoff.
11. **Staging GitHub/Vercel gates:** CI and relevant Robustness jobs green; Vercel Preview Ready.
12. **PR -> Production:** required PR verification green, merge to main, Production Ready, non-destructive smoke test, then `main -> staging` resync.

If a required gate cannot run in the current environment, mark it **NOT EXECUTED/BLOCKED** and do not call the release deployable.

## 5. Global ground rules (authoritative list: `APP_RULES.md` in the zip)
Highlights — read `APP_RULES.md` for the numbered set + CI mapping:
- Flex children that can shrink need `minWidth:0` (prevents overflow blowing the layout).
- **Real glyphs** in JSX text (`·`, `›`, `—`, `…`, `×`, `▾`), never literal `\uXXXX`. (JS string literals may use `\u`.)
- **Popups:** every popup needs an always-reachable `×` and must NOT dismiss on scroll; scrollable-sheet
  backdrops must not close on tap.
- **Minimum font size 11px** anywhere.
- **Reuse check** before adding UI — look for an existing shared component first.
- **Print every migration's FULL SQL inline** in chat (Amit runs it manually).
- **Keep repo docs in sync** each bundle (see §6).
- Line endings: CRLF except `ci/` + `.github/` + `marketing/onepager-content.txt` = LF.
- Horizontally-scrollable boxes use the shared **`<HScroll>`** (`components/hscroll.tsx`) — hides the
  native scrollbar and shows a slim scroll-position bar BELOW the content (never over data).
- **Charts must fit their data to the space** (fit axis to data range; guard flat series).
- **Versioning:** `FEATURE.EDIT.YYMMDD` (ET date), e.g. `165.1.260714`. FEATURE = new feature, EDIT =
  refinement (resets on FEATURE bump), bump EDIT every ship. (≤ `1.165.0` used old `1.MINOR.PATCH`.)
- **Deliberate name-list order** (default alphabetical; ask if unclear before shipping).
- **Never blank a screen on a query error**; never delete data or present a blank/new screen unexpectedly.
- **Confirm the plan before BIG / DB / semantic changes**; build **HTML mockups before visual changes**.
- **Yardages** show per-hole, per each player's chosen tee, on ALL scorecards.

## 6. Docs to keep in sync every bundle
`DEPLOY_NOTES.md` (changelog — add an entry per release), `MIGRATIONS.md` (run-ledger — regenerate),
`SCHEMA.md`, `BACKLOG.md`, `README.md`, `APP_RULES.md`. (Also present: `BETTING_MONEY_PLAN.md`,
`MONEY_FEATURE_PLAN.md`, `SCHEDULING_PLAN.md` — feature plans.)

## 7. Orientation — where things live
- `components/tournaments.tsx` — games/tournaments; the big one (game room state/side effects, live scoring,
  betting, matchups, tee-groups, organizer controls). The post-create setup render boundary now lives in `components/game/setup/game-setup-workspace.tsx`.
- `components/round-setup.tsx` — new solo round entry (hole-by-hole + gross).
- `components/round-editor.tsx` — edit an existing round (scores + **editable play date**).
- `components/round-detail.tsx` — read-only round view + hole strip.
- `components/manage.tsx` — admin/manage (Power Users table, engagement charts, admin repair, drill-downs).
- `components/dashboard.tsx` — personal dashboard + trend charts.
- `components/ui.tsx` — shared primitives (`Avatar`, `ShortDateInput`, `NumPicker`, `ScoreEntryCard`, …).
- `components/hscroll.tsx` — horizontal scroller with the scroll-position bar.
- `lib/golf.ts` — core domain (handicaps, differentials, `fmtDate`, stats, the `C` colour palette).
- `lib/*` — money, legs, grouping, badges, card, sync — each with a `.test.ts`.
- `migrations/` — all SQL migrations (numbered). `MIGRATIONS.md` is the run-checklist.

## 8. Current state — immediate to-dos
**Current setup candidate:** 177.44.260816 is the corrective candidate for the 177.43 transition-policy PR: it adds the required `Game.code` field to the dedicated policy test fixture so dependency-backed TypeScript/CI can compile; runtime policy behavior is unchanged and there is no migration.
**Current working candidate: 177.44.260816 (transition-policy test-fixture typecheck correction).**
- 177.26 supersedes the unreleased 177.25 candidate after its first GitHub execution exposed verification-harness ordering/sequencing defects; it still includes the 177.24 dashboard Putts/round + targeted stats-completion baseline.
- Migrations `0135_ledger_backfill.sql`, `0136_core_rls_helpers.sql`, and `0137_core_rls_baseline.sql` are now **applied and verified in both staging and Production**. Production/staging ledgers are reconciled through 0137 (0129 is the intentional reserved gap); both environments expose the expected 60 core RLS policies across 12 tables.
- `0135` evidence-backfilled 0122-0128 into both ledgers; `0136` installed/verified the six Production SECURITY DEFINER RLS helpers; `0137` installed the source-controlled core RLS policy/grant baseline. The real staging integration harness passed afterward and Production passed a non-destructive smoke test.
- `ci/core_rls_production_baseline.json` is the machine-readable 2026-08-14 Production RLS baseline (12 tables / 60 policies). `ci/core_rls_helpers_production_baseline.json` captures the six helper definitions. `ci/assert-core-rls-live.sql` is the read-only live drift guard.
- Fresh-database reconstruction is now part of required `CI / verify`: a pinned Supabase CLI creates a disposable database, applies both migration trees from empty state, and asserts the checked-in RLS baseline. The first GitHub execution correctly exposed a full-path ordering bug; 177.26 fixes ordering by numeric migration prefix and requires a corrected GitHub fresh-DB PASS before ship.
- The schema migration ledger (`public.schema_migrations`) is the source of truth for applied state from 0113 onward. `MIGRATIONS.md` is a human checklist and must not be treated as authoritative applied-state evidence.
- 177.39 completed the historical round rating/slope feature. 177.40 is a refactor-only candidate and remains **NOT DEPLOYABLE** until its own dependency-backed CI/type/test/build, characterization/guard suite, staging validation, PR verify, Production Ready, and smoke gates pass.

## 9. Recent major thread — "date of play" (context you'll need)
The recent work overhauled how a round's date is recorded:
- **Games (team/multiplayer):** recorded date is ALWAYS the day it was **scored** (games are scored live,
  never back-dated). The entered "Play date" is scheduling/display only. (migration 0110)
- **Solo rounds:** user-entered date, defaults to today, **editable** in the round editor. (v1.163.0)
- **Past-date confirmation:** any round saved with a date before today prompts a confirm. (v1.163.0)
- **Organizer** can correct a whole game's date; all players' rounds move together via
  `set_game_played_date`. (migration 0110 + v1.164.0)
- Posting functions `post_game_rounds_internal` (games) and `post_group_rounds` (tee-groups) set
  `played_at` = scored date and **preserve it on re-post** (finalizing a day later doesn't move the date).

## 10. Backlog (untouched — pick up when asked)
Flights Stage 2/3; large-field leaderboard; organizer console Phase 2/3; a "why your handicap moved"
one-liner; friction hardening (partial unique index on `rounds(user_id)` where in-progress); real GHIN
auto-import (parked); silent `catch{}` hardening.

## 11. Working style with Amit
Terse, technically precise. Diagnose root cause before patching; design for known cross-environment
tensions (installed PWA vs browser viewport) up front. Confirm plans on big/DB/semantic changes. Mockups
before visual changes. Don't over-format. When unsure, ask one crisp question.

---

## Appendix A — migration 0108 (applied — reference)
```sql
-- 0108_admin_stat_users_avatars.sql
drop function if exists public.admin_stat_users(text, text, date);

-- 0108_admin_stat_users_avatars.sql
-- Adds avatar_url to the shared analytics "who" drill so the drill sheet can show photos.
-- DROP+CREATE (return shape changes); re-applies the 0096 America/New_York timezone + grant.
-- Regenerated from 0090 by adding each branch's profile avatar_url as a 4th column.
-- The drill-down engine: one is_admin-gated RPC that, given a stat key (and optional arg/date),
-- returns the UNIFORM list of users behind that number: (name, detail, tag). Every analytics
-- stat routes through here so drill-down is consistent and new stats get it for free.
-- Real-round definition matches the app: deleted_at is null AND status <> 'in_progress'.
-- Test + deactivated accounts excluded from user-population stats.
-- NOTE: push_prefs values are 'push' | 'inapp' | 'off' (delivery mode), so "muted" = 'off';
-- notifications-on = the user has an active (non-disabled) push_subscription.
create or replace function public.admin_stat_users(
  p_stat text,
  p_arg text default null,
  p_date date default null
)
returns table(name text, detail text, tag text, avatar_url text)
language plpgsql
security definer
set search_path = public
as $function$
declare
  d date := coalesce(p_date, current_date);
begin
  if not public.is_admin() then raise exception 'admins only'; end if;

  if p_stat = 'users_total' then
    return query select coalesce(p.display_name,'(no name)'), coalesce(p.email,''), null::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
      order by p.display_name nulls last;

  elsif p_stat = 'users_new_30d' then
    return query select coalesce(p.display_name,'(no name)'), 'first seen '||to_char(fa.first_day,'Mon DD'), 'new'::text
     , p.avatar_url from profiles p join (select user_id, min(day) first_day from daily_active group by user_id) fa on fa.user_id=p.id
      where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false and fa.first_day > current_date - 30
      order by fa.first_day desc;

  elsif p_stat = 'active_dau' then
    return query select coalesce(p.display_name,'(no name)'), da.opens||' opens today', null::text
     , p.avatar_url from profiles p join daily_active da on da.user_id=p.id and da.day=current_date
      where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false order by da.opens desc;

  elsif p_stat in ('active_wau','active_mau') then
    return query select coalesce(p.display_name,'(no name)'), sum(da.opens)::text||' opens', null::text
     , p.avatar_url from profiles p join daily_active da on da.user_id=p.id
      where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and da.day > current_date - (case p_stat when 'active_wau' then 7 else 30 end)
      group by p.id, p.display_name order by sum(da.opens) desc;

  elsif p_stat = 'lapsed' then
    return query select coalesce(p.display_name,'(no name)'), 'last seen '||to_char(mx.last_day,'Mon DD'), 'lapsed'::text
     , p.avatar_url from profiles p join (select user_id, max(day) last_day from daily_active group by user_id) mx on mx.user_id=p.id
      where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and mx.last_day <= current_date - 30 and mx.last_day > current_date - 60 order by mx.last_day desc;

  elsif p_stat = 'never_joined_group' then
    return query select coalesce(p.display_name,'(no name)'), coalesce(p.email,''), 'no club'::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and not exists (select 1 from group_members gm where gm.user_id=p.id and gm.status='active')
      order by p.display_name nulls last;

  elsif p_stat = 'rounds_done' then
    return query select coalesce(p.display_name,'(no name)'), count(*)::text||' completed', null::text
     , p.avatar_url from profiles p join rounds r on r.user_id=p.id
      where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and r.deleted_at is null and coalesce(r.status,'final')<>'in_progress'
      group by p.id, p.display_name order by count(*) desc;

  elsif p_stat = 'rounds_started' then
    return query select coalesce(p.display_name,'(no name)'), count(*)::text||' in progress', 'open'::text
     , p.avatar_url from profiles p join rounds r on r.user_id=p.id
      where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and r.deleted_at is null and coalesce(r.status,'final')='in_progress'
      group by p.id, p.display_name order by count(*) desc;

  elsif p_stat in ('abandoned','unfinished') then
    return query select coalesce(p.display_name,'(no name)'),
        count(*) filter (where r.deleted_at is null and coalesce(r.status,'final')='in_progress')::text||' unfinished'
          || case when count(*) filter (where r.deleted_at is not null) > 0
                  then ' · '||count(*) filter (where r.deleted_at is not null)::text||' deleted' else '' end,
        'friction'::text
     , p.avatar_url from profiles p join rounds r on r.user_id=p.id
      where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and ((r.deleted_at is null and coalesce(r.status,'final')='in_progress' and r.created_at < now() - interval '24 hours')
             or r.deleted_at is not null)
      group by p.id, p.display_name
      having count(*) filter (where r.deleted_at is null and coalesce(r.status,'final')='in_progress') > 0
          or count(*) filter (where r.deleted_at is not null) >= 3
      order by count(*) desc;

  elsif p_stat = 'rounds_day' then
    return query select coalesce(p.display_name,'(no name)')||' · '||coalesce(r.course,'course'),
        (select count(*) from holes h where h.round_id=r.id and h.strokes is not null)::text||' holes'
          || case when r.gross_score is not null then ' · gross '||r.gross_score::text else '' end,
        case when r.deleted_at is not null then 'deleted'
             when coalesce(r.status,'final')='in_progress' then 'in progress'
             when r.finished_by='system:auto' then 'auto-finished' else 'completed' end
     , p.avatar_url from rounds r join profiles p on p.id=r.user_id where r.played_at = d order by r.created_at;

  elsif p_stat = 'active_day' then
    return query select coalesce(p.display_name,'(no name)'), da.opens||' opens', null::text
     , p.avatar_url from daily_active da join profiles p on p.id=da.user_id
      where da.day = d and coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false order by da.opens desc;

  elsif p_stat = 'installed' then
    return query select coalesce(p.display_name,'(no name)'), coalesce(p.email,''), 'installed'::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false and p.last_standalone is true
      order by p.display_name nulls last;

  elsif p_stat = 'browser' then
    return query select coalesce(p.display_name,'(no name)'), coalesce(p.email,''), 'browser'::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false and p.last_standalone is false
      order by p.display_name nulls last;

  elsif p_stat = 'notif_on' then
    return query select coalesce(p.display_name,'(no name)'), 'push enabled', 'on'::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and exists (select 1 from push_subscriptions s where s.user_id=p.id and s.disabled=false)
      order by p.display_name nulls last;

  elsif p_stat = 'notif_off' then
    return query select coalesce(p.display_name,'(no name)'), 'no active device', 'off'::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and not exists (select 1 from push_subscriptions s where s.user_id=p.id and s.disabled=false)
      order by p.display_name nulls last;

  elsif p_stat = 'failing_subs' then
    return query select coalesce(p.display_name,'(no name)'),
        'fails '||max(s.fail_count)::text||' · last seen '||to_char(max(s.last_seen),'Mon DD'), 'stale'::text
     , p.avatar_url from push_subscriptions s join profiles p on p.id=s.user_id
      where s.disabled=true or s.fail_count >= 3 or s.last_seen < now() - interval '14 days'
      group by p.id, p.display_name order by max(s.fail_count) desc nulls last;

  elsif p_stat = 'mute' and p_arg is not null then
    return query select coalesce(p.display_name,'(no name)'), 'set to Off', 'muted'::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and (p.push_prefs->>p_arg) = 'off'
      order by p.display_name nulls last;

  elsif p_stat = 'share_on' then
    return query select coalesce(p.display_name,'(no name)'), 'card visible', 'on'::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false and coalesce(p.show_card,true)=true
      order by p.display_name nulls last;

  elsif p_stat = 'share_off' then
    return query select coalesce(p.display_name,'(no name)'), 'opted out', 'off'::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false and coalesce(p.show_card,true)=false
      order by p.display_name nulls last;

  elsif p_stat = 'guests' then
    return query select coalesce(host.display_name,'(no name)'), count(*)::text||' guest rounds hosted', 'host'::text
     , host.avatar_url from game_players gp join profiles host on host.id = gp.guest_of
      where gp.guest_of is not null group by host.id, host.display_name order by count(*) desc;

  elsif p_stat = 'avatars_set' then
    return query select coalesce(p.display_name,'(no name)'), 'has avatar', null::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and p.avatar_url is not null and p.avatar_url <> '' order by p.display_name nulls last;

  elsif p_stat = 'ai_summaries' then
    return query select coalesce(p.display_name,'(no name)'), 'has AI summary', null::text
     , p.avatar_url from profiles p where coalesce(p.is_test,false)=false and coalesce(p.deactivated,false)=false
        and p.dashboard_ai is not null order by p.display_name nulls last;

  end if;
  return;
end;
$function$;
alter function public.admin_stat_users(text, text, date) set timezone = 'America/New_York';
grant execute on function public.admin_stat_users(text, text, date) to authenticated;
```

## Appendix B — migration 0110 (applied — reference)
```sql
-- 0110_games_always_scored_date.sql
-- Games are scored live and never back-dated (team play), so a game round's recorded date is ALWAYS
-- the day it was scored — the game's entered play date is scheduling/display only. This drops the
-- 'deliberately-entered date wins' branch from 0109 for games. Also adds set_game_played_date so an
-- organizer can correct a whole game's date (all players' rounds move together), and finishes the
-- backfill for any game rounds still holding an inherited date.

create or replace function public.post_game_rounds_internal(p_game uuid, p_system boolean default false)
returns void language plpgsql security definer set search_path = public as $$
declare
  g       record;
  pl      record;
  rid     uuid;
  hmeta   jsonb;
  n       int;
  i       int;
  sc      int;
  gross   int;
  entered int;
  rdate   date;
begin
  select * into g from games where id = p_game;
  if not found then return; end if;

  hmeta := coalesce(g.holes_meta, '[]'::jsonb);
  n := jsonb_array_length(hmeta);
  -- Games are scored live, so a round's recorded date is always the day it was scored (this first
  -- post). The game's play-date field is scheduling/display only. Re-posts preserve played_at, and an
  -- organizer can correct a whole game's date via set_game_played_date.
  rdate := (now() at time zone 'America/New_York')::date;

  for pl in
    select * from game_players where game_id = p_game and user_id is not null
  loop
    gross := 0; entered := 0;
    for i in 0 .. n - 1 loop
      sc := nullif(pl.scores->>i, '')::int;
      if sc is not null and sc > 0 then
        entered := entered + 1;
        gross := gross + sc;
      end if;
    end loop;
    if entered = 0 then continue; end if;

    select id into rid from rounds where game_id = p_game and user_id = pl.user_id limit 1;
    if rid is not null then
      update rounds set
        course = g.course, tee_name = pl.tee_name, rating = pl.rating, slope = pl.slope,
        course_par = g.course_par, handicap_index = pl.handicap_index,
        course_handicap = pl.course_handicap, group_id = g.group_id,
        status = 'final', gross_score = gross
      where id = rid;
    else
      insert into rounds (
        user_id, course, tee_name, rating, slope, course_par, handicap_index,
        course_handicap, group_id, played_at, status, gross_score, game_id
      ) values (
        pl.user_id, g.course, pl.tee_name, pl.rating, pl.slope, g.course_par, pl.handicap_index,
        pl.course_handicap, g.group_id, rdate, 'final', gross, p_game
      )
      on conflict (game_id, user_id) do update set
        course = excluded.course, tee_name = excluded.tee_name, rating = excluded.rating,
        slope = excluded.slope, course_par = excluded.course_par,
        handicap_index = excluded.handicap_index, course_handicap = excluded.course_handicap,
        group_id = excluded.group_id,
        status = excluded.status, gross_score = excluded.gross_score
      returning id into rid;
    end if;

    delete from holes where round_id = rid;
    for i in 0 .. n - 1 loop
      sc := nullif(pl.scores->>i, '')::int;
      if sc is not null and sc > 0 then
        insert into holes (
          round_id, hole_number, par, stroke_index, strokes, putts, fairway, penalties, sand, yardage
        ) values (
          rid,
          (hmeta->i->>'n')::int,
          (hmeta->i->>'par')::int,
          nullif(hmeta->i->>'si','')::int,
          sc,
          nullif(pl.putts->>i, '')::int,
          nullif(pl.fairways->>i, ''),
          coalesce(nullif(pl.penalties->>i, '')::int, 0),
          coalesce((pl.sand->>i)::boolean, false),
          nullif(hmeta->i->>'yards','')::int
        );
      end if;
    end loop;
  end loop;

  if p_system then
    update rounds set finished_by = 'system:auto', finished_at = coalesce(finished_at, now())
    where game_id = p_game;
  end if;
end;
$$;

create or replace function public.post_group_rounds(p_game uuid, p_tee_group int)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  g       record;
  pl      record;
  rid     uuid;
  hmeta   jsonb;
  n       int;
  i       int;
  sc      int;
  gross   int;
  entered int;
  rdate   date;
begin
  select * into g from games where id = p_game;
  if not found then return; end if;
  -- Caller must be a player in this game (any member can finish their group).
  if not exists (
    select 1 from game_players where game_id = p_game and user_id = auth.uid()
  ) then
    return;
  end if;

  hmeta := coalesce(g.holes_meta, '[]'::jsonb);
  n := jsonb_array_length(hmeta);
  -- Deliberately-entered date first, else the date it's actually scored.
  -- Games are scored live, so a round's recorded date is always the day it was scored (this first
  -- post). The game's play-date field is scheduling/display only. Re-posts preserve played_at, and an
  -- organizer can correct a whole game's date via set_game_played_date.
  rdate := (now() at time zone 'America/New_York')::date;

  for pl in
    select * from game_players
    where game_id = p_game and user_id is not null and tee_group = p_tee_group
  loop
    -- Tally entered holes + gross from the player's jsonb scores.
    gross := 0; entered := 0;
    for i in 0 .. n - 1 loop
      sc := nullif(pl.scores->>i, '')::int;
      if sc is not null and sc > 0 then
        entered := entered + 1;
        gross := gross + sc;
      end if;
    end loop;
    if entered = 0 then continue; end if;  -- didn't play

    -- Upsert the round row (one per game+user). ON CONFLICT keeps a racing client
    -- insert from aborting the whole post; it updates that row in place instead.
    select id into rid from rounds where game_id = p_game and user_id = pl.user_id limit 1;
    if rid is not null then
      update rounds set
        course = g.course, tee_name = pl.tee_name, rating = pl.rating, slope = pl.slope,
        course_par = g.course_par, handicap_index = pl.handicap_index,
        course_handicap = pl.course_handicap, group_id = g.group_id,
        status = 'final', gross_score = gross
      where id = rid;
    else
      insert into rounds (
        user_id, course, tee_name, rating, slope, course_par, handicap_index,
        course_handicap, group_id, played_at, status, gross_score, game_id
      ) values (
        pl.user_id, g.course, pl.tee_name, pl.rating, pl.slope, g.course_par, pl.handicap_index,
        pl.course_handicap, g.group_id, rdate, 'final', gross, p_game
      )
      on conflict (game_id, user_id) do update set
        course = excluded.course, tee_name = excluded.tee_name, rating = excluded.rating,
        slope = excluded.slope, course_par = excluded.course_par,
        handicap_index = excluded.handicap_index, course_handicap = excluded.course_handicap,
        group_id = excluded.group_id,
        status = excluded.status, gross_score = excluded.gross_score
      returning id into rid;
    end if;

    -- Rewrite per-hole detail for played holes only.
    delete from holes where round_id = rid;
    for i in 0 .. n - 1 loop
      sc := nullif(pl.scores->>i, '')::int;
      if sc is not null and sc > 0 then
        insert into holes (
          round_id, hole_number, par, stroke_index, strokes, putts, fairway, penalties, sand, yardage
        ) values (
          rid,
          (hmeta->i->>'n')::int,
          (hmeta->i->>'par')::int,
          nullif(hmeta->i->>'si','')::int,
          sc,
          nullif(pl.putts->>i, '')::int,
          nullif(pl.fairways->>i, ''),
          coalesce(nullif(pl.penalties->>i, '')::int, 0),
          coalesce((pl.sand->>i)::boolean, false),
          nullif(hmeta->i->>'yards','')::int
        );
      end if;
    end loop;
  end loop;
end;
$$;

-- Organizer-only: correct a whole game's date. Moves the game's display/schedule date AND every
-- posted round for that game together, so all players stay in sync. Past-date confirmation is done
-- client-side. security definer so the organizer can touch other players' round rows (RLS-guarded).
create or replace function public.set_game_played_date(p_game uuid, p_date date)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from games where id = p_game and created_by = auth.uid()) then
    raise exception 'only the organizer can change the game date';
  end if;
  update games  set played_at = p_date where id = p_game;
  update rounds set played_at = p_date where game_id = p_game;
end;
$$;
grant execute on function public.set_game_played_date(uuid, date) to authenticated;

-- Complete the 0109 backfill now that games always use the scored date: force EVERY game round to the
-- day it was actually scored (its first-post/creation day, ET), superseding any inherited match date.
-- Rounds already on that date are untouched; solo rounds (game_id null) are left alone.
update public.rounds r
set played_at = (r.created_at at time zone 'America/New_York')::date
where r.game_id is not null
  and r.deleted_at is null
  and r.played_at is distinct from (r.created_at at time zone 'America/New_York')::date;
```

## v177.14 automated pre-deploy gate
Current release target: **177.14.260808**. Migration sequence assumes 0130/0131/0132 are already live from v177.13; apply **0133_testing_and_money_atomicity.sql** before deploying v177.14.
For release candidates, run `npm run ci:staging` against a disposable/staging Supabase project with `BNN_STAGING_SUPABASE_URL`, `BNN_STAGING_SUPABASE_ANON_KEY`, `BNN_STAGING_SUPABASE_SERVICE_ROLE_KEY`, and the explicit safety switch `BNN_STAGING_ALLOW_MUTATION=YES`. The suite creates and removes test users/data; never point it at production.


## v177.15 corrective release
- Production path: if v177.14/0133 is already live, apply only `0134_fix_bet_rpc_ambiguous_id.sql`, confirm the ledger row, then deploy v177.15.
- Fresh path: 0129 remains intentionally skipped/reserved; apply 0130 → 0131 → 0132 → 0133 → 0134.
- 0134 was generated from a failure caught by the real GitHub/Supabase staging integration gate and then validated by a fully green staging run.
- Do not copy production data or production outbound webhooks into staging; schema/RPC parity plus disposable test fixtures is the intended model.

## v177.19+ refactor integrity rule
A modular refactor is not verified by byte identity alone. Preserve and permanently characterize the full entry -> inputs/state -> extracted code -> outputs/callbacks -> downstream dependency/DB side effects -> refresh/cancel/exit chain, including effect timing. Use explicit prop contracts, `satisfies` for spread props, reachability/state/dependency CI guards, differential tests for pure logic, and scenario tests for stateful flows. Treat unused props/state/imports as boundary-drift signals.

Release candidates must be constructed from the latest clean synchronized `staging` baseline (`main` synced back after production), never from an older uploaded release ZIP.

## External provider contract rule (177.20+)
- External API identifiers are opaque provider-owned tokens. Do not assume numeric/string formats from historical data unless the provider explicitly guarantees them.
- GolfCourseAPI has a scheduled golden-fixture contract monitor in `.github/workflows/external-api-contracts.yml`; it checks search/detail availability, exact reviewed course identities, ids, metadata, and required detail fields and opens/updates a GitHub issue on drift.
- Before changing BNN in response to an external-data failure, compare live provider responses with the golden fixtures and determine whether the provider contract or BNN code changed.
- Preserve BNN internal UUIDs/history across provider migrations; reconcile provider-owned ids/metadata separately.

## 177.21 source/environment contracts
- Staging is visually marked by a yellow safe-area-aware border and STAGING badge based on `VERCEL_GIT_COMMIT_REF === "staging"`; Production must not display it.
- Add New Course now distinguishes canonical BNN data from fresh GolfCourseAPI data at selection time. Existing canonical rows remain primary; provider data is comparison-only until the user explicitly chooses to review it.
- 177.21 Production deployment is the required live transition test for the 177.20 PWA update contract: the installed 177.20 shell must remain active until Update is pressed.

### Stateful UI evidence rule
For changed interactions, do not equate handler reachability with working behavior. Verify action -> complete state propagation -> observable UI -> downstream effects -> reverse/cancel/re-entry. Label evidence MODELLED, EXECUTED, or BROWSER-VALIDATED; never report modelled behavior as an executed PASS. Mode/source switches require round-trip A -> B -> A verification.


## Correction workflow terminal-path rule (177.23+)
- When a stateful flow can enter a validation-required terminal action, the UI must expose every required input before submission and the primary CTA must describe the actual terminal action.
- For course provider review, Stored BNN -> Provider review -> reason entry -> Submit for approval -> pending/review outcome is part of the observable-outcome contract; the reverse/cancel path must remain reachable.

## 177.25 integrity hardening status
- Current working candidate: `177.25.260814`.
- Do not ship until the Production RLS export for the 12 legacy core tables has been captured and converted into an executable idempotent baseline migration, then verified by a fresh-database reconstruction test.
- Migration 0135 is an evidence-based ledger backfill for 0122-0128; it must be executed as database owner/postgres, not through an application Supabase client.

### 177.27 fresh-database prerequisite correction
- Fresh-DB CI now installs source-controlled PostgreSQL prerequisites before migration 0001.
- Current pre-0001 prerequisite: `citext`, because `0001_baseline.sql` uses the type while historical migration 0038 only declares the extension later.
- `pg_cron` remains self-declared by migration 0074 before its first `cron.*` use.
- `ci/check_db_extension_prereqs.py` permanently validates extension availability against the real globally ordered migration stream.
- Do not apply migrations 0135-0137 to staging or Production until the disposable fresh-database GitHub gate passes end-to-end.


## 177.28 fresh-database reconstruction status
- Disposable rebuild now has explicit extension prerequisites and globally ordered migrations.
- CI 177.27 reached `0017_notifications_lockdown.sql` and exposed the baseline omission of the historical `create notifications` policy.
- 177.28 restores only that pre-0017 compatibility policy in `0001_baseline.sql` and adds `ci/check_legacy_migration_prereqs.py` so non-idempotent historical object dependencies are audited semantically.
- Do not apply 0135-0137 to staging or Production until the full disposable rebuild reaches the end and passes the core-RLS verification.

## 177.29 comprehensive migration dependency audit
- After fresh replay exposed a missing `is_group_member(uuid,uuid)` dependency at migration 0025, the audit was expanded across the entire 135-migration ordered stream rather than iterating one CI failure at a time.
- `0001_baseline.sql` now reconstructs the historical pre-0034 versions of `is_admin`, `is_group_member`, and `is_group_admin`; 0034 remains the point where banned-user enforcement is added.
- `ci/check_legacy_migration_prereqs.py` now checks relation ordering, all repo-defined function calls/use-before-create, policy prerequisites, explicit column-state operations, custom types, and unresolved `public.*` function references. Extension ordering remains separately guarded.
- Current static closure result: PASS across 135 migrations; negative mutation test also PASS (guard fails when the historical helper is removed).
- Do not apply 0135-0137 to staging or Production until GitHub's disposable fresh-database replay passes end-to-end.

## 177.30 historical baseline column closure
- CI #39 advanced clean-database replay through migration 0042 and failed at 0043 because `rounds.game_id` was absent from the committed baseline. Production/staging live databases were not changed.
- The Production-derived 177.14 bootstrap was used as historical evidence to identify baseline-table columns that existed outside the numbered migration stream. Nine such compatibility columns are now source-controlled in `supabase/migrations/0001_baseline.sql`.
- Fresh DB CI now asserts those nine columns after the full migration chain, including type/nullability/default expectations.
- Static migration dependency analysis now includes executable column dependencies and is negative-tested against the exact 0043 game_id failure pattern.
- Continue to treat disposable fresh-database execution as authoritative. Do not apply 0135-0137 to staging until the fresh replay is green through the entire stream and final RLS/security assertions.


## 177.31 RLS parity diagnostics
- CI #40 completed the full migration stream through `0137_core_rls_baseline.sql` and passed the historical nine-column compatibility assertion, then failed only at the final exact RLS policy comparison.
- The old verifier reported `30 differing row(s)` without policy/field detail, which is insufficient evidence for modifying security policy definitions.
- `ci/assert-core-rls-live.sql` now emits `CORE_RLS_DIFF` diagnostics keyed by table/policy, including differing fields and raw expected/actual `permissive`, roles, command, USING expression, and WITH CHECK expression.
- Whitespace-only expression flags are diagnostic only; exact raw parity remains mandatory until differences are classified.
- Do not apply 0135-0137 to staging or Production until the fresh rebuild's policy differences are fully explained and the final security contract gate passes.


## 177.32 RLS diagnostic transaction lifetime
- Root cause of the 177.31 verifier execution failure is confirmed: `_core_rls_expected` used `ON COMMIT DROP` while the script ran under psql autocommit with no enclosing transaction. The table was dropped immediately after CREATE TABLE, so the following INSERT failed before any policy diagnostics could run.
- Working correction adds an explicit `BEGIN` before the verifier work and `COMMIT` only after the PASS result.
- Source-contract guard now checks that ordering.
- 177.32 may be packaged only as a staging-diagnostic overlay so GitHub can execute the disposable PostgreSQL gate. Do not treat it as deployable, apply 0135-0137 to staging/Production, or promote to `main` until (a) matching fixtures => PASS and (b) deliberate mismatch => emitted `CORE_RLS_DIFF` row(s) followed by hard failure, followed by the complete release gate.


## 177.33 RLS runtime-canonical parity gate
- CI 177.32 proved the diagnostic transaction fix and reduced the former 30 count-only rows to 15 named policy keys. Review of all 15 showed the same class: PostgreSQL `pg_policies` parse/deparse rendering differences on subquery expressions, with no role/command/predicate-semantic drift visible.
- 177.33 preserves the Production raw baseline but canonicalizes `qual`/`with_check` by creating session-local shadow tables/policies and letting the SAME running PostgreSQL engine parse/deparse the expected expressions. The real public policies are then compared against that runtime-canonical form.
- Metadata (table/policy key, permissive mode, roles, command), RLS state, and grants remain exact comparisons. `CORE_RLS_RENDERING` is informational only; `CORE_RLS_DIFF` remains a hard failure.
- The verifier includes executable negative canaries for removed admin checks, ownership checks, guest checks, active-membership checks, AND->OR mutation, and organizer-condition mutation, plus one equivalent-format convergence canary. It also logs the PostgreSQL server version.
- Do not apply 0135-0137 to real staging or Production and do not promote to main until GitHub's disposable fresh-DB run proves the canonical gate/canaries and the complete release gate is green.


### 177.34.260815 — split RLS structural / semantic / behavior verification
- Replaces the flawed 177.33 pg_temp deparser-canonicalization approach. PostgreSQL deparsed text is no longer treated as a stable security semantic contract.
- `ci/assert-core-rls-live.sql` is again production-safe/read-only and hard-gates stable runtime structure only: 12 RLS table states, exact 60 policy identities/permissive modes/roles/commands, and exported grants.
- New fresh-DB-only `ci/assert-core-rls-behavior.sql` exercises authenticated owner-vs-other authorization for notifications, rounds, and holes, including allowed writes and denied cross-user writes. All fixtures and trigger-disable changes roll back.
- `ci/test_fresh_db_rebuild.sh` now requires structural and behavior RLS gates after the full migration replay; `ci/check_fresh_db_ci_contract.py` permanently guards that architecture and rejects a return to pg_temp expression canonicalization.
- No application code, RLS policy, grant, helper, migration, staging database, or Production database behavior is changed.
- **NOT DEPLOYABLE:** PostgreSQL execution of the new structural/behavior gates, full dependency-backed CI/type/test/build, Vercel staging, staging regression validation, PR verify, Production Ready and smoke remain mandatory.

## 177.35 hook-lint gate reconciliation
- CI on 177.34 reached the dependency-backed `npm run ci` chain and stopped at its first stage because ESLint reported 23 unused disable directives with `--max-warnings=0`.
- Exact current staging source contains 22 reviewed `react-hooks/exhaustive-deps` suppressions plus one generic inline `eslint-disable-next-line`; `eslint.config.mjs` enables only `react-hooks/rules-of-hooks`, so all 23 directives are stale and have no runtime effect.
- 177.35 removes only those 23 comments. No effect bodies, dependency arrays, props, state, callbacks, imports, APIs, RPCs, database writes, or UI behavior are changed.
- `ci/check_effect_suppressions.py` now enforces a permanent zero-suppression contract for `react-hooks/exhaustive-deps`; the old 22-line legacy baseline is retired. The broader exhaustive-deps dependency audit remains backlog work and the rule itself is not enabled by this corrective.
- Local dependency installation timed out in this execution environment, so dependency-backed ESLint/TypeScript/unit/build remain GitHub-authoritative gates. Do not call 177.35 deployable until the complete GitHub CI chain, fresh-database reconstruction/RLS behavior gate, Vercel staging build, and relevant staging regression checks are green.



## 177.39 historical round rating/slope correction
- Existing final rounds expose historical Course rating / Slope in Round Editor. Saving a correction writes only that round's `rating`, `slope`, and recalculated `course_handicap` (using the handicap index stored on the round), then the normal round reload recomputes differential and app-estimated handicap history.
- Gross-only historical rounds can save the correction without losing `gross_score` or inventing hole rows. Cancel on an already-recorded round is non-destructive.
- Game-linked personal rounds remain personal-history corrections only; no game/game_player data is rewritten. Course-library propagation remains separate/explicit through Save course.
- No migration.

## 177.36 CI severity alignment
- GitHub 177.35 progressed past hook lint and reached the guard suite, then stopped because `ci/check_extracted_import_debt.py` returned exit 1 for unused-symbol debt changes. APP_RULES #26 already defines unused props/state/imports as boundary-drift **warnings**, so the implemented severity contradicted the documented policy.
- 177.36 keeps the unused-symbol measurement and full per-file report but makes it explicitly **ADVISORY** (exit 0). The baseline is not reset and no reported application code is cleaned up in this corrective.
- Blocking gates remain blocking: fresh-database reconstruction, RLS/security structure and behavior, migration/source closure, secrets/environment safety, TypeScript correctness, unit/differential behavior, production build, reachability/source-contract defects, and feature correctness.
- No application logic, migration, RLS policy, grant, helper, or database behavior changes. The purpose is severity alignment, not suppression of evidence.
- Release remains **NOT DEPLOYABLE** until all blocking GitHub/fresh-DB/type/test/build/staging gates pass. Advisory findings must be carried in release verification/backlog rather than silently discarded.


## 177.40 Game setup workspace extraction
- Scope is deliberately narrow: extract only the existing organizer setup stepper/progress/render calculations into `components/game/setup/game-setup-workspace.tsx`; no UX redesign and no transition-policy behavior yet.
- `GameRoom` keeps setup state, every mutation handler, every Supabase/RPC write, `load()`/refresh chains, structure stash/restore, scoring ownership, and Matchups/StrokesSummary rendering.
- `GameRoom` constructs `OrganizerPanelProps` and `GameSetupWorkspace` props with `satisfies` so callback/boundary drift fails TypeScript.
- Permanent `ci/check_game_setup_workspace_contract.py` verifies step visibility/fallback, Players/Teams/Groups reachability, tee/handicap/add-player/group callback bridges, Matchups reachability, and forbids DB ownership in the extracted workspace.
- Next product stage after this refactor is validated: persistent Game Control Center UX that lets organizers revisit Game/Players/Format/Teams & Groups/Review, followed by a centralized before/after-scoring transition policy.

## 177.49 Create Game convergence staging train
- Production intentionally remains on the last completed release while 177.47+ accumulate on `staging`; do not open staging->main PRs for intermediate convergence checkpoints.
- 177.47: canonical Create Game draft/state inventory foundation.
- 177.48: pure game-structure mutations with differential characterization.
- 177.49 Stage 3A: shared Create Game navigation workspace (**Game -> Players -> Format -> Teams & groups -> Review**) using existing parent state/handlers. No persistence ownership moved; no migration.
- 177.50 Stage 3B: creation-time tee inheritance is now **individual override -> one-off flight tee -> game default tee**. The maps persist in Resume Setup, old drafts remain compatible, and Create resolves inheritance into explicit player tee/rating/slope/course-handicap snapshots. No migration.
- Before Stage 3 is complete, move the existing team/matchup/foursome/tee-group structure into pre-create draft state without discarding structure work.
- Stage 4 remains the atomic core Create transaction after the draft UI is fully characterized and browser-validated.

## Current staging convergence checkpoint — 177.52 Lean Create
Create Game is intentionally **lean**: Game → Players → Format → Review. Default/flight/player tee inheritance and Resume Setup remain in Create; persisted structural work (teams, matchups, foursomes, tee groups) is completed in Manage Game, which remains the single source of truth for transition policy and structural edits. Stableford/Stroke create into Play; structural formats create into the relevant Manage Game setup section. No migration. Production should not receive the convergence train until cumulative validation is complete.


## 212.78 candidate — missing-handicap comparison

Manual course handicap is authoritative for differential comparisons via a game-specific equivalent index using the saved course par, tee rating and slope. Without an entered manual value, use a real recorded game-row index (including explicit0); missing is unavailable, never scratch. No profile writes, stored round changes or 9-hole comparison expansion. See RELEASE_VERIFICATION_212.78.md. Application deployment remains pending; this is a new fix beyond 212.77.

## Historical212.79 update deferral — superseded by212.84
Source files: lib/update-safety.ts, lib/update-handshake.ts, components/update-safety.tsx, components/register-sw.tsx, components/app-update-checker.tsx, game room and personal editor lifecycle integrations, public/sw.js. No migration.
The currently reviewed baseline is the locally available 212.77 source with the exact saved 212.78 candidate overlaid. Reconcile against the latest synchronized GitHub branches before committing; do not overwrite newer remote work.
Existing older clients cannot answer the new worker handshake. During the first rollout the waiting worker refuses activation until those tabs/windows are closed. Close all BNN windows after completing/syncing, then reopen. Never close during entry merely to force an update.
An unresolved draft, storage failure, offline/missing game read, or an unresponsive tab may keep updates deferred. No age-based deletion or forced activation is provided. Resume/finish/discard through the app; retain backups.
See RELEASE_VERIFICATION_212.79.md for executed vs pending verification. User will wait for green GitHub CI before the production merge PR. Full source ZIP delivery is now required; no bloat cleanup in this release.

## Historical212.80 update feedback — superseded by212.84
Fixes missing feedback/dismissal in 212.79. Source: lib/app-update.ts, components/app-update-status.tsx; shared Settings/banner actions, worker outcome messages and detailed safety blockers. No migration. Existing loaded OLD builds cannot retroactively gain this UI; for the one-time transition, finish/sync scores, close all BNN windows and reopen. Never clear browser storage to force installation. Do not bypass first-rollout safety just to get the new feedback.

## Current212.84 automatic update handoff
User explicitly replaced unfinished-round update deferral with automatic installation and fresh-open/refresh loading. No running-document reload on deployment/focus/controllerchange. No score/draft/round cleanup required. Pending data, ordinary scoring sync and primary-device security remain intact. Legacy verification/correction helpers are retained for source-copy compatibility, existing recovery archives and previously copied links; the live update flow does not call or render them. Legacy manual-worker behavior is kept only as an explicit browser-test fixture. Follow RELEASE_VERIFICATION_212.84.md and its staging/iPhone gates.

## 212.85 member-guide upkeep
User declined an updated-version banner and prefers monthly feature education by email. No banner or email sending/scheduling is added. Shared capabilities now cover all8 game formats, Ryder Cup events and round recaps. Scramble/Alternate Shot are in Help's Formats answer; Scramble and Ryder Cup have guidance. Both PDF editions regenerated from the same JSON. Every future member feature must review the guide/FAQ/PDFs; ci/check_capabilities_formats.py prevents format-list drift.

<!-- 212.106: CI-only scheduler test correction. No new migration; 0234 is unchanged. -->
<!-- 212.105: no additional migration. 0234 SQL is byte-identical to 212.104; this release corrects CI assertions only. -->
<!-- 212.103: consolidate round recovery into the existing yellow panel; no database/global-rule changes. -->
<!-- 212.102: shared validated Organizer tee options; no database/schema/global-rule changes. -->
## 192.16.260929 — migration 0158

Apply 0158_profile_privilege_boundaries.sql to staging first. It closes privileged profile INSERT and non-owner direct admin updates. Existing accounts are unchanged. Do not edit or reapply earlier migrations. Full release gates remain required.

## 192.15.260928 — migration 0157 (manifest regenerated)
record_course_api_check must accept the SERVICE-ROLE monitor, not only signed-in users. 0156 is
unchanged from its released form: a migration already on main is immutable, and the earlier
instruction to "re-apply 0156" was wrong. 0157 is the replacement.

## 192.12.260918 — no new migration
Ledger URL normalisation. 0156 still required.

## 192.11.260917 — no new migration
Contract job reuses the existing production secrets. 0156 still required.

## 192.10.260917 — no new migration
Documentation of the ledger secret scope. 0156 still required.

## 192.9.260917 — migration 0156
Course-check ledger and daily claim RPC. New table, two functions.

## 192.8.260907 — no new migration
Daily-quota recognition and honest backfill errors. 0155 still required.

## 192.7.260907 — no new migration
Admin raw passthrough for provider diagnosis. 0155 still required.

## 192.6.260907 — no new migration
Course proxy reports the upstream failure reason. 0155 still required.

## 192.5.260907 — no new migration
Contract monitor progress output. 0155 still required.

## 192.4.260907 — no new migration
Diagnostic contract failure message. 0155 still required.

## 192.3.260907 — no new migration
Share card labels the playing handicap. 0155 still required.

## 192.2.260907 — no new migration
Comment correction only. 0155 still required.

## 192.1.260907 — no new migration
Stroke dots honour the game's allowance. 0155 still required.

## 192.0.260907 — migration 0155
Public RPCs prefer a manual course handicap. Replaces two functions; no schema change.

## 191.1.260907 — no migration
GolfCourseAPI contract tolerance. 0154 remains current.

## 191.0.260907 — no migration
Share-card handicap fix and the half-stroke engine. 0154 remains current.

## 190.5.260907 — no migration
Removed the misleading matchStrokeLabel default. 0154 remains current.

## 190.4.260907 — no migration
New round screen: course-handicap basis and manual override. 0154 remains current.

## 190.3.260907 — no migration
Lazy Supabase client so the build needs no credentials. 0154 remains current.

## 190.2.260907 — no migration
Singles match card layout. 0154 remains current.

## 190.1.260907 — no migration
Match card labelling and column consistency. 0154 remains current.

## 190.0.260907 — migration 0154
Manual course handicaps for solo rounds. Columns only; no new functions.

## 189.2.260907 — re-apply 0153
Restores 0149's full match-length contract, which the first cut of 0153 had dropped. Idempotent.

## 189.1.260907 — no migration
Manual course handicap simulation. 0153 remains current.

## 189.0.260907 — migration 0153
Manual course handicaps: source column, audit columns, and clearing them on a hole-count change.

## 188.5.260907 — no migration
Cup page presentation. 0152 remains current.

## 188.4.260907 — re-apply 0152
Competition roster added to the public payload. Amended in place; idempotent.

## 188.3.260907 — no migration
Cup match row progress and final state. 0152 remains current.

## 188.2.260907 — re-apply 0152
is_admin() called with an argument; amended in place. Idempotent.

## 188.1.260907 — no migration
Cup share toggle in the organizer UI. 0152 remains current.

## 188.0.260907 — migration 0152
Competition share token, set_competition_share, get_live_competition. Adds one column; two new functions.

## 187.3.260907 — no migration
Alternate Shot side scorecards on the share page. 0151 remains current.

## 187.2.260907 — no migration
Alternate Shot close-out unification and share-page standings. 0151 remains current.

## 187.1.260907 — no migration
Stroke glyph box alignment. 0151 remains current.

## 187.0.260907 — migration 0151
Alternate Shot side scores and guest players in the live-share payload. Replaces get_live_scorecard; no schema change.

## 186.3.260907 — no migration
Legend label scope and personal-card glyph row spacing. 0150 remains current.

## 186.2.260907 — no migration
Stableford box colour and a named chip token. 0150 remains current.

## 186.1.260907 — no migration
Stroke-dot colour weights and Stableford box text colour. 0150 remains current.

## 186.0.260907 — no migration
Stroke-dot shapes, colours and slot layout. Display only. 0150 remains current.

## 185.1.260907 — no migration
Share-page scorecard layout and stroke bases. 0150 remains current.

## 185.0.260907 — no migration
Stroke-dot basis scheme and Trifecta singles strokes. Display + lib only. 0150 remains current.

## 184.1.260906 — no migration
Close-out unification and two live-route display fixes. 0150 remains current.

## 184.0.260906 — no migration
Live-share scoring extraction and CI parity harness. 0150 remains current.

## 183.1.260906 — no migration
Results/live-share display and the live page's Trifecta singles source. 0150 remains current.

## 183.0.260906 — migration 0150
Trifecta single rule: `games.trifecta_scoring` default → 'match', backfill, CHECK (match or null). Column kept for the Ryder Cup trigger (0146).

## 182.2.260906 — no migration
Trifecta player-card scoring correction only; TypeScript, rendered test and CI guard. 182.1 was never deployed. 0149 remains current.

## 178.25.260830 — no migration
CI-only production migration-parity URL hardening. 0140/0141 are unchanged.

> **178.18.260829:** No migration. Environment-contract documentation only; database contract unchanged.

> **178.17.260829:** No migration. React hook-order correction and source guard only; database contract unchanged.
> **178.16.260829:** No migration. TypeScript-only correction to the Alternate Shot individual-card exclusion; database contract unchanged.

> **178.15.260829:** No migration. Release infrastructure now mechanically verifies the live staging/Production `schema_migrations` ledgers against the committed migration chain and fails if this checklist is stale.
> **178.14.260829:** No migration. Alternate Shot team-card/side-game presentation correction only.
> **178.13.260829:** No migration. CI assertion-baseline/documentation-only correction; Alternate Shot scoring code is unchanged from 178.12.

# Migrations run-ledger

Migrations are applied **by hand** in the Supabase SQL editor, in filename order. From migration 0113 onward, `public.schema_migrations` is the database source of truth; this file remains the human checklist and release notes.

Regenerate after shipping (adds new files, keeps ticks and the notes block):
`python3 ci/gen-migrations-checklist.py`

Confirm database-applied state with:
`select id, applied_at from public.schema_migrations order by id;`

Total: 223 migrations. Unchecked = not yet confirmed applied in this checklist.

## Checklist (oldest → newest)

- [x] 0014_round_clock.sql
- [x] 0015_multiuse_group_invites.sql
- [x] 0016_trifecta.sql
- [x] 0017_notifications_lockdown.sql
- [x] 0018_live_scorecard.sql
- [x] 0019_avatars.sql
- [x] 0020_analytics.sql
- [x] 0021_live_teams_stats.sql
- [x] 0022_scorecard_ownership.sql
- [x] 0023_reset_game_scores.sql
- [x] 0024_trifecta_scoring.sql
- [x] 0025_group_roster.sql
- [x] 0026_post_game_rounds.sql
- [x] 0027_admin_group_oversight.sql
- [x] 0028_admin_support_session.sql
- [x] 0029_admin_delete_group.sql
- [x] 0030_default_group.sql
- [x] 0031_admin_game_repair.sql
- [x] 0032_admin_merge_users_groups.sql
- [x] 0033_lock_privileged_profile_columns.sql
- [x] 0034_enforce_ban_in_access.sql
- [x] 0035_stroke_basis.sql
- [x] 0036_skins_mode.sql
- [x] 0037_feedback.sql
- [x] 0038_auth_blocklist.sql
- [x] 0039_support_session_expiry.sql
- [x] 0040_score_validation.sql
- [x] 0041_live_stroke_trifecta.sql
- [x] 0042_score_audit.sql
- [x] 0043_round_game_unique.sql
- [x] 0044_post_game_rounds_fix.sql
- [x] 0045_post_group_rounds.sql
- [x] 0046_structure_stash.sql
- [x] 0047_live_avatar.sql
- [x] 0048_money.sql
- [x] 0049_expense_payers.sql
- [x] 0050_expense_audit.sql
- [x] 0051_group_activity.sql
- [x] 0052_group_pay_roster.sql
- [x] 0053_leg_config.sql
- [x] 0054_money_simplify.sql
- [x] 0055_zelle.sql
- [x] 0056_expense_source.sql
- [x] 0057_tee_times.sql
- [x] 0058_rounds_soft_delete.sql
- [x] 0059_game_players_bets.sql
- [x] 0060_tee_seq.sql
- [x] 0061_guest_sponsor_groups.sql
- [x] 0062_repair_column_defaults.sql
- [x] 0063_guest_per_expense_sponsor.sql
- [x] 0065_bet_guest_payers.sql
- [x] 0066_bet_guest_source_game.sql
- [x] 0067_save_hole_stats.sql
- [x] 0068_analytics_v2.sql
- [x] 0069_push_subscriptions.sql
- [x] 0070_push_events.sql
- [x] 0071_title_case_names.sql
- [x] 0072_profiles_readable_by_comembers.sql
- [x] 0073_push_events_more.sql
- [x] 0074_tee_reminders.sql
- [x] 0075_tee_time_roles.sql
- [x] 0076_holes_unique.sql
- [x] 0077_holes_upsert.sql
- [x] 0078_admin_engagement.sql
- [x] 0079_achievements.sql
- [x] 0080_player_cards.sql
- [x] 0081_nudges.sql
- [x] 0082_group_cards_live_rounds.sql
- [x] 0083_ops_autofinish_and_funnel.sql
- [x] 0084_admin_todos.sql
- [x] 0085_admin_list_users_real_rounds.sql
- [x] 0086_admin_group_overview_real_rounds.sql
- [x] 0087_admin_engagement_real_rounds.sql
- [x] 0088_power_users.sql
- [x] 0089_install_capture.sql
- [x] 0090_admin_stat_users.sql
- [x] 0091_admin_extra_stats.sql
- [x] 0092_friction_ledger.sql
- [x] 0093_flights_oneoff.sql
- [x] 0094_clear_notifications.sql
- [x] 0095_notifications_retention.sql
- [x] 0096_analytics_eastern_day.sql
- [x] 0097_power_users_eastern_day.sql
- [x] 0098_group_cards_show_basics.sql
- [x] 0099_admin_sandbaggers.sql
- [x] 0100_admin_sandbaggers_club.sql
- [x] 0101_admin_sandbaggers_system_only.sql
- [x] 0102_owner_system_admins.sql
- [x] 0103_game_autocomplete.sql
- [x] 0104_admin_stale_games.sql
- [x] 0105_admin_delete_stale_game.sql
- [x] 0106_test_groups.sql
- [x] 0107_admin_wipe_group.sql
- [x] 0108_admin_stat_users_avatars.sql
- [x] 0109_play_date_when_scored.sql
- [x] 0110_games_always_scored_date.sql
- [x] 0111_money_audit.sql
- [x] 0112_events.sql
- [x] 0113_migration_ledger.sql
- [x] 0114_settlement_events.sql
- [x] 0115_settlement_frozen_event.sql
- [x] 0116_money_permissions.sql
- [x] 0117_settlement_dedup.sql
- [x] 0118_settlement_allocations.sql
- [x] 0119_expenses_soft_delete.sql
- [x] 0120_teetimes_realtime.sql
- [x] 0121_money_clean_slate.sql
- [x] 0122_side_contests.sql
- [x] 0123_api_hardening.sql
- [x] 0124_course_freshness.sql
- [x] 0125_course_freshness_authorization.sql
- [x] 0126_course_freshness_use_canonical_auth.sql
- [x] 0127_system_function_lockdown.sql
- [x] 0128_rate_limit.sql
- [x] 0130_workflow_atomicity.sql
- [x] 0131_workflow_retry_and_review_atomicity.sql
- [x] 0132_course_schema_reconciliation_and_privilege_hardening.sql
- [x] 0133_testing_and_money_atomicity.sql
- [x] 0134_fix_bet_rpc_ambiguous_id.sql
- [x] 0135_ledger_backfill.sql
- [x] 0136_core_rls_helpers.sql
- [x] 0137_core_rls_baseline.sql
- [x] 0138_change_game_course_before_scoring.sql
- [x] 0139_nine_hole_round_basis.sql
- [x] 0140_alt_shot_side_scores.sql
- [x] 0141_alt_shot_clear_tombstones.sql
- [x] 0142_team_competitions.sql
- [x] 0143_competition_schedule_contract.sql
- [x] 0144_authorization_hardening.sql
- [x] 0145_competition_lifecycle.sql
- [ ] 0146_ryder_cup_trifecta.sql
- [ ] 0147_ryder_cup_trifecta_draft_groups.sql
- [ ] 0148_delete_competition_session_game.sql
- [ ] 0149_change_game_match_length.sql
- [ ] 0150_trifecta_single_rule.sql
- [ ] 0151_live_alt_shot_and_guests.sql
- [ ] 0152_competition_share.sql
- [ ] 0153_manual_course_handicap.sql
- [ ] 0154_round_manual_course_handicap.sql
- [ ] 0155_live_manual_course_handicap.sql
- [ ] 0156_course_api_checks.sql
- [ ] 0157_course_api_check_service_role.sql
- [ ] 0158_profile_privilege_boundaries.sql
- [ ] 0159_personal_round_persistence.sql
- [ ] 0160_personal_round_payload_contract.sql
- [ ] 0161_game_round_manual_handicap.sql
- [ ] 0162_primary_scoring_device.sql
- [ ] 0163_game_reset_fencing.sql
- [ ] 0164_course_api_check_outcomes.sql
- [ ] 0165_notification_detail.sql
- [ ] 0166_device_heartbeat_and_scheduled_freshness.sql
- [ ] 0167_course_review_queue.sql
- [ ] 0168_course_owner_groups.sql
- [ ] 0169_admin_course_status.sql
- [ ] 0170_push_device_health.sql
- [ ] 0171_course_api_check_log.sql
- [ ] 0172_push_delivery_log.sql
- [ ] 0173_live_lineup.sql
- [ ] 0174_game_added_deep_link.sql
- [ ] 0175_game_added_organizer.sql
- [ ] 0176_live_lineup_match_date.sql
- [ ] 0177_lineup_slug.sql
- [ ] 0178_readable_live_links.sql
- [ ] 0179_finish_game_closes_clocks.sql
- [ ] 0180_season_wrapped.sql
- [ ] 0181_season_wrapped_seen.sql
- [ ] 0182_security_posture.sql
- [ ] 0183_course_freshness_integrity.sql
- [ ] 0184_game_structure_atomic.sql
- [ ] 0185_course_freshness_followups.sql
- [ ] 0186_course_versions.sql
- [ ] 0187_course_status_view.sql
- [ ] 0188_game_recap_announce.sql
- [ ] 0189_account_signup_approval.sql
- [ ] 0190_account_merge_remove.sql
- [ ] 0191_season_wrapped_active_only.sql
- [ ] 0192_course_selective_apply.sql
- [ ] 0193_round_summary_email.sql
- [ ] 0194_guest_scoring_by_group.sql
- [ ] 0195_club_reports.sql
- [ ] 0196_account_merge_guards.sql
- [ ] 0197_active_accounts_and_course_baseline.sql
- [ ] 0198_email_and_announcement_hardening.sql
- [ ] 0199_club_requests.sql
- [ ] 0200_support_visit_notice.sql
- [ ] 0201_club_notification_links.sql
- [ ] 0202_admin_reads_clubs.sql
- [ ] 0203_scramble.sql
- [ ] 0204_live_scramble.sql
- [ ] 0205_anon_boundary.sql
- [ ] 0206_member_privileges.sql
- [ ] 0207_policy_review_fixes.sql
- [ ] 0208_player_cards_server_only.sql
- [ ] 0209_scramble_team_handicap.sql
- [ ] 0210_scramble_handicap_methods.sql
- [ ] 0211_scramble_lineup_live.sql
- [ ] 0212_cup_scramble.sql
- [ ] 0213_team_rounds.sql
- [ ] 0214_security_contract_state.sql
- [ ] 0215_course_field_averages.sql
- [ ] 0216_retire_hand_made_functions.sql
- [ ] 0217_log_retention.sql
- [ ] 0218_live_skins_mode.sql
- [ ] 0219_create_game_complete.sql
- [ ] 0220_draft_games_private.sql
- [ ] 0221_group_changes_after_scores.sql
- [ ] 0222_setup_locks_at_server.sql
- [ ] 0223_game_setup_organizer_only.sql
- [ ] 0224_player_rows_match_the_app.sql
- [ ] 0225_organizer_corrects_ended_game.sql
- [ ] 0226_organizer_takes_over_group_scoring.sql
- [ ] 0227_score_owner_at_server.sql
- [ ] 0228_posted_rounds_match_the_app.sql
- [ ] 0229_profile_flags_match_the_app.sql
- [ ] 0230_no_foursomes_outside_team_play.sql
- [ ] 0231_test_clubs_out_of_stats.sql
- [ ] 0232_name_change_reaches_games.sql
- [ ] 0233_club_score_and_report_contracts.sql
- [ ] 0234_daily_stale_games.sql
- [ ] 0235_analytics_quality.sql
- [ ] 0236_confirmed_penalty_tracking.sql
- [ ] 0237_club_round_standings.sql
- [ ] 0238_club_round_standings_year.sql

<!-- NOTES:START -->

- **0064 — intentionally documented numbering gap.** No `0064_*.sql` migration exists in the repository history. Do not invent or apply a synthetic 0064 migration; the sequence continues from 0063 to 0065.

- 0122_side_contests.sql — side contests (CTP/long drive/straightest): game_contests + append-only game_contest_entries + RLS (participant read; writes via SECURITY DEFINER RPCs) + can_see_game/is_game_organizer/create|update|delete_game_contest/log_contest_entry/void_contest_entry. Run after 0121.

- 0123_api_hardening.sql — DB-backed AI usage caps (ai_usage_daily/global + bump_ai_usage) for the now-authenticated /api/analyze-round; revoke record_migration from authenticated. Run after 0122.

- 0124_course_freshness.sql — course_freshness cache + record_course_freshness RPC (daily API freshness check, admin flag). Run after 0123.

- 0125_course_freshness_authorization.sql — authorization fixes for the 0124 RPCs + status CHECK (external security review). Run after 0124. REQUIRED with v176.30+ (client calls the new signature).

- 0126_course_freshness_use_canonical_auth.sql — switches the freshness RPCs to is_group_member/is_group_admin (enforces active + non-banned; fixes removed-member bypass) + status-filters the notification query. Run after 0125. REQUIRED (supersedes 0125 function bodies; same signatures, no client change).

- 0127_system_function_lockdown.sql — admin-gates + input-validates expire_support_sessions; revokes app-role EXECUTE on the pg_cron reapers (purge_old_notifications, send_tee_reminders); tightens finish_stale_rounds/sweep_friction grants. Run after 0126.
- 0128_rate_limit.sql — generic per-user rate limiter (api_rate_limits + bump_rate_limit RPC, RLS-locked); wires /api/courses to 120 lookups/hour/user. Run after 0127.

- **0129 — intentionally skipped/reserved.** There is no `0129_workflow_atomicity.sql` in v177.13. Do not create or apply a 0129 migration for this release. The workflow hardening sequence begins at 0130 to avoid collision with a separately-used production 0129 identifier.

- [x] **0130_workflow_atomicity.sql** — atomic Money/game/group/course workflows + collision-safe tee-time RSVP order. REQUIRED before v177.13.
- [x] **0131_workflow_retry_and_review_atomicity.sql** — retry-safe course corrections + atomic admin review. REQUIRED after 0130.
- [x] **0132_course_schema_reconciliation_and_privilege_hardening.sql** — reconciles course-correction schema, ensures the override upsert key, preserves member-readable SELECT policies, and removes direct browser-role mutation privileges. REQUIRED after 0131.

- [ ] **0133_testing_and_money_atomicity.sql** — v177.14 reliability migration. Ensures `group_courses(group_id, course_id)` has the unique conflict key required by course-correction RPCs; aborts clearly instead of silently deduping if historical duplicates exist. Adds organizer/admin-gated atomic TGC bet post/re-post/un-post RPCs. Its original `save_bet_expense_atomic` body has a runtime ambiguity fixed by 0134; always apply 0134 after 0133. REQUIRED before v177.14.
- [ ] **0134_fix_bet_rpc_ambiguous_id.sql** — staging-proven runtime correction for `save_bet_expense_atomic`; qualifies table `id`/`created_at` references that collide with `RETURNS TABLE(id, created_at)` PL/pgSQL output variables. No schema/data changes. REQUIRED before v177.15.
<!-- NOTES:END -->

"use client";
import { notifyError, notifyInfo } from "@/components/toast";
import { askConfirm, askText } from "@/components/confirm";
import { useAnalyticsRpc, AnalyticsReadStatus } from "@/components/analytics-read";

import { PhoneDiagnosticsPanel } from "@/components/phone-diagnostics";
import { UpdateChecker } from "@/components/app-update-checker";
import { SaveTraceToggle } from "@/components/save-trace-view";
import { StorageMeter } from "@/components/storage-meter";
import { loadClubDirectory, clubDirectorySummary, filterClubDirectory, type ClubDirectorySummary } from "@/lib/club-directory";
import { fetchAll, fetchAllIn, rpcAll } from "@/lib/fetch-all";
import { useScoringDevice } from "@/components/scoring-device";
import { isPrimaryScoringDevice } from "@/lib/scoring-device";
import React, { useEffect, useState, useCallback } from "react";
import { HScroll } from "@/components/hscroll";
import { createClient } from "@/lib/supabase";
import { chBasis } from "@/lib/game-shape";
import { pushGate, subscribeToPush, unsubscribeFromPush, currentPermission, syncPushSubscription } from "@/lib/push";
import { C, titleCaseName, Round, Hole, strokesReceived, stablefordPts, toParStr, fmtDate, played, strokesOf, validateStrokeIndexes, dedupeHoles, TGC_GROUP_ID, effectiveGroupId, runningHandicap, handicapRounds, adjustedGross, roundDifferential, nextRoundOutlook, maxHoleScore } from "@/lib/golf";
import capabilities from "@/lib/capabilities.json";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, LabelList } from "recharts";
import { write, writeAll } from "@/lib/db-write";
import { failureMessage } from "@/lib/errors";
import { buildCustomCourse, Course, CourseHole, courseLabel, loadCoursesForGroup, linkCourseToGroup } from "@/lib/courses";
import { logActivity } from "@/lib/activity";
import { checkCourseFreshness } from "@/lib/course-freshness";
import { CourseHistory } from "@/components/course-history";
import { AdminPlayers } from "@/components/admin-players";
import { AdminStandoutWatch } from "@/components/admin-standout-watch";
import { HeadToHead } from "@/components/head-to-head";
import { AdminClubReport } from "@/components/admin-club-report";
import { AdminClubRequests } from "@/components/admin-club-requests";
import { courseStatus } from "@/lib/course-status";
import { FreshnessDiffList } from "@/components/course-freshness-diff";
import type { FreshnessDiff } from "@/lib/course-diff";
import { diagEnabled, setDiagEnabled, reproduceBug, setReproduceBug, getDiagLog, clearDiagLog } from "@/lib/debuglog";
import { AdminFeedbackTab } from "@/components/feedback";
import { btn, inputStyle, Eyebrow, NumPicker, Avatar, BottomSheet, DifferentialSheet, Segmented } from "@/components/ui";
import { YardageBackfill } from "@/components/yardage-backfill";
import { AchievementsWall } from "@/components/achievements";
import { PlayerCard, PeerCardModal, CardVisibilityToggle, ShareRoundsToggle } from "@/components/player-card";
import { resizeToAvatar } from "@/lib/image";
import { APP_VERSION } from "@/lib/app-version";
import { courseChangeLines, buildCourseChangeSummary, hasMaterialCourseChanges } from "@/lib/course-diff";
import { loadFormDraft, saveFormDraft, clearFormDraft, draftAgeLabel } from "@/lib/form-draft";
import { saveActiveCourseEdit, loadActiveCourseEdit, clearActiveCourseEdit } from "@/lib/draft";
import { SignOutRow } from "@/components/sign-out-row";
import { HelpSearch } from "@/components/help-search";
import { FeedbackForm, type FeedbackPrefill } from "@/components/feedback";

import { ChartAxisTick } from "@/components/charts/axis-tick";
import { chartXAxis, formatChartDate, showCountLabels } from "@/lib/chart-axis";
import { ChartTip, ChartTooltip, DismissableChart } from "@/components/charts/chart-tip";

const supabase = createClient();

// Create an in-app notification for a user. `detail` is the optional second line (0165).
async function notify(userId: string, message: string, detail?: string | null, groupId?: string | null) {
  try { await supabase.rpc("create_notification", { p_recipient: userId, p_message: message, p_detail: detail ?? null, p_group_id: groupId ?? null }); } catch {}
}
// The signed-in person's name as a notification should say it: display name, else email prefix.
// Cached per user id; a notification that says "an admin" when the admin's name is one query
// away is the pattern 0165 removed.
const labelCache = new Map<string, string>();
async function myLabel(user: { id: string; email?: string | null }): Promise<string> {
  const hit = labelCache.get(user.id); if (hit) return hit;
  let name = "";
  try { const { data } = await supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle(); name = (data?.display_name || "").trim(); } catch { /* fall through */ }
  if (!name) name = (user.email || "").split("@")[0] || "An admin";
  labelCache.set(user.id, name); return name;
}

// "3h ago" style relative time.
/**
 * The course handicap a ROUND is scored off. Delegates to chBasis so a round obeys the same rules a
 * game does: a manual figure is used as given and is NOT halved for a nine, while a derived one is.
 * A round carries its own index/slope/rating, so chBasis can still derive when nothing was entered.
 */
const roundCh = (r: Round, holeCount: number) =>
  chBasis(
    {
      handicap_index: r.handicap_index, slope: r.slope, rating: r.rating,
      course_handicap: r.course_handicap, course_handicap_source: r.course_handicap_source,
    },
    r.course_par,
    holeCount,
  );

function timeAgo(iso: string | null): string {
  if (!iso) return "never";
  const s = Math.floor((Date.now() - +new Date(iso)) / 1000);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
// Relative + absolute stamp for notifications, e.g. "3h ago · Jul 13, 3:42 PM".
function notifWhen(iso: string | null): string {
  if (!iso) return "";
  return `${timeAgo(iso)} · ${new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}`;
}


// ================= Push notifications opt-in =================
// Per-type notification preferences. Keys + defaults must match the sender route
// (app/api/push/route.ts DEFAULT_DELIVERY). Only the first three are wired to real
// events today; the rest are shown so the choice persists as those events get added.
const NOTIF_TYPES: { key: string; label: string; def: "push" | "inapp" | "off"; live: boolean }[] = [
  { key: "game_added", label: "You're added to a game", def: "push", live: true },
  { key: "money_owed", label: "You owe money", def: "push", live: true },
  { key: "money_paid", label: "You get paid / settled", def: "push", live: true },
  { key: "tee_reminder", label: "Tee-time reminders", def: "push", live: true },
  { key: "tee_new", label: "New tee time posted", def: "inapp", live: true },
  { key: "bet_posted", label: "A bet is posted in your game", def: "inapp", live: true },
  { key: "game_finished", label: "Game finished / results", def: "inapp", live: true },
  { key: "group_member", label: "New member joins your club", def: "inapp", live: true },
  { key: "course_change", label: "Course data changed at GolfCourseAPI (club admins)", def: "inapp", live: true },
  { key: "season_wrapped", label: "Your season summary is ready (Dec 31)", def: "push", live: true },
  { key: "signup_pending", label: "New sign-up waiting for approval (admins)", def: "push", live: true },
  { key: "signup_reminder", label: "A sign-up has waited 7 days (admins)", def: "push", live: true },
  { key: "signup_admitted", label: "You've been admitted to a club", def: "push", live: true },
  { key: "club_report", label: "Your club's report is ready (July 1 / October 1)", def: "push", live: true },
  { key: "club_decision", label: "Your club request was approved or declined", def: "push", live: true },
  { key: "support_visit", label: "A BNN admin looked in on a club you run (support)", def: "push", live: true },
];

function PushToggle({ user, profile }: { user: any; profile: any }) {
  // 209.3: round-summary emails — on unless the member turns them off (owner decision: opt-out).
  const [roundEmails, setRoundEmails] = useState<boolean>(profile?.round_emails !== false);
  const [emailBusy, setEmailBusy] = useState(false);
  // 210.1: club report emails — their own switch, on unless turned off.
  const [clubEmails, setClubEmails] = useState<boolean>(profile?.club_report_emails !== false);
  const toggleClubEmails = async () => {
    const next = !clubEmails;
    setEmailBusy(true);
    const { error } = await supabase.from("profiles").update({ club_report_emails: next }).eq("id", user.id);
    setEmailBusy(false);
    if (error) { notifyError(`Couldn't save: ${error.message}`); return; }
    setClubEmails(next);
  };
  const toggleRoundEmails = async () => {
    const next = !roundEmails;
    setEmailBusy(true);
    const { error } = await supabase.from("profiles").update({ round_emails: next }).eq("id", user.id);
    setEmailBusy(false);
    if (error) { notifyError(`Couldn't save: ${error.message}`); return; }
    setRoundEmails(next);
  };
  const [gate, setGate] = useState<ReturnType<typeof pushGate> | null>(null);
  const [on, setOn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [prefs, setPrefs] = useState<Record<string, string>>((profile?.push_prefs as Record<string, string>) || {});
  // Test push (0172): proves VAPID keys, the subscription rows and the push service from the device
  // in hand. The result names what happened at each step; "delivered to the push service" means
  // Apple/Google accepted it — the device shows it within seconds unless Focus/Do Not Disturb holds it.
  const [testing, setTesting] = useState(false);
  const [myLog, setMyLog] = useState<Array<{ at: string; type: string | null; delivery: string; endpoints: number; sent: number; failed: number; result: string | null }> | null>(null);
  // bounded: function returns at most 50 (latest deliveries)
  const loadMyLog = useCallback(async () => { try { const { data } = await supabase.rpc("my_push_delivery_log", { p_limit: 8 }); setMyLog((data || []) as any); } catch { setMyLog([]); } }, []);
  useEffect(() => { void loadMyLog(); }, [loadMyLog]);
  useEffect(() => {
    const g = pushGate(); setGate(g);
    // Reflect the true server state: on = a live browser subscription that's actually saved.
    // syncPushSubscription re-saves it (healing a rotated endpoint) and reports enrollment,
    // so the toggle can't show a false "on" when the server has no row for this device.
    if (g === "ready" && user?.id) syncPushSubscription(user.id).then(setOn);
    else setOn(false);
  }, [user?.id]);
  useEffect(() => { setPrefs((profile?.push_prefs as Record<string, string>) || {}); }, [profile?.push_prefs]);
  if (gate === null) return null;

  const enable = async () => {
    setBusy(true); setMsg(null);
    const r = await subscribeToPush(user.id);
    setBusy(false);
    if (r.ok) { setOn(true); setMsg("Notifications are on for this device."); return; }
    if (r.reason === "denied") setMsg(currentPermission() === "denied"
      ? "Notifications are blocked in your device/browser settings — enable them for Birdie Num Num there, then try again."
      : "Permission wasn't granted.");
    else if (r.reason === "unsupported") setMsg("This device can't receive web push. On iPhone, install to the Home Screen from Safari first.");
    else if (r.reason === "unconfigured") setMsg("Push isn't configured on the server yet.");
    else setMsg("Couldn't turn on notifications — please try again.");
  };
  const disable = async () => { setBusy(true); await unsubscribeFromPush(); setOn(false); setBusy(false); setMsg("Notifications are off for this device."); };
  const sendTest = async () => {
    setTesting(true); setMsg(null);
    try {
      const r = await fetch("/api/push/test", { method: "POST" });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg(j?.error || "Couldn't send a test push.");
      else if (j.endpoints === 0) setMsg("No enrolled devices on your account — turn notifications on above, then test again.");
      else setMsg(`Test push: ${j.result}. ${j.sent > 0 ? "It should appear on your enrolled device(s) within a few seconds." : ""}`);
    } catch { setMsg("Couldn't reach the server to send a test push."); }
    setTesting(false); await loadMyLog();
  };

  const setPref = async (key: string, val: "push" | "inapp" | "off") => {
    const next = { ...prefs, [key]: val };
    setPrefs(next);
    try { await supabase.from("profiles").update({ push_prefs: next }).eq("id", user.id); } catch { /* ignore */ }
  };
  const seg = (key: string, def: string) => {
    const cur = prefs[key] ?? def;
    const opts: { v: "push" | "inapp" | "off"; l: string }[] = [{ v: "push", l: "Push" }, { v: "inapp", l: "In-app" }, { v: "off", l: "Off" }];
    return (
      <div style={{ display: "flex", gap: 4 }}>
        {opts.map((o) => {
          const active = cur === o.v;
          return (
            <button key={o.v} onClick={() => setPref(key, o.v)}
              style={{ padding: "9px 9px", borderRadius: 6, fontSize: 11, fontWeight: 700, cursor: "pointer",
                border: `1px solid ${active ? (o.v === "off" ? "#8B6A62" : C.gold) : C.borderCard}`,
                background: active ? (o.v === "off" ? "#6B2F28" : C.gold) : "transparent",
                color: active ? (o.v === "off" ? "#F6DEDB" : "#16201C") : C.sage }}>
              {o.l}
            </button>
          );
        })}
      </div>
    );
  };

  return (
    <div style={{ background: C.greenLight, borderRadius: 12, padding: 14, marginTop: 10 }}>
      <div style={{ color: C.cream, fontSize: 13, fontWeight: 700 }}>🔔 Notifications</div>
      {gate === "install_ios" ? (
        <div style={{ marginTop: 6 }}>
          <div style={{ background: "#2A1512", border: `1px solid ${C.birdie}`, borderRadius: 10, padding: "10px 11px" }}>
            <div style={{ color: "#F0997B", fontSize: 12, fontWeight: 800, lineHeight: 1.4 }}>⚠️ iPhone: add to your Home Screen first, or notifications won&apos;t work</div>
            <div style={{ color: "#E8C9C2", fontSize: 12, lineHeight: 1.5, marginTop: 6 }}>
              Phone notifications only work when Birdie Num Num is installed to your Home Screen <b>from Safari</b> and opened from that icon. Opened in any browser — including Safari itself — your phone will not receive them.
            </div>
          </div>
          <div style={{ color: C.sage, fontSize: 12, lineHeight: 1.7, marginTop: 10 }}>
            <div>1. Open Birdie Num Num in <b>Safari</b>.</div>
            <div>2. Tap the <b>Share</b> icon (the square with an up-arrow).</div>
            <div>3. Choose <b>Add to Home Screen</b>.</div>
            <div>4. Open BNN from that new <b>Home-Screen icon</b>.</div>
            <div>5. Come back here and tap <b>Turn on notifications</b>.</div>
          </div>
          <div style={{ color: C.sage, fontSize: 11, marginTop: 8 }}>An icon added from Chrome or any other browser won&apos;t work — it must be added from Safari.</div>
        </div>
      ) : gate === "unsupported" ? (
        <div style={{ color: C.sage, fontSize: 12, marginTop: 6 }}>This browser can't receive push notifications. Try Chrome on Android/desktop, or install to the Home Screen on iPhone via Safari.</div>
      ) : gate === "unconfigured" ? (
        <div style={{ color: C.sage, fontSize: 12, marginTop: 6 }}>Notifications aren't switched on for the app yet — check back soon.</div>
      ) : (
        <>
          <div style={{ color: C.sage, fontSize: 12, lineHeight: 1.5, marginTop: 4 }}>
            Get a phone notification when you're added to a game, when you owe or get paid, and more — even when the app is closed.
          </div>
          <button onClick={on ? disable : enable} disabled={busy} style={{ ...btn(!on), marginTop: 10, fontSize: 13, opacity: busy ? 0.62 : 1 }}>
            {busy ? "…" : on ? "Turn off on this device" : "Turn on notifications"}
          </button>
        </>
      )}
      <button onClick={sendTest} disabled={testing} style={{ ...btn(false), marginTop: 8, fontSize: 13, opacity: testing ? 0.62 : 1 }}>Send a test push to my devices</button>
      {msg && <div style={{ color: C.sage, fontSize: 12, marginTop: 8 }}>{msg}</div>}
      {myLog && myLog.length > 0 && (
        <div style={{ marginTop: 12 }}>
          <div style={{ color: C.sage, fontSize: 11, fontWeight: 800, letterSpacing: 1.2, marginBottom: 4 }}>YOUR RECENT PUSHES</div>
          {myLog.map((l, i) => (
            <div key={i} style={{ color: l.sent > 0 ? C.cream : C.sage, fontSize: 12, lineHeight: 1.5 }}>
              {new Date(l.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} · {l.type || "—"} · {l.result}
            </div>
          ))}
        </div>
      )}
      {myLog && myLog.length === 0 && <div style={{ color: C.sage, fontSize: 12, marginTop: 10 }}>No push has been attempted to you since the delivery log began.</div>}

      <div data-round-emails style={{ marginTop: 14, borderTop: `1px solid ${C.borderGreen}`, paddingTop: 10 }}>
        <Eyebrow>ROUND SUMMARY EMAILS</Eyebrow>
        <div style={{ color: C.sage, fontSize: 12, lineHeight: 1.5, marginTop: 4 }}>
          An email about an hour after each round: your scorecard and stats — and for a game, the group&apos;s recap. Sent to {user?.email || "your sign-in email"}.
        </div>
        <button type="button" onClick={toggleRoundEmails} disabled={emailBusy} aria-pressed={roundEmails}
          style={{ ...btn(!roundEmails), marginTop: 8, fontSize: 13, opacity: emailBusy ? 0.62 : 1 }}>
          {emailBusy ? "…" : roundEmails ? "On — turn off round summaries" : "Off — turn on round summaries"}
        </button>
        <div style={{ color: C.sage, fontSize: 12, lineHeight: 1.5, marginTop: 12 }}>Club report emails — your club&apos;s report on July 1 (January–June) and October 1 (July–September).</div>
        <button type="button" onClick={toggleClubEmails} disabled={emailBusy} aria-pressed={clubEmails} data-club-report-emails
          style={{ ...btn(!clubEmails), marginTop: 8, fontSize: 13, opacity: emailBusy ? 0.62 : 1 }}>
          {emailBusy ? "…" : clubEmails ? "On — turn off club report emails" : "Off — turn on club report emails"}
        </button>
      </div>

      {gate !== "unconfigured" && (
        <div style={{ marginTop: 14, borderTop: `1px solid ${C.borderGreen}`, paddingTop: 10 }}>
          <Eyebrow>WHAT TO NOTIFY ME ABOUT</Eyebrow>
          <div style={{ color: C.sage, fontSize: 11, marginTop: 3 }}>Push buzzes your phone (needs notifications on for the device); In-app just shows in the bell.</div>
          {NOTIF_TYPES.map((t) => (
            <div key={t.key} style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 9 }}>
              <div style={{ flex: 1, color: C.cream, fontSize: 12 }}>
                {t.label}{!t.live && <span style={{ color: C.sage, fontSize: 11 }}> · soon</span>}
              </div>
              {seg(t.key, t.def)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ================= Profile panel (+ admin) =================
// Profile-tab handicap summary. Reads the SAME rounds prop + SAME engine as the dashboard
// (runningHandicap over handicapRounds), so the index can never diverge between tabs, and it
// recalculates automatically whenever a round is added/deleted (deletes refresh the rounds state).
export function HandicapSummary({ rounds, profile, onOpen }: { rounds: Round[]; profile: any; onOpen?: (r: Round) => void }) {
  const hcp = React.useMemo(() => runningHandicap(handicapRounds(rounds)), [rounds]);
  const rows = React.useMemo(() => {
    const eligible = handicapRounds(rounds)
      .filter((r) => roundDifferential(r) != null)
      .sort((a, b) => +new Date(b.played_at) - +new Date(a.played_at))
      .slice(0, 20);
    return eligible.map((r, i) => ({
      r,
      date: new Date(r.played_at).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      ag: adjustedGross(r),
      diff: roundDifferential(r) as number,
      used: hcp.recentDetail[i]?.used ?? false,
    }));
  }, [rounds, hcp.recentDetail]);

  const official = profile?.handicap_index != null ? Number(profile.handicap_index) : null;
  const idx = hcp.index;
  const delta = idx != null && official != null ? Math.round(Math.abs(idx - official) * 10) / 10 : null;

  // "What your next round does" — see nextRoundOutlook in lib/golf.ts. Only shown once you have more than
  // 20 acceptable rounds (posting another rolls the oldest of the current 20 out of the window).
  const next = React.useMemo(() => nextRoundOutlook(rounds), [rounds]);
  const [calcFor, setCalcFor] = React.useState<Round | null>(null);

  return (
    <div style={{ background: C.greenMid, borderRadius: 14, padding: 16, marginTop: 16 }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 10 }}>
        <div>
          <Eyebrow style={{ margin: 0 }}>Handicap index</Eyebrow>
          <div style={{ color: C.sage, fontSize: 11, marginTop: 2 }}>App estimate{idx != null ? ` · best ${hcp.used} of last ${rows.length}` : ""}</div>
        </div>
        <div style={{ color: C.cream, fontSize: 36, fontWeight: 800, fontFamily: "Georgia, serif", lineHeight: 1 }}>{idx != null ? idx.toFixed(1) : "—"}</div>
      </div>

      {official != null && (
        <div style={{ background: C.greenLight, borderRadius: 10, padding: "9px 12px", marginTop: 10 }}>
          <div style={{ color: C.sage, fontSize: 12 }}>Your entered index <span style={{ color: C.cream, fontWeight: 700 }}>{official.toFixed(1)}</span></div>
          {delta != null && (
            <div style={{ color: delta >= 1 ? C.overRedDark : C.sage, fontSize: 11, marginTop: 2 }}>
              {delta >= 1 ? `Differs from the app estimate by ${delta.toFixed(1)} — check your rounds are in sync with GHIN` : "In line with the app estimate"}
            </div>
          )}
        </div>
      )}

      <div style={{ color: C.sage, fontSize: 11, lineHeight: 1.5, marginTop: 8 }}>
        This is an app calculation for reference. Your official GHIN Handicap Index is the system of record and supersedes it.
      </div>

      {next && (
        <div style={{ background: C.greenLight, border: `1px solid rgba(201,162,39,0.35)`, borderRadius: 12, padding: "11px 13px", marginTop: 10 }}>
          <div style={{ color: C.gold, fontSize: 11, letterSpacing: 0.6, textTransform: "uppercase", fontWeight: 700 }}>Your next round</div>
          <div style={{ color: C.cream, fontSize: 12.5, marginTop: 6, lineHeight: 1.5 }}>
            Counts toward your index if its differential is under <span style={{ fontWeight: 800, fontFamily: "Georgia, serif" }}>{next.threshold.toFixed(1)}</span>.
          </div>
          <div style={{ color: C.sage, fontSize: 11.5, marginTop: 5, lineHeight: 1.5 }}>
            {next.indexIfHigher === next.current
              ? `If it's higher, your index stays ${next.current.toFixed(1)}.`
              : `If it's higher, your index moves to ${next.indexIfHigher.toFixed(1)} (from ${next.current.toFixed(1)}) as your oldest round rolls off.`}
          </div>
          <div style={{ color: C.sage, fontSize: 11, marginTop: 6 }}>
            Rolling off: <span style={{ color: C.sage }}>{new Date(next.rollOff.played_at).toLocaleDateString(undefined, { month: "short", day: "numeric" })} · {next.rollOff.course || "—"} · {(roundDifferential(next.rollOff) as number).toFixed(1)}</span>
          </div>
        </div>
      )}

      {idx == null ? (
        <div style={{ color: C.sage, fontSize: 12, marginTop: 12 }}>
          Need at least 3 rounds with a course rating and slope to estimate an index. You have {hcp.total}.
        </div>
      ) : (
        <>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", margin: "14px 0 6px" }}>
            <Eyebrow style={{ margin: 0 }}>Scoring record</Eyebrow>
            <div style={{ color: C.sage, fontSize: 11 }}>Best {hcp.used} of last {rows.length}</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 4px", borderBottom: `1px solid rgba(255,255,255,0.10)` }}>
            <div style={{ width: 7, flexShrink: 0 }} />
            <div style={{ width: 48, flexShrink: 0, color: C.sage, fontSize: 11 }}>Date</div>
            <div style={{ flex: 1, color: C.sage, fontSize: 11 }}>Course · tee (CR/slope)</div>
            <div style={{ width: 38, textAlign: "right", color: C.sage, fontSize: 11 }}>Adj</div>
            <div style={{ width: 44, textAlign: "right", color: C.sage, fontSize: 11 }}>Diff</div>
            {onOpen && <div style={{ width: 14, flexShrink: 0 }} />}
          </div>
          {rows.map(({ r, date, ag, diff, used }) => (
            <div key={r.id} onClick={onOpen ? () => onOpen(r) : undefined} role={onOpen ? "button" : undefined} tabIndex={onOpen ? 0 : undefined}
              onKeyDown={onOpen ? (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onOpen(r); } } : undefined}
              style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 4px", borderBottom: `1px solid rgba(255,255,255,0.10)`, opacity: used ? 1 : 0.62, background: used ? "rgba(228,207,134,0.06)" : "transparent", cursor: onOpen ? "pointer" : "default" }}>
              <div style={{ width: 7, height: 7, borderRadius: 6, background: used ? C.gold : "transparent", flexShrink: 0 }} />
              <div style={{ width: 48, flexShrink: 0, color: C.sage, fontSize: 11 }}>{date}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: C.cream, fontSize: 12.5, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.course || "—"}</div>
                <div style={{ color: C.sage, fontSize: 11, marginTop: 1 }}>{[r.tee_name, r.rating != null && r.slope != null ? `${r.rating}/${r.slope}` : null].filter(Boolean).join(" · ") || "—"}</div>
              </div>
              <div style={{ width: 38, textAlign: "right", color: C.cream, fontSize: 13, fontWeight: 700, fontFamily: "Georgia, serif" }}>{ag != null ? ag : "—"}</div>
              <div onClick={(e) => { e.stopPropagation(); setCalcFor(r); }} role="button" tabIndex={0}
                onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); setCalcFor(r); } }}
                style={{ width: 44, textAlign: "right", color: used ? C.cream : C.sage, fontSize: 13, fontWeight: used ? 800 : 600, fontFamily: "Georgia, serif", cursor: "pointer", textDecoration: "underline dotted", textDecorationColor: C.sage, textUnderlineOffset: 3 }}>{diff.toFixed(1)}</div>
              {onOpen && <span aria-hidden="true" style={{ width: 14, textAlign: "right", color: C.sage, fontSize: 16, flexShrink: 0 }}>›</span>}
            </div>
          ))}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 10, padding: "0 4px" }}>
            <div style={{ width: 7, height: 7, borderRadius: 6, background: C.gold, flexShrink: 0 }} />
            <div style={{ color: C.sage, fontSize: 11, flex: 1 }}>Counts toward index ({hcp.used} lowest differentials)</div>
          </div>
          <div style={{ background: C.greenLight, borderRadius: 10, padding: "9px 12px", marginTop: 8, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ color: C.sage, fontSize: 12 }}>Index = average of {hcp.used} lowest{hcp.adj !== 0 ? `, ${hcp.adj > 0 ? "+" : ""}${hcp.adj} adj` : ""}</div>
            <div style={{ color: C.gold, fontSize: 15, fontWeight: 800, fontFamily: "Georgia, serif" }}>{idx.toFixed(1)}</div>
          </div>
          <div style={{ color: C.sage, fontSize: 11, marginTop: 8, textAlign: "center" }}>Tap any differential to see how it’s calculated.</div>
        </>
      )}
      {calcFor && <DifferentialSheet round={calcFor} onClose={() => setCalcFor(null)} />}
    </div>
  );
}

export function ProfilePanel({ profile, user, onSaved, badgeRefresh = 0, rounds = [], onOpen }: { profile: any; user: any; onSaved: () => void; badgeRefresh?: number; rounds?: Round[]; onOpen?: (r: Round) => void }) {
  const [name, setName] = useState(profile?.display_name || "");
  const [ghin, setGhin] = useState(profile?.ghin_number || "");
  const [phone, setPhone] = useState(profile?.phone || "");
  const [venmo, setVenmo] = useState(profile?.venmo_handle || "");
  const [paypal, setPaypal] = useState(profile?.paypal_handle || "");
  const [zelle, setZelle] = useState(profile?.zelle_handle || "");
  const [idxStr, setIdxStr] = useState(profile?.handicap_index != null ? String(profile.handicap_index) : "");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(profile?.avatar_url || null);
  const [photoBusy, setPhotoBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setName(profile?.display_name || "");
    setGhin(profile?.ghin_number || "");
    setPhone(profile?.phone || "");
    setVenmo(profile?.venmo_handle || "");
    setPaypal(profile?.paypal_handle || "");
    setZelle(profile?.zelle_handle || "");
    setIdxStr(profile?.handicap_index != null ? String(profile.handicap_index) : "");
    setAvatarUrl(profile?.avatar_url || null);
  }, [profile]);

  const pickPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // allow re-picking the same file later
    if (!file) return;
    setPhotoBusy(true); setMsg(null);
    try {
      const blob = await resizeToAvatar(file);
      const path = `${user.id}/avatar.jpg`;
      const up = await supabase.storage.from("avatars").upload(path, blob, { upsert: true, contentType: "image/jpeg" });
      if (up.error) throw new Error(up.error.message);
      const pub = supabase.storage.from("avatars").getPublicUrl(path).data.publicUrl;
      const url = `${pub}?v=${Date.now()}`; // cache-bust so a changed photo shows immediately
      const { error } = await supabase.rpc("set_my_avatar", { p_url: url });
      if (error) throw new Error(error.message);
      setAvatarUrl(url);
      setMsg("Photo updated ✓");
      onSaved();
    } catch (err: any) {
      setMsg("Couldn't update photo: " + (err?.message || "unknown error"));
    } finally {
      setPhotoBusy(false);
    }
  };

  const removePhoto = async () => {
    setPhotoBusy(true); setMsg(null);
    try {
      await supabase.rpc("set_my_avatar", { p_url: null });
      await supabase.storage.from("avatars").remove([`${user.id}/avatar.jpg`]);
      setAvatarUrl(null);
      setMsg("Photo removed ✓");
      onSaved();
    } catch (err: any) {
      setMsg("Couldn't remove photo: " + (err?.message || "unknown error"));
    } finally {
      setPhotoBusy(false);
    }
  };


  const save = async () => {
    if (!name.trim()) { setMsg("Please enter your name so others in your club can recognize you."); return; }
    setSaving(true); setMsg(null);
    const idx = idxStr.trim() === "" ? null : parseFloat(idxStr);
    const { error } = await supabase.from("profiles").update({
      display_name: titleCaseName(name.trim()),
      ghin_number: ghin.trim() || null,
      phone: phone.trim() || null,
      venmo_handle: venmo.trim().replace(/^@/, "") || null,
      paypal_handle: paypal.trim().replace(/^@/, "") || null,
      zelle_handle: zelle.trim() || null,
      handicap_index: idx,
    }).eq("id", user.id);
    setSaving(false);
    if (error) { setMsg(failureMessage("Couldn't save", error)); return; }
    setMsg("Saved ✓");
    onSaved();
  };

  return (
    <div style={{ maxWidth: 560 }}>
      <PlayerCard profile={profile} user={user} rounds={rounds} />
      <CardVisibilityToggle user={user} initial={profile?.show_card !== false} />
      <ShareRoundsToggle user={user} initial={profile?.share_rounds_with_club !== false} />
      <Eyebrow>YOUR PROFILE</Eyebrow>
      <div style={{ background: C.greenLight, borderRadius: 14, padding: 18, marginTop: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, paddingBottom: 16, marginBottom: 16, borderBottom: `1px solid ${C.borderGreen}` }}>
          <Avatar src={avatarUrl} name={name || profile?.display_name || "?"} size={64} />
          <div style={{ flex: 1 }}>
            <div style={{ color: C.cream, fontSize: 13, fontWeight: 700 }}>Profile photo</div>
            <div style={{ color: C.sage, fontSize: 11, marginTop: 2, lineHeight: 1.5 }}>
              Helps your group recognize you on the scorecard. Any photo works — it&apos;s resized automatically.
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
              <label style={{ ...btn(true), fontSize: 12, padding: "7px 12px", cursor: photoBusy ? "default" : "pointer", opacity: photoBusy ? 0.62 : 1 }}>
                {photoBusy ? "Working…" : avatarUrl ? "Change" : "Add photo"}
                <input type="file" accept="image/*" disabled={photoBusy} onChange={pickPhoto} style={{ display: "none" }} />
              </label>
              {avatarUrl && !photoBusy && (
                <button onClick={removePhoto}
                  style={{ background: "transparent", color: C.overRedDark, border: `0.5px solid #7A3A34`, borderRadius: 8, padding: "7px 12px", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                  Remove
                </button>
              )}
            </div>
          </div>
        </div>
        <div>
          <label style={{ color: C.sage, fontSize: 12 }}>Display name <span style={{ color: C.gold }}>(required)</span></label>
          <input style={{ ...inputStyle, marginTop: 6 }} value={name} placeholder="e.g. Amit Sharma" onChange={(e) => setName(e.target.value)} />
        </div>
        <div style={{ marginTop: 14 }}>
          <label style={{ color: C.sage, fontSize: 12 }}>Phone (optional)</label>
          <input style={{ ...inputStyle, marginTop: 6, maxWidth: 220 }} inputMode="tel" placeholder="(555) 123-4567"
            value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
        <div style={{ marginTop: 14, display: "flex", gap: 10, flexWrap: "wrap" }}>
          <div style={{ flex: 1, minWidth: 150 }}>
            <label style={{ color: C.sage, fontSize: 12 }}>Venmo username (optional)</label>
            <input style={{ ...inputStyle, marginTop: 6 }} placeholder="your-venmo" value={venmo} onChange={(e) => setVenmo(e.target.value)} />
          </div>
          <div style={{ flex: 1, minWidth: 150 }}>
            <label style={{ color: C.sage, fontSize: 12 }}>PayPal.me handle (optional)</label>
            <input style={{ ...inputStyle, marginTop: 6 }} placeholder="yourhandle" value={paypal} onChange={(e) => setPaypal(e.target.value)} />
          </div>
        </div>
        <div style={{ marginTop: 14 }}>
          <label style={{ color: C.sage, fontSize: 12 }}>Zelle contact (phone or email, optional)</label>
          <input style={{ ...inputStyle, marginTop: 6 }} placeholder="phone or email you use for Zelle" value={zelle} onChange={(e) => setZelle(e.target.value)} />
        </div>
        <div style={{ color: C.sage, fontSize: 11, marginTop: 6 }}>Used only to pre-fill payments when settling up in Money. Never shared elsewhere.</div>
        <div style={{ marginTop: 14 }}>
          <label style={{ color: C.sage, fontSize: 12 }}>Handicap index (enter manually)</label>
          <input style={{ ...inputStyle, marginTop: 6, maxWidth: 160 }} inputMode="decimal" placeholder="14.2"
            value={idxStr} onChange={(e) => { const v = e.target.value; if (v === "" || /^\d*\.?\d*$/.test(v)) setIdxStr(v); }} />
        </div>
        <div style={{ marginTop: 14 }}>
          <label style={{ color: C.sage, fontSize: 12 }}>GHIN number (optional)</label>
          <input style={{ ...inputStyle, marginTop: 6, maxWidth: 220 }} inputMode="numeric" placeholder="1234567"
            value={ghin} onChange={(e) => setGhin(e.target.value)} />
          <div style={{ color: C.sage, fontSize: 11, marginTop: 4 }}>
            Stored for reference. Automatic handicap import from GHIN isn't connected — enter your index manually for now.
          </div>
        </div>
        <button style={{ ...btn(true), marginTop: 18, opacity: saving ? 0.62 : 1 }} disabled={saving} onClick={save}>{saving ? "Saving…" : "Save profile"}</button>
        {msg && <div style={{ color: C.gold, fontSize: 12, marginTop: 10 }}>{msg}</div>}
      </div>

      <HandicapSummary rounds={rounds} profile={profile} onOpen={onOpen} />

      <AchievementsWall user={user} rounds={rounds} refreshKey={badgeRefresh} />

      <HeadToHead user={user} />

      <PushToggle user={user} profile={profile} />

      <SignOutRow userId={user.id} onSignOut={() => supabase.auth.signOut()} />
    </div>
  );
}

// ================= Admin panel =================
// ★ Shared stat drill-down engine. Any analytics stat calls openStatDrill({stat,title,...});
// the single StatDrawerHost (mounted once) fetches admin_stat_users(stat,arg,date) and lists
// the exact users behind that number. Built once, reused by every stat — existing and new.
type DrillPayload = { stat: string; title: string; cap?: string; arg?: string | null; date?: string | null };
let _openDrill: ((p: DrillPayload) => void) | null = null;
function openStatDrill(p: DrillPayload) { _openDrill?.(p); }

function StatDrawerHost() {
  const [open, setOpen] = useState(false);
  const [payload, setPayload] = useState<DrillPayload | null>(null);
  const read = useAnalyticsRpc(supabase, payload?.stat.startsWith("push_") ? "admin_push_devices" : "admin_stat_users",
    payload?.stat.startsWith("push_") ? { p_kind: payload.stat } : { p_stat: payload?.stat, p_arg: payload?.arg ?? null, p_date: payload?.date ?? null },
    ["name", "detail", "tag"], open && !!payload);
  const rows: any[] | null = read.data;
  const err = read.error;
  useEffect(() => {
    _openDrill = (p) => { setPayload(p); setOpen(true); };
    return () => { _openDrill = null; };
  }, []);
  const close = () => setOpen(false);
  const tagColor = (t: string) => {
    const bad = ["friction", "off", "stale", "lapsed", "deleted", "muted", "in progress"];
    const good = ["on", "installed", "new"];
    if (bad.includes(t)) return { bg: C.birdie, fg: "#fff" };
    if (good.includes(t)) return { bg: C.gold, fg: C.green };
    return { bg: C.greenLight, fg: C.sage };
  };
  return open ? (
    <BottomSheet onClose={close} maxWidth={440} panelStyle={{ background: C.greenMid }} bodyStyle={{ padding: "6px 10px 12px" }}
      header={
        <div style={{ padding: "14px 44px 12px 16px", borderBottom: `1px solid ${C.greenLight}` }}>
          <div style={{ fontFamily: "Georgia, serif", fontSize: 19, fontWeight: 800, color: C.cream }}>{payload?.title || ""}</div>
          {payload?.cap ? <div style={{ color: C.sage, fontSize: 12, marginTop: 2 }}>{payload.cap}</div> : null}
          {rows ? <div style={{ color: C.sage, fontSize: 11, marginTop: 4 }}>{rows.length} {rows.length === 1 ? "user" : "users"}</div> : null}
        </div>
      }>
          <AnalyticsReadStatus {...read} />
          {err && !rows ? null :
           !rows ? <div style={{ color: C.sage, fontSize: 12, padding: 12 }}>Loading…</div> :
           rows.length === 0 ? <div style={{ color: C.sage, fontSize: 12, padding: 12 }}>No users for this metric.</div> :
           rows.map((u: any, i: number) => {
             const tc = u.tag ? tagColor(u.tag) : null;
             return (
               <div key={i} style={{ display: "flex", alignItems: "center", gap: 11, padding: "11px 8px", borderTop: i ? "1px solid rgba(255,255,255,.06)" : "none" }}>
                 <Avatar src={u.avatar_url} name={u.name || "?"} size={28} />
                 <div style={{ minWidth: 0 }}>
                   <div style={{ fontSize: 13, fontWeight: 700, color: C.cream, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{u.name}</div>
                   {u.detail ? <div style={{ fontSize: 11, color: C.sage, marginTop: 1 }}>{u.detail}</div> : null}
                 </div>
                 {tc ? <span style={{ marginLeft: "auto", fontSize: 11, fontWeight: 800, borderRadius: 6, padding: "2px 7px", background: tc.bg, color: tc.fg, whiteSpace: "nowrap" }}>{u.tag === "friction" ? "unfinished" : u.tag}</span> : null}
               </div>
             );
           })}
    </BottomSheet>
  ) : null;
}

// ★ Admin analytics — utilization, feature popularity, health. Reads one JSON
// payload from the is_admin-gated get_admin_analytics() RPC.
// ★ Golf-cadence engagement — reads the is_admin-gated get_admin_engagement() RPC (migration
// 0078). Measures the round (real golf activity) on a weekly cycle, not daily app-opens.
export function AdminEngagement() {
  const read = useAnalyticsRpc(supabase, "get_admin_engagement");
  const e = read.data;
  const [chartWidth, setChartWidth] = useState(0);
  if (!e) return <AnalyticsReadStatus {...read} />;

  const ws: { week: string; golfers: number; rounds: number }[] = e.weekend_series || [];
  const nr: { week: string; new: number; returning: number }[] = e.weekly_new_returning || [];
  const nrData = nr.map((w) => ({ week: w.week, new: w.new || 0, returning: w.returning || 0, total: (w.new || 0) + (w.returning || 0) }));
  const feat = e.feature || { in_game: 0, solo: 0 };
  const featTot = (feat.in_game || 0) + (feat.solo || 0);

  const tile = (n: React.ReactNode, l: string, d?: string) => (
    <div style={{ background: C.greenLight, borderRadius: 12, padding: "10px 12px", flex: 1, minWidth: 92 }}>
      <div style={{ color: C.cream, fontWeight: 800, fontSize: 20, fontFamily: "Georgia, serif" }}>{n}</div>
      <div style={{ color: C.sage, fontSize: 11 }}>{l}</div>
      {d ? <div style={{ color: C.sage, fontSize: 11, marginTop: 2, opacity: 0.8 }}>{d}</div> : null}
    </div>
  );

  return (
    <div style={{ marginTop: 18 }}><AnalyticsReadStatus {...read} />
      <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 16, fontWeight: 700 }}>Engagement — golf cadence</div>
      <div style={{ color: C.sage, fontSize: 11, marginTop: 2, marginBottom: 8 }}>Measured on rounds (the real unit of golf) on a weekly cycle — not daily app-opens.</div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {tile(`${e.wau_mau_pct ?? 0}%`, "WAU / MAU", "weekly stickiness")}
        {tile(e.rounds_per_active_mo ?? 0, "Rounds / golfer", "active, last 28d")}
        {tile(`${e.weekend_share_pct ?? 0}%`, "Weekend share", "Fri–Sun, 90d")}
        {tile(e.active_28d ?? 0, "Active golfers", "logged a round, 28d")}
      </div>

      <div style={{ color: C.sage, fontSize: 12, fontWeight: 700, marginTop: 16, marginBottom: 6 }}>Weekend reach — golfers logging Fri–Sun</div>
      <div style={{ height: 172, background: C.greenLight, borderRadius: 12, padding: "14px 10px 6px" }}>
        {ws.length === 0 ? <div style={{ color: C.sage, fontSize: 12 }}>No rounds yet.</div> : (
          <DismissableChart height="100%" holdDismissed><ResponsiveContainer onResize={(width) => setChartWidth(width)}>
            <BarChart data={ws} margin={{ top: 14, right: 2, left: 2, bottom: 0 }}>
              <XAxis dataKey="week" tick={<ChartAxisTick />} axisLine={{ stroke: C.greenMid }} tickLine={false} {...chartXAxis(ws, "week", "week")} />
              <ChartTooltip wrapperStyle={{ pointerEvents: "auto" }} content={<ChartTip nameMap={{ golfers: "Golfers", new: "New", returning: "Returning" }} fmt={(v: number) => String(v)} heading={(point: { week?: string }) => formatChartDate(point.week)} />} />
              <YAxis allowDecimals={false} tick={{ fill: C.cream, fontSize: 11 }} axisLine={false} tickLine={false} width="auto" tickSize={0} tickMargin={4} />
              <Bar dataKey="golfers" fill={C.gold} radius={[4, 4, 0, 0]} maxBarSize={34} isAnimationActive={false}>
                {showCountLabels(ws.map(w => w.golfers), chartWidth) && <LabelList dataKey="golfers" position="top" fill={C.cream} fontSize={11} fontWeight={700} />}
              </Bar>
            </BarChart>
          </ResponsiveContainer></DismissableChart>
        )}
      </div>

      <div style={{ color: C.sage, fontSize: 12, fontWeight: 700, marginTop: 16, marginBottom: 6 }}>New vs returning golfers, per week</div>
      <div style={{ height: 172, background: C.greenLight, borderRadius: 12, padding: "14px 10px 6px" }}>
        {nr.length === 0 ? <div style={{ color: C.sage, fontSize: 12 }}>No rounds yet.</div> : (
          <DismissableChart height="100%" holdDismissed><ResponsiveContainer onResize={(width) => setChartWidth(width)}>
            <BarChart data={nrData} margin={{ top: 14, right: 2, left: 2, bottom: 0 }}>
              <XAxis dataKey="week" tick={<ChartAxisTick />} axisLine={{ stroke: C.greenMid }} tickLine={false} {...chartXAxis(nrData, "week", "week")} />
              <ChartTooltip wrapperStyle={{ pointerEvents: "auto" }} content={<ChartTip nameMap={{ golfers: "Golfers", new: "New", returning: "Returning" }} fmt={(v: number) => String(v)} heading={(point: { week?: string }) => formatChartDate(point.week)} />} />
              <YAxis allowDecimals={false} tick={{ fill: C.cream, fontSize: 11 }} axisLine={false} tickLine={false} width="auto" tickSize={0} tickMargin={4} />
              <Bar dataKey="new" stackId="a" fill={C.gold} maxBarSize={34} isAnimationActive={false} />
              <Bar dataKey="returning" stackId="a" fill={C.sage} radius={[4, 4, 0, 0]} maxBarSize={34} isAnimationActive={false}>
                {showCountLabels(nrData.map(w => w.total), chartWidth) && <LabelList dataKey="total" position="top" fill={C.cream} fontSize={11} fontWeight={700} />}
              </Bar>
            </BarChart>
          </ResponsiveContainer></DismissableChart>
        )}
      </div>
      <div style={{ display: "flex", gap: 12, marginTop: 6, fontSize: 11, color: C.sage }}>
        <span><span style={{ display: "inline-block", width: 8, height: 8, background: C.gold, borderRadius: 6, marginRight: 4 }} />new</span>
        <span><span style={{ display: "inline-block", width: 8, height: 8, background: C.sage, borderRadius: 6, marginRight: 4 }} />returning</span>
      </div>

      <div style={{ color: C.sage, fontSize: 12, fontWeight: 700, marginTop: 14 }}>How rounds are played (90 days)</div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: C.cream, marginTop: 6 }}><span>In a game</span><span>{feat.in_game || 0}</span></div>
      <div style={{ height: 8, borderRadius: 6, background: C.green, marginTop: 3, overflow: "hidden" }}>
        <div style={{ height: "100%", borderRadius: 6, width: `${featTot > 0 ? Math.round(((feat.in_game || 0) / featTot) * 100) : 0}%`, background: C.gold }} />
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: C.cream, marginTop: 8 }}><span>Solo score entry</span><span>{feat.solo || 0}</span></div>
      <div style={{ height: 8, borderRadius: 6, background: C.green, marginTop: 3, overflow: "hidden" }}>
        <div style={{ height: "100%", borderRadius: 6, width: `${featTot > 0 ? Math.round(((feat.solo || 0) / featTot) * 100) : 0}%`, background: C.sage }} />
      </div>
    </div>
  );
}

// ★ Power users — top 25 by composite engagement score, every metric individually sortable,
// with a churn ("quiet 30d+") signal. (The old "restarts" behaviour badge was removed —
// abandoning/deleting rounds is normal; real data-integrity issues live in Friction review.)
// Reads the is_admin-gated get_power_users() RPC (migration 0088).
type PUCol =
  | "score" | "completed_rounds" | "games_played" | "active_days" | "total_opens"
  | "completion_pct" | "unfinished_rounds" | "deleted_rounds" | "days_since_active";
export function AdminPowerUsers() {
  const [days, setDays] = useState<number | null>(null); // null = all-time
  const [sortCol, setSortCol] = useState<PUCol>("score");
  const [sortDir, setSortDir] = useState<"desc" | "asc">("desc");
  const [avatars, setAvatars] = useState<Record<string, string | null>>({});

  const read = useAnalyticsRpc(supabase, "get_power_users", { p_days: days });
  const rows: any[] | null = read.data;

  // Photos, best-effort: if row-level security lets this admin read the profiles, show avatars;
  // otherwise the Avatar falls back to initials. Never blocks the table.
  useEffect(() => {
    const ids = (rows || []).map((r: any) => r.user_id).filter(Boolean);
    if (!ids.length) return;
    fetchAllIn<any>(supabase, "profiles", "id", ids).then((data: any) => {
      if (data) setAvatars(Object.fromEntries(data.map((p: any) => [p.id, p.avatar_url ?? null])));
    }).catch(() => { /* avatars are decoration — a failed load just shows initials */ });
  }, [rows]);

  const sorted = React.useMemo(() => {
    if (!rows) return [];
    const arr = [...rows];
    arr.sort((a, b) => {
      const av = a[sortCol] ?? -1, bv = b[sortCol] ?? -1;
      return sortDir === "desc" ? bv - av : av - bv;
    });
    return arr;
  }, [rows, sortCol, sortDir]);

  const setSort = (c: PUCol) => {
    if (c === sortCol) setSortDir((d) => (d === "desc" ? "asc" : "desc"));
    else { setSortCol(c); setSortDir("desc"); }
  };


  const cols: { key: PUCol; label: string; title: string }[] = [
    { key: "score", label: "Score", title: "Composite: completed×4 + games×2 + active days×1 + opens×0.1" },
    { key: "completed_rounds", label: "Rnds", title: "Completed rounds (final, not deleted)" },
    { key: "games_played", label: "Games", title: "Qualifying completed games played" },
    { key: "active_days", label: "Days", title: "Days active (opened the app)" },
    { key: "total_opens", label: "Opens", title: "Total app opens" },
    { key: "completion_pct", label: "Cmpl%", title: "Completed participation ÷ completed participation plus open personal rounds" },
    { key: "unfinished_rounds", label: "Unfin", title: "Started but never finished (in-progress)" },
    { key: "deleted_rounds", label: "Del", title: "Soft-deleted rounds (mostly phantom-round cleanup)" },
    { key: "days_since_active", label: "Idle", title: "Days since last active" },
  ];
  const arrow = (c: PUCol) => (c === sortCol ? (sortDir === "desc" ? " ▾" : " ▴") : "");

  return (
    <div style={{ marginTop: 18 }}><AnalyticsReadStatus {...read} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 8 }}>
        <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 16, fontWeight: 700 }}>Power users</div>
        <div style={{ display: "flex", gap: 4 }}>
          {([[null, "All-time"], [90, "90 days"]] as [number | null, string][]).map(([d, lbl]) => (
            <button key={lbl} onClick={() => setDays(d)}
              style={{ fontSize: 11, padding: "9px 10px", borderRadius: 999, border: "none", cursor: "pointer",
                background: days === d ? C.gold : C.greenLight, color: days === d ? C.green : C.cream, fontWeight: 700 }}>
              {lbl}
            </button>
          ))}
        </div>
      </div>
      <div style={{ color: C.sage, fontSize: 11, marginTop: 2, marginBottom: 8 }}>
        Top 25 by composite score — tap a column to sort. <b style={{ color: C.cream }}>quiet</b> = no activity 30d+.
      </div>

      {!rows ? <div style={{ color: C.sage, fontSize: 12 }}>Loading…</div> :
        sorted.length === 0 ? <div style={{ color: C.sage, fontSize: 12 }}>No users yet.</div> : (
        <HScroll maxHeight="70vh" style={{ background: C.greenLight, borderRadius: 12, padding: 4 }}>
          <table style={{ borderCollapse: "collapse", width: "100%", minWidth: 640 }}>
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: "6px 8px", position: "sticky", left: 0, top: 0, zIndex: 3, background: C.greenLight }}>
                  <span style={{ color: C.sage, fontSize: 11, fontWeight: 700 }}>Player</span>
                </th>
                {cols.map((c) => (
                  <th key={c.key} title={c.title} onClick={() => setSort(c.key)}
                    style={{ padding: "6px 8px", textAlign: "right", cursor: "pointer", whiteSpace: "nowrap", position: "sticky", top: 0, zIndex: 2, background: C.greenLight }}>
                    <span style={{ color: c.key === sortCol ? C.gold : C.sage, fontSize: 11, fontWeight: 700 }}>{c.label}{arrow(c.key)}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sorted.map((r) => (
                <tr key={r.user_id} style={{ borderTop: `1px solid ${C.borderGreen}` }}>
                  <td style={{ padding: "6px 8px", position: "sticky", left: 0, zIndex: 1, background: C.greenLight, maxWidth: 160 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 7, minWidth: 0 }}>
                      <Avatar src={avatars[r.user_id]} name={r.display_name || "?"} size={22} enlargeable={false} />
                      <div style={{ color: C.cream, fontSize: 12, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {r.display_name || "—"}
                      </div>
                    </div>
                    {r.churned ? (
                      <div style={{ display: "flex", gap: 4, marginTop: 2 }}>
                        <span style={{ fontSize: 11, color: C.cream, background: C.greenMid, borderRadius: 6, padding: "0 5px", fontWeight: 700 }}>quiet</span>
                      </div>
                    ) : null}
                  </td>
                  {cols.map((c) => {
                    const v = r[c.key];
                    const flagHot = (c.key === "unfinished_rounds" || c.key === "deleted_rounds") && (v || 0) > 0;
                    return (
                      <td key={c.key} style={{ padding: "6px 8px", textAlign: "right", whiteSpace: "nowrap",
                        color: c.key === sortCol ? C.cream : (flagHot ? C.gold : C.sage), fontSize: 12,
                        fontWeight: c.key === "score" ? 800 : 500 }}>
                        {v == null ? "—" : c.key === "score" ? Math.round(v) : c.key === "completion_pct" ? `${v}%` : v}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </HScroll>
      )}
    </div>
  );
}

export function AdminAnalytics() {
  const read = useAnalyticsRpc(supabase, "get_admin_analytics");
  const a = read.data;
  if (!a) return <AnalyticsReadStatus {...read} />;

  const t = a.totals || {}, ac = a.active || {}, f = a.formats || {}, fe = a.features || {}, h = a.health || {}, en = a.engagement || {};
  const series: { day: string; n: number }[] = ac.series || [];

  const tile = (n: React.ReactNode, l: string, d?: string, bg: string = C.greenLight, drill?: { stat: string; cap?: string }) => (
    <div onClick={drill ? () => openStatDrill({ stat: drill.stat, title: l, cap: drill.cap }) : undefined}
      style={{ background: bg, borderRadius: 12, padding: "10px 12px", flex: 1, minWidth: 88, position: "relative", cursor: drill ? "pointer" : "default" }}>
      {drill ? <span style={{ position: "absolute", right: 8, top: 8, color: C.gold, fontSize: 11, fontWeight: 800 }}>who ›</span> : null}
      <div style={{ color: C.cream, fontWeight: 800, fontSize: 20, fontFamily: "Georgia, serif" }}>{n}</div>
      <div style={{ color: C.sage, fontSize: 11 }}>{l}</div>
      {d ? <div style={{ color: "#5BD08A", fontSize: 11, marginTop: 2 }}>{d}</div> : null}
    </div>
  );

  const W = 600, H = 120, pad = 6;
  const max = Math.max(1, ...series.map((s) => s.n));
  const step = series.length > 1 ? (W - pad * 2) / (series.length - 1) : 0;
  const pts = series.map((s, i) => [pad + i * step, H - pad - (s.n / max) * (H - pad * 2)] as [number, number]);
  const line = pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(" ");
  const area = pts.length ? `${line} L${(W - pad).toFixed(1)} ${H - pad} L${pad} ${H - pad} Z` : "";

  const bar = (label: string, n: number, denom: number, color: string, drillStat?: string) => (
    <div key={label} onClick={drillStat ? () => openStatDrill({ stat: drillStat, title: label }) : undefined} style={{ cursor: drillStat ? "pointer" : "default" }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: C.cream, marginTop: 8 }}><span>{label}{drillStat ? <span style={{ color: C.gold, fontSize: 11, fontWeight: 800 }}>  who ›</span> : null}</span><span>{n}</span></div>
      <div style={{ height: 8, borderRadius: 6, background: C.green, marginTop: 3, overflow: "hidden" }}>
        <div style={{ height: "100%", borderRadius: 6, width: `${denom > 0 ? Math.round((n / denom) * 100) : 0}%`, background: color }} />
      </div>
    </div>
  );

  const fmtName: Record<string, string> = { stroke: "Stroke play", scramble: "Scramble", alt_shot: "Alternate shot", stableford: "Stableford", fourball: "Four-ball", match: "Singles match", skins: "Skins", trifecta: "Trifecta" };
  const fmtColors: Record<string, string> = { stableford: "#5BD08A", fourball: "#5AA9E6", match: "#C9A227", skins: "#E0915B", trifecta: "#B084E0" };
  const fmtEntries = (Object.entries(f) as [string, number][]).sort((x, y) => y[1] - x[1]);
  const fmtMax = Math.max(1, ...fmtEntries.map(([, n]) => n));
  const feat: [string, number][] = [["Avatars set", fe.avatars_set || 0], ["Members with saved AI coaching", fe.ai_summaries || 0], ["Live links (now)", fe.live_shared || 0], ["Courses added (30d)", fe.courses_added_30d || 0]];
  const featMax = Math.max(1, ...feat.map(([, n]) => n));

  const hrow = (label: string, val: string, good?: boolean, drill?: { stat: string; cap?: string }) => (
    <div key={label} onClick={drill ? () => openStatDrill({ stat: drill.stat, title: label, cap: drill.cap }) : undefined}
      style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 12, padding: "8px 0", borderTop: `1px solid ${C.borderGreen}`, cursor: drill ? "pointer" : "default" }}>
      <span style={{ color: C.cream, fontSize: 13 }}>{label}{drill ? <span style={{ color: C.gold, fontSize: 11, fontWeight: 800 }}>  who ›</span> : null}</span>
      <span style={{ flexShrink: 0, textAlign: "right", fontWeight: 800, fontSize: 15, color: good === undefined ? C.cream : good ? "#5BD08A" : "#E0796B" }}>{val}</span>
    </div>
  );

  return (
    <div style={{ marginTop: 8 }}><AnalyticsReadStatus {...read} />
      <StatDrawerHost />
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {tile(t.users ?? "—", "Total users", t.users_new_30d ? `+${t.users_new_30d} / 30d` : undefined, C.greenLight, { stat: "users_total", cap: "All active (non-test) users" })}
        {tile(t.active_groups ?? "—", "Active clubs")}
        {tile(t.games ?? "—", "Games created", t.games_30d ? `+${t.games_30d} / 30d` : undefined)}
        {tile(t.rounds ?? "—", "Rounds played", `${t.rounds_30d ? `+${t.rounds_30d} /30d` : "—"}${t.rounds_started ? ` · ${t.rounds_started} started` : ""}`, C.greenLight, { stat: "rounds_done", cap: "Players with completed rounds" })}
      </div>

      <div style={{ background: C.greenLight, borderRadius: 12, padding: 14, marginTop: 10 }}>
        <div style={{ display: "flex", textAlign: "center" }}>
          <div style={{ flex: 1, cursor: "pointer" }} onClick={() => openStatDrill({ stat: "active_dau", title: "Active today", cap: "Users who opened BNN today" })}><div style={{ color: C.gold, fontFamily: "Georgia, serif", fontSize: 26, fontWeight: 800 }}>{ac.dau ?? 0}</div><div style={{ color: C.sage, fontSize: 11 }}>Today · unique</div><div style={{ color: C.sage, fontSize: 11, marginTop: 1 }}>{ac.views_today ?? 0} views · who ›</div></div>
          <div style={{ flex: 1, cursor: "pointer" }} onClick={() => openStatDrill({ stat: "active_wau", title: "Active this week", cap: "Users active in the last 7 days" })}><div style={{ color: C.gold, fontFamily: "Georgia, serif", fontSize: 26, fontWeight: 800 }}>{ac.wau ?? 0}</div><div style={{ color: C.sage, fontSize: 11 }}>This week · unique</div><div style={{ color: C.sage, fontSize: 11, marginTop: 1 }}>{ac.views_7d ?? 0} views · who ›</div></div>
          <div style={{ flex: 1, cursor: "pointer" }} onClick={() => openStatDrill({ stat: "active_mau", title: "Active this month", cap: "Users active in the last 30 days" })}><div style={{ color: C.gold, fontFamily: "Georgia, serif", fontSize: 26, fontWeight: 800 }}>{ac.mau ?? 0}</div><div style={{ color: C.sage, fontSize: 11 }}>This month · unique</div><div style={{ color: C.sage, fontSize: 11, marginTop: 1 }}>{ac.views_30d ?? 0} views · who ›</div></div>
        </div>
        {series.length > 0 && (
          <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", height: 120, marginTop: 12 }}>
            <defs><linearGradient id="aaGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={C.gold} stopOpacity="0.35" /><stop offset="1" stopColor={C.gold} stopOpacity="0" /></linearGradient></defs>
            {area && <path d={area} fill="url(#aaGrad)" />}
            {line && <path d={line} fill="none" stroke={C.gold} strokeWidth={2.5} strokeLinejoin="round" />}
          </svg>
        )}
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: C.sage }}><span>30 days ago</span><span>today</span></div>
        <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
          {tile(ac.avg7 ?? 0, "7-day avg", undefined, C.green)}
          {tile(ac.avg30 ?? 0, "30-day avg", undefined, C.green)}
          {tile(`${ac.stickiness_pct ?? 0}%`, "Stickiness (DAU/MAU)", undefined, C.green)}
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          {tile(t.rounds_per_active_user ?? 0, "Rounds / active user", undefined, C.green)}
          {tile(ac.churn_30d ?? 0, "Lapsed (30–60d, gone)", undefined, C.green, { stat: "lapsed", cap: "Active 30–60d ago, silent since" })}
        </div>
        <div style={{ color: C.sage, fontSize: 11, marginTop: 8 }}>Unique = distinct users; views = total app opens. Test accounts are excluded from all figures. Days run midnight–midnight US Eastern. Trends build over time.</div>
      </div>

      <div style={{ background: C.greenLight, borderRadius: 12, padding: 14, marginTop: 10 }}>
        <div style={{ color: C.sage, fontSize: 12, fontWeight: 700 }}>Games by format</div>
        {fmtEntries.length ? fmtEntries.map(([k, n]) => bar(fmtName[k] || k, n, fmtMax, fmtColors[k] || C.sage)) : <div style={{ color: C.sage, fontSize: 12, marginTop: 6 }}>No games yet.</div>}
        <div style={{ color: C.sage, fontSize: 12, fontWeight: 700, marginTop: 14 }}>Saved settings &amp; records</div>
        {feat.map(([k, n]) => bar(k, n, featMax, "#5AA9E6", k === "Avatars set" ? "avatars_set" : k === "Members with saved AI coaching" ? "ai_summaries" : undefined))}
      </div>

      <div style={{ background: C.greenLight, borderRadius: 12, padding: 14, marginTop: 10 }}>
        {hrow("Game completion · retained lifecycle counts", h.completion_pct == null ? "—" : `${h.completion_pct}%`, true)}
        {hrow("Round completion · excludes deleted records", h.round_completion_pct == null ? "—" : `${h.round_completion_pct}%`, true, { stat: "unfinished", cap: "Users with unfinished personal rounds" })}
        {hrow("Unresolved / deleted unfinished games", h.abandoned_pct == null ? "—" : `${h.abandoned_pct}%`, false)}
        {hrow("Avg scored holes / played card", `${h.avg_holes ?? 0}`)}
        {hrow("First completed round within 7 days", h.activation_cohort?.d ? `${h.activation_cohort.n}/${h.activation_cohort.d} (${h.activation_cohort.pct}%)` : "No mature cohort yet")}
        {hrow("Second completed round within 28 days", h.second_round_cohort?.d ? `${h.second_round_cohort.n}/${h.second_round_cohort.d} (${h.second_round_cohort.pct}%)` : "No mature cohort yet")}
        {hrow("Signups never joined a club", h.never_joined_group_pct == null ? "—" : `${h.never_joined_group_pct}%`, false, { stat: "never_joined_group", cap: "Users with no active club membership" })}
        {hrow("Retention \u2014 week 1", h.retention_w1?.d ? `${h.retention_w1.n}/${h.retention_w1.d} (${h.retention_w1.pct}%)` : "No mature cohort yet")}
        {hrow("Retention \u2014 week 4", h.retention_w4?.d ? `${h.retention_w4.n}/${h.retention_w4.d} (${h.retention_w4.pct}%)` : "No mature cohort yet")}
        <div style={{ color: C.sage, fontSize: 11, marginTop: 8 }}>Participation counts qualifying completed personal and game cards, including team attendance once per member. Activation cohorts have had their full 7/28-day opportunity; retention measures return app activity. Test, deactivated and unavailable accounts and Test clubs are excluded. All days use US Eastern.</div>
      </div>

      <div style={{ background: C.greenLight, borderRadius: 12, padding: 14, marginTop: 10 }}>
        <div style={{ color: C.sage, fontSize: 12, fontWeight: 700, marginBottom: 2 }}>Engagement (last 30 days)</div>
        {hrow("Tee times created", `${en.tee_times_30d ?? 0}`)}
        {hrow("RSVPs recorded", `${en.tee_rsvps_30d ?? 0}`)}
        {hrow("Bets posted (all-time / 30d)", `${en.bets_posted ?? 0} / ${en.bets_30d ?? 0}`)}
        {hrow("Money settled (all-time)", `$${Math.round((en.settled_cents ?? 0) / 100).toLocaleString()}`)}
        {hrow("Invite links created", `${en.invites_created_30d ?? 0}`)}
        {hrow("Joins via invite (all-time)", `${en.joins_via_invite ?? 0}`)}
        {hrow("Games using a group scorer", `${en.group_scoring_pct ?? 0}%`, true)}
      </div>
      <div style={{ background: C.greenLight, borderRadius: 12, padding: 14, marginTop: 10 }}>
        <Eyebrow>ACTIVATION &amp; REPEAT PLAY</Eyebrow>
        {hrow("Clubs playing 2+ games · 90 days", a.funnels?.repeat_clubs?.d ? `${a.funnels.repeat_clubs.n}/${a.funnels.repeat_clubs.d} (${a.funnels.repeat_clubs.pct}%)` : "No qualifying clubs yet")}
        {(a.funnels?.formats || []).map((f: any) => hrow(`${fmtName[f.game_type] || f.game_type} · repeat participants`, `${f.repeat_players}/${f.players}`))}
        <div style={{ color: C.sage, fontSize: 11, marginTop: 8 }}>Repeat = at least two completed games in the same format during the last 90 days. Club repeat counts clubs with qualifying member participation.</div>
        {hrow("Reminded games · sent / resumed / completed", `${a.funnels?.reminders?.sent ?? 0} / ${a.funnels?.reminders?.resumed ?? 0} / ${a.funnels?.reminders?.completed ?? 0}`)}
        <div style={{ color: C.sage, fontSize: 11, marginTop: 8 }}>Unique games with a reminder in the last 90 days. Resumed means a later scoring change; completed means a later game completion. This is an observed association.</div>
        <Eyebrow style={{ marginTop: 16 }}>OBSERVED FEATURE USE · 30 DAYS</Eyebrow>
        {(a.funnels?.feature_use || []).map((f: any) => <div key={f.action} style={{ color: C.cream, fontSize: 12, marginTop: 10 }}>{({ analytics_insights_open: "Scoring insights", analytics_ai_dashboard: "Dashboard coaching", analytics_ai_round: "Round coaching", analytics_live_share: "Live links enabled" } as Record<string, string>)[f.action] || f.action}: {f.uses} actions · {f.users} members · {f.repeat_users} repeat users<div style={{ color: C.sage, fontSize: 11 }}>Returned within 28 days: {f.returned?.d ? `${f.returned.n}/${f.returned.d} (${f.returned.pct}%)` : "waiting for a mature cohort"}</div></div>)}
        {!(a.funnels?.feature_use || []).length && <div style={{ color: C.sage, fontSize: 12 }}>No observed feature actions yet.</div>}
        <div style={{ color: C.sage, fontSize: 11, marginTop: 10 }}>{a.quality?.feature_note}</div>
        <div style={{ color: C.sage, fontSize: 11, marginTop: 10 }}>{a.quality?.lifecycle_note}</div>
      </div>
    </div>
  );
}

export function OpsMetrics() {
  const read = useAnalyticsRpc(supabase, "get_ops_metrics");
  const m = read.data;
  const [sg, setSg] = useState<any[] | null>(null);
  const [sgError, setSgError] = useState(false);
  const [delId, setDelId] = useState<string | null>(null);
  useEffect(() => {
    let live = true;
    rpcAll(supabase, "admin_stale_games", undefined, "game_id").then(({ data, error }: any) => {
      if (!live) return;
      setSgError(!!error);
      if (!error && Array.isArray(data)) setSg(data);
    }, () => { if (live) setSgError(true); });
    return () => { live = false; };
  }, [read.revision]);
  if (!m || Object.keys(m).length === 0) return <AnalyticsReadStatus {...read} />;

  const delStale = async (g: any) => {
    if (g.rounds_posted > 0 || delId) return;
    if (!(await askConfirm(`Delete "${g.name}"? This removes the game and its ${g.players} player row${g.players === 1 ? "" : "s"} app-wide. It can't be undone.`))) return;
    setDelId(g.game_id);
    const { data } = await supabase.rpc("admin_delete_stale_game", { p_game: g.game_id });
    setDelId(null);
    if (data === "deleted") setSg((prev) => (prev || []).filter((x) => x.game_id !== g.game_id));
    else if (data === "has_rounds") notifyError("Skipped — this game has posted rounds, so it wasn't deleted (avoids orphaning player rounds).");
    else if (data === "not_stale") notifyError("Skipped — this game is already completed.");
    else notifyError("Couldn't delete (permission or already gone).");
  };

  const ctr = (c: number, s: number) => (s ? `${Math.round((100 * c) / s)}% click-through` : "no impressions yet");
  const tile = (n: React.ReactNode, l: string, d?: string) => (
    <div style={{ background: C.greenLight, borderRadius: 12, padding: "10px 12px", flex: 1, minWidth: 92 }}>
      <div style={{ color: C.cream, fontWeight: 800, fontSize: 20, fontFamily: "Georgia, serif" }}>{n}</div>
      <div style={{ color: C.sage, fontSize: 11 }}>{l}</div>
      {d ? <div style={{ color: C.sage, fontSize: 11, marginTop: 2, opacity: 0.8 }}>{d}</div> : null}
    </div>
  );

  return (
    <div style={{ marginTop: 18 }}><AnalyticsReadStatus {...read} />
      {sgError && <div role="alert" style={{ color: C.cream, fontSize: 12 }}>The stale-game list could not be loaded. Refresh to retry.</div>}
      <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 16, fontWeight: 700 }}>Operations</div>
      <div style={{ color: C.sage, fontSize: 11, marginTop: 2, marginBottom: 8 }}>Profile-completion funnel and round hygiene. Nudge counts accumulate from when logging shipped, so they build up over time.</div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {tile(m.profiles_incomplete ?? 0, "Profiles incomplete", "missing photo or handicap")}
        {tile(`${m.nudge_clicked_7d ?? 0}/${m.nudge_shown_7d ?? 0}`, "Nudge clicks · 7d", ctr(m.nudge_clicked_7d ?? 0, m.nudge_shown_7d ?? 0))}
        {tile(`${m.nudge_clicked_28d ?? 0}/${m.nudge_shown_28d ?? 0}`, "Nudge clicks · 28d", ctr(m.nudge_clicked_28d ?? 0, m.nudge_shown_28d ?? 0))}
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8 }}>
        {tile(m.stale_ready ?? 0, "Stuck & complete", "daily job after 24h without scoring")}
        {tile(m.stale_partial ?? 0, "Stuck & partial", "left for the player to resolve")}
        {tile(m.auto_finished_7d ?? 0, "Auto-finished · 7d", "recovered into handicaps")}
      </div>
      {m.stale_job && (
        <div style={{ color: C.sage, fontSize: 12, marginTop: 8, lineHeight: 1.5 }}>
          <strong style={{ color: C.gold }}>Daily cleanup · 4 a.m. Eastern</strong>
          <div>{m.stale_job.scheduled ? "Scheduled" : "Not scheduled — check database setup"}</div>
          {m.stale_job.last_run ? <div>
            Last run: {m.stale_job.last_run.finished_at ? new Date(m.stale_job.last_run.finished_at).toLocaleString() : "in progress"}
            {" · "}{m.stale_job.last_run.completed_games ?? 0} games completed
            {" · "}{m.stale_job.last_run.deleted_games ?? 0} empty games deleted
            {" · "}{m.stale_job.last_run.reviewed_games ?? 0} sent for review
            {" · "}{m.stale_job.last_run.completed_rounds ?? 0} personal rounds completed
            <span style={{ color: m.stale_job.last_run.failures ? C.gold : C.sage }}> · {m.stale_job.last_run.failures ?? 0} failures</span>
          </div> : <div>No daily cleanup run recorded yet.</div>}
        </div>
      )}
      {sg ? (() => {
        const clean = sg.filter((g) => g.verdict === "fully_scored").length;
        const abandoned = sg.filter((g) => g.verdict === "in_progress" || g.verdict === "no_scores" || g.verdict === "empty").length;
        const vlabel: Record<string, string> = { fully_scored: "fully scored", in_progress: "in progress", no_scores: "no scores", empty: "no players" };
        const vcolor: Record<string, string> = { fully_scored: C.gold, in_progress: C.sage, no_scores: C.birdie, empty: C.faint };
        return (
          <div style={{ marginTop: 16 }}>
            <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 14, fontWeight: 700 }}>Stale games · 24h+</div>
            <div style={{ color: C.sage, fontSize: 11, marginTop: 2, marginBottom: 8 }}>
              Unfinished games created over a day ago, excluding future dates and Test clubs. Complete cards finish in the daily job after 24 hours without scoring. Empty games are deleted seven days after the later of creation or play date; partial cards go to the organizer for review.
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
              {tile(sg.length, "Total stale", "not ended, 24h+")}
              {tile(clean, "Fully scored", "done but left open")}
              {tile(abandoned, "Abandoned", "partial / empty")}
            </div>
            {sg.length === 0 ? (
              <div style={{ color: C.sage, fontSize: 12, padding: "8px 2px" }}>No stale games — nothing to clean up.</div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {sg.map((g) => (
                  <div key={g.game_id} style={{ background: C.greenLight, borderRadius: 10, padding: "8px 10px", display: "flex", alignItems: "flex-start", gap: 8 }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ color: C.cream, fontSize: 13, fontWeight: 700 }}>{g.name}</div>
                      <div style={{ color: C.sage, fontSize: 11, marginTop: 1 }}>
                        {g.course} · {g.club} · {Math.round(g.age_days)}d · {g.organizer}
                      </div>
                      <div style={{ color: C.sage, fontSize: 11, marginTop: 1, opacity: 0.85 }}>
                        {g.players} player{g.players === 1 ? "" : "s"} · {g.complete} done · {g.partial} mid-round · {g.not_started} no score
                        {g.rounds_posted ? ` · ${g.rounds_posted} posted` : ""}
                      </div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
                      <div style={{ background: vcolor[g.verdict] || C.faint, color: g.verdict === "fully_scored" ? "#1A1A1A" : C.cream, borderRadius: 8, padding: "2px 8px", fontSize: 11, fontWeight: 800, whiteSpace: "nowrap" }}>
                        {vlabel[g.verdict] || g.verdict}
                      </div>
                      {g.rounds_posted > 0 ? (
                        <div style={{ color: C.sage, fontSize: 11, whiteSpace: "nowrap" }}>has rounds</div>
                      ) : (
                        <button
                          onClick={() => delStale(g)}
                          disabled={delId === g.game_id}
                          style={{ background: "transparent", color: C.overRedDark, border: `1px solid ${C.birdie}`, borderRadius: 8, padding: "9px 8px", fontSize: 11, fontWeight: 700, cursor: delId === g.game_id ? "default" : "pointer", opacity: delId === g.game_id ? 0.62 : 1, whiteSpace: "nowrap" }}
                        >
                          {delId === g.game_id ? "Deleting…" : "Delete"}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })() : null}
    </div>
  );
}

type AdminGameRow = {
  game_id: string;
  code: string;
  game_name: string;
  course: string;
  game_type: string;
  game_status: string;
  played_at: string;
  created_at: string;
  ended_at: string | null;
  group_id: string | null;
  group_name: string;
  organizer_id: string;
  organizer_name: string;
  player_count: number;
  player_names: string;
  posted_round_count: number;
  competition_id: string | null;
  competition_name: string | null;
};

function AdminGamesOversight({ onOpenGame }: { onOpenGame: (gameId: string) => void }) {
  const [rows, setRows] = useState<AdminGameRow[] | null>(null);
  const [search, setSearch] = useState("");
  const [appliedSearch, setAppliedSearch] = useState("");
  const [status, setStatus] = useState<"all" | "active" | "ended" | "ryder_cup">("all");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async (query = appliedSearch, nextStatus = status) => {
    setLoading(true);
    setErr(null);
    // bounded: function returns at most the requested page (v_limit)
    const { data, error } = await supabase.rpc("admin_game_oversight", {
      p_search: query.trim() || null,
      p_status: nextStatus,
      p_limit: 200,
    });
    setLoading(false);
    if (error) {
      setErr(failureMessage("Couldn't load system-wide Games", error));
      return;
    }
    setRows((data || []) as AdminGameRow[]);
  }, [appliedSearch, status]);

  useEffect(() => { void load(); }, [load]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next = search.trim();
    if (next === appliedSearch) { void load(next, status); return; }
    setAppliedSearch(next);
  };

  const chooseStatus = (next: typeof status) => {
    setStatus(next);
  };

  const formatLabel = (value: string) => ({
    stableford: "Stableford", stroke: "Stroke Play", match: "Singles Match", fourball: "Four-Ball",
    alt_shot: "Alternate Shot", scramble: "Scramble", trifecta: "Trifecta", skins: "Skins",
  }[value] || value.replaceAll("_", " "));

  return (
    <div>
      <div style={{ color: C.sage, fontSize: 12.5, lineHeight: 1.5, marginBottom: 12 }}>
        Search every Game across every club. Inspecting a Game does not join it or add you as a player.
      </div>
      <form onSubmit={submit} style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Game, code, player, organizer, club…"
          aria-label="Search all Games"
          style={{ ...inputStyle, minWidth: 0, flex: 1 }}
        />
        <button type="submit" disabled={loading} style={{ ...btn(true), flexShrink: 0, padding: "8px 12px", fontSize: 12, opacity: loading ? .62 : 1 }}>
          {loading ? "Searching…" : "Search"}
        </button>
      </form>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 }}>
        {([
          ["all", "All"], ["active", "Active"], ["ended", "Completed"], ["ryder_cup", "Ryder Cup"],
        ] as const).map(([value, label]) => (
          <button key={value} onClick={() => chooseStatus(value)} style={{ ...btn(status === value), padding: "8px 12px", fontSize: 11 }}>
            {label}
          </button>
        ))}
      </div>
      {err ? <div style={{ color: C.overRedDark, fontSize: 12, marginTop: 10 }}>{err}</div> : null}
      <Eyebrow>{rows === null ? "GAMES" : `${rows.length} GAME${rows.length === 1 ? "" : "S"}`}</Eyebrow>
      {rows === null ? (
        <div style={{ color: C.sage, fontSize: 12 }}>Loading Games…</div>
      ) : rows.length === 0 ? (
        <div style={{ background: C.greenLight, borderRadius: 12, padding: 16, color: C.sage, fontSize: 12 }}>No Games match this search.</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {rows.map((g) => (
            <div key={g.game_id} style={{ width: "100%", boxSizing: "border-box", background: C.greenLight, border: `1px solid ${C.borderGreen}`, borderRadius: 12, padding: "8px 12px" }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 9 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ color: C.cream, fontSize: 14, fontWeight: 800, overflowWrap: "anywhere" }}>{g.game_name}</div>
                  <div style={{ color: C.sage, fontSize: 11.5, marginTop: 3, lineHeight: 1.45, overflowWrap: "anywhere" }}>
                    {g.group_name} · {formatLabel(g.game_type)} · {g.course}
                  </div>
                </div>
                <span style={{ flexShrink: 0, borderRadius: 999, padding: "4px 10px", background: g.game_status === "ended" ? C.gold : "#1F714D", color: g.game_status === "ended" ? C.green : C.cream, fontSize: 11, fontWeight: 800 }}>
                  {g.game_status === "ended" ? "COMPLETED" : "ACTIVE"}
                </span>
              </div>
              <div style={{ color: C.sage, fontSize: 11, lineHeight: 1.5, marginTop: 7, overflowWrap: "anywhere" }}>
                {g.played_at ? new Date(`${g.played_at}T12:00:00`).toLocaleDateString() : "No play date"} · Code {g.code} · Organizer {g.organizer_name}
              </div>
              <div style={{ color: C.sage, fontSize: 11, lineHeight: 1.5, overflowWrap: "anywhere" }}>
                {g.player_count} player{g.player_count === 1 ? "" : "s"} · {g.posted_round_count} posted round{g.posted_round_count === 1 ? "" : "s"}{g.competition_name ? ` · Ryder Cup: ${g.competition_name}` : ""}
              </div>
              {g.player_names ? <div style={{ color: C.cream, fontSize: 11, lineHeight: 1.45, marginTop: 5, overflowWrap: "anywhere" }}>{g.player_names}</div> : null}
              <button onClick={() => onOpenGame(g.game_id)} style={{ ...btn(false), marginTop: 9, padding: "8px 12px", fontSize: 11.5 }}>
                Inspect Game →
              </button>
            </div>
          ))}
        </div>
      )}
      {rows && rows.length === 200 ? <div style={{ color: C.sage, fontSize: 11, marginTop: 10 }}>Showing the newest 200 matches. Narrow the search to find older Games.</div> : null}
    </div>
  );
}

function RoundSaveDiag() {
  const [on, setOn] = useState(false);
  const [repro, setRepro] = useState(false);
  const [log, setLog] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const refresh = () => setLog(getDiagLog().slice().reverse());
  useEffect(() => { setOn(diagEnabled()); setRepro(reproduceBug()); refresh(); }, []);

  const toggleOn = () => { const v = !on; setDiagEnabled(v); setOn(v); refresh(); };
  const toggleRepro = () => { const v = !repro; setReproduceBug(v); setRepro(v); };
  const copyAll = async () => {
    const text = getDiagLog().map((e) => `${new Date(e.t).toISOString()} [${e.sid}] ${e.ev}${e.d ? " " + JSON.stringify(e.d) : ""}`).join("\n");
    try { await navigator.clipboard.writeText(text); notifyInfo(`Copied ${getDiagLog().length} events to clipboard.`); }
    catch { notifyError("Couldn't access the clipboard — select the text below and copy manually."); }
  };
  const clear = async () => { if ((await askConfirm("Clear the diagnostics log?"))) { clearDiagLog(); refresh(); } };

  const insertCount = getDiagLog().filter((e) => e.ev === "ensure" && /insert/.test(e.d?.outcome || "")).length;
  const evColor = (e: any) => {
    if (e.ev === "ensure") {
      const o = e.d?.outcome || "";
      if (/insert/.test(o)) return "#FB7185";      // new row created — the bug's signature
      if (o === "adopt" || o === "reuse") return "#8FE0B0"; // reused an existing row — good
      return C.sage;
    }
    if (e.ev === "flush") return "#7FB8FF";
    if (e.ev === "mount") return C.gold;
    return C.sage;
  };
  const Toggle = ({ v, on: label, off }: { v: boolean; on: string; off: string }) => (
    <span style={{ display: "inline-block", minWidth: 44, textAlign: "center", padding: "3px 8px", borderRadius: 999, fontSize: 11, fontWeight: 800, color: v ? "#0e3a2c" : C.sage, background: v ? C.gold : "#16302A", border: `1px solid ${v ? C.gold : "#37624f"}` }}>{v ? label : off}</span>
  );

  return (
    <div style={{ marginTop: 18, border: `1px solid #37624f`, borderRadius: 12, padding: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 16, fontWeight: 700, flex: 1 }}>Round-save diagnostics</div>
        <button onClick={() => setOpen((o) => !o)} style={{ ...btn(false), fontSize: 11, padding: "5px 10px" }}>{open ? "Hide" : "Show"}</button>
      </div>
      {open && (
        <div style={{ marginTop: 10 }}>
          <div style={{ color: C.sage, fontSize: 11, lineHeight: 1.5, marginBottom: 10 }}>
            Per-device and off by default. Turn on logging, then to reproduce the bug turn on “reproduce” and score a few holes,
            locking the phone between each. Red “insert” lines = a new row was created; green “adopt/reuse” = the existing row was
            reused. One round should show a single insert once reproduce is off.
          </div>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 10 }}>
            <button onClick={toggleOn} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, padding: 0 }}>
              <Toggle v={on} on="ON" off="OFF" /><span style={{ color: C.cream, fontSize: 12 }}>Logging</span>
            </button>
            <button onClick={toggleRepro} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 8, padding: 0 }}>
              <Toggle v={repro} on="ON" off="OFF" /><span style={{ color: repro ? "#FB7185" : C.cream, fontSize: 12 }}>Reproduce bug (disable dedupe)</span>
            </button>
          </div>
          <div style={{ display: "flex", gap: 6, marginBottom: 8 }}>
            <button onClick={refresh} style={{ ...btn(false), fontSize: 11, padding: "5px 10px" }}>Refresh</button>
            <button onClick={copyAll} style={{ ...btn(true), fontSize: 11, padding: "5px 10px" }}>Copy all</button>
            <button onClick={clear} style={{ ...btn(false), fontSize: 11, padding: "5px 10px" }}>Clear</button>
          </div>
          <div style={{ color: C.sage, fontSize: 11, marginBottom: 6 }}>{log.length} events · <span style={{ color: insertCount > 1 ? "#FB7185" : C.sage, fontWeight: 700 }}>{insertCount} insert{insertCount === 1 ? "" : "s"}</span></div>
          <div style={{ maxHeight: 280, overflowY: "auto", background: "#0e2620", borderRadius: 8, padding: 8, fontFamily: "monospace", fontSize: 11, lineHeight: 1.5 }}>
            {log.length === 0 ? <div style={{ color: C.sage }}>No events yet.</div> : log.map((e, i) => (
              <div key={i} style={{ color: evColor(e), whiteSpace: "pre-wrap", wordBreak: "break-all" }}>
                {new Date(e.t).toLocaleTimeString()} [{e.sid}] {e.ev}{e.d ? " " + JSON.stringify(e.d) : ""}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}


// ── Admin · Course data (0169) ────────────────────────────────────────────────────────────────────
// One row per library course: clubs, last provider verification, last data comparison and its
// review state, pending member corrections. Replaces hunting across the course editor, the queue
// at the top of Courses, and Pending edits.
type AdminCourseRow = {
  course_id: string; course_name: string; clubs: string; provider_id: string | null; corrected: boolean;
  last_verified_at: string | null; last_check_at: string | null; last_check_status: string | null; last_check_note: string | null;
  freshness_checked_at: string | null; freshness_status: string | null; freshness_changes: number | null;
  pending_requests: number | null; oldest_request_at: string | null;
  // 207.1 (0187)
  last_compared_at: string | null; freshness_check_state: string | null; freshness_revision: number | null;
  decision_reason: string | null; decided_at: string | null;
  current_version: number | null; current_version_at: string | null; current_version_source: string | null; current_version_by: string | null;
};
type CheckLogRow = { at: string; status: string; http_status: number | null; note: string | null; source: string };
function AdminCourseData({ onOpenCourses }: { onOpenCourses?: () => void }) {
  const [rows, setRows] = useState<AdminCourseRow[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [filter, setFilter] = useState<"review" | "failed" | "unchecked" | "all">("review");
  const [busy, setBusy] = useState<string | null>(null);
  const [flash, setFlash] = useState<Record<string, string>>({});
  const [open, setOpen] = useState<Record<string, { diff: FreshnessDiff | null; log: CheckLogRow[] | null }>>({});
  const load = useCallback(async () => {
    const { data, error } = await rpcAll(supabase, "admin_course_status", undefined, "course_id");
    if (error) { setErr(error.message); setRows([]); return; }
    setRows((data || []) as AdminCourseRow[]);
  }, []);
  useEffect(() => { void load(); }, [load]);
  const say = (id: string, m: string) => setFlash((f) => ({ ...f, [id]: m }));

  // Refresh from API now: ONE provider request. The route records the attempt in the ledger (and
  // the 0171 log); the shared freshness checker then diffs the payload against the stored data and
  // records the review, exactly as New Round and the nightly sync do.
  const refreshNow = async (r: AdminCourseRow) => {
    if (!r.provider_id) return;
    setBusy(r.course_id); say(r.course_id, "");
    try {
      const { data: fc } = await supabase.from("favorite_courses").select("data").eq("id", r.course_id).maybeSingle();
      const res = await checkCourseFreshness(supabase, { courseId: r.course_id, externalId: r.provider_id, stored: (fc?.data as Course) || ({ name: r.course_name, tees: [], holes: [] } as unknown as Course), force: true });
      // 206.0 (finding 6): say what actually happened.
      if (res.checkState === "provider_error" || res.checkState === "failed") say(r.course_id, `The provider did not answer${res.error ? ` (${res.error})` : ""} — see the attempt log below.`);
      else if (res.checkState === "incomplete") say(r.course_id, `The provider's data is incomplete — nothing to apply: ${(res.problems || []).slice(0, 3).join("; ")}${(res.problems || []).length > 3 ? "…" : ""}`);
      else if (res.checkState === "not_saved") say(r.course_id, `Compared, but the result couldn't be saved${res.error ? ` (${res.error})` : ""}.`);
      else say(r.course_id, res.hasChanges ? `Provider data differs (${res.status}) — review below.` : "Verified: stored data matches the provider.");
      await logActivity(supabase, { actor_id: (await supabase.auth.getUser()).data.user?.id || "", actor_name: "admin", action: "course_api_manual_refresh", group_id: null, summary: `Manual GolfCourseAPI refresh for "${r.course_name}"` });
    } finally {
      setBusy(null); await load(); await openDetails(r, true);
    }
  };
  const openDetails = async (r: AdminCourseRow, keepOpen = false) => {
    if (open[r.course_id] && !keepOpen) { setOpen((o) => { const n = { ...o }; delete n[r.course_id]; return n; }); return; }
    const [{ data: cf }, { data: log }] = await Promise.all([
      supabase.from("course_freshness").select("diff, has_changes, status, revision").eq("course_id", r.course_id).maybeSingle(),
      // bounded: function returns at most 100 (latest checks)
      r.provider_id ? supabase.rpc("admin_course_check_log", { p_provider_id: r.provider_id, p_limit: 20 }) : Promise.resolve({ data: [] as CheckLogRow[] }),
    ]);
    // The revision shown here is the one an approval applies (0183): what the admin saw, nothing newer.
    setOpen((o) => ({ ...o, [r.course_id]: { diff: cf?.has_changes && (cf?.diff as any)?.hasChanges ? (cf.diff as FreshnessDiff) : null, log: (log || []) as CheckLogRow[], revision: (cf as any)?.revision ?? null } }));
  };
  const apply = async (r: AdminCourseRow) => {
    if (!(await askConfirm(`Update "${r.course_name}" with the GolfCourseAPI data for everyone?${r.corrected ? "\n\nThis course carries hand corrections; updating replaces the whole stored record with the provider's version." : ""}`))) return;
    setBusy(r.course_id);
    const revision = (open[r.course_id] as any)?.revision;
    if (revision == null) { setBusy(null); say(r.course_id, "Open the details and review the changes before applying."); return; }
    const { error } = await supabase.rpc("apply_course_freshness", { p_course_id: r.course_id, p_revision: revision });
    say(r.course_id, error ? `Couldn't update: ${error.message}` : "Stored course now matches the provider.");
    setBusy(null); await load(); await openDetails(r, true);
  };
  const dismiss = async (r: AdminCourseRow) => {
    setBusy(r.course_id);
    // 207.1: keep current data for the revision on screen, with an optional reason (0187).
    const rev = (open[r.course_id] as any)?.revision ?? r.freshness_revision;
    if (rev == null) { setBusy(null); say(r.course_id, "Open the details and review the changes first."); return; }
    const reason = (await askText("Keep the current data. Reason (optional) — e.g. \"provider's slope is wrong\":", "")) ;
    if (reason === null) { setBusy(null); return; }
    const { error } = await supabase.rpc("dismiss_course_freshness", { p_course_id: r.course_id, p_revision: rev, p_reason: reason || null });
    say(r.course_id, error ? `Couldn't dismiss: ${error.message}` : "Kept the stored data; you'll be told if the provider changes it again.");
    setBusy(null); await load(); await openDetails(r, true);
  };
  const needsAttention = (r: AdminCourseRow) =>
    r.freshness_status === "pending" || (r.pending_requests || 0) > 0 || r.last_check_status === "error" || r.last_check_status === "drift" || (!!r.provider_id && !r.last_verified_at) || r.clubs === "No club";
  // 207.1: one status function decides what each row says and which filters it falls under.
  const statusOf = (r: AdminCourseRow) => courseStatus(r, (iso) => ago(iso));
  const shownRows = () => (rows || []).filter((r) => {
    if (filter === "all") return true;
    const st = statusOf(r);
    return filter === "review" ? st.review : filter === "failed" ? st.failed : st.notChecked;
  });
  const ago = (iso: string | null) => {
    if (!iso) return "never";
    const d = new Date(iso); const now = new Date();
    const sod = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
    const days = Math.round((sod(now) - sod(d)) / 86_400_000);
    const when = d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    return `${when} (${days <= 0 ? "today" : days === 1 ? "yesterday" : `${days}d ago`})`;
  };
  const counts = {
    pendingApi: (rows || []).filter((r) => r.freshness_status === "pending").length,
    pendingReq: (rows || []).reduce((n, r) => n + (r.pending_requests || 0), 0),
    unverified: (rows || []).filter((r) => !!r.provider_id && !r.last_verified_at).length,
    noProvider: (rows || []).filter((r) => !r.provider_id).length,
  };
  return (
    <div>
      {err && <div style={{ color: C.gold, fontSize: 12 }}>Couldn't load course status: {err}</div>}
      {rows && (
        <div style={{ background: C.greenLight, borderRadius: 12, padding: "13px 16px", marginBottom: 10, color: C.cream, fontSize: 13, lineHeight: 1.6 }}>
          <b>{rows.length}</b> courses in the library · <b>{counts.pendingApi}</b> with provider updates to review · <b>{counts.pendingReq}</b> member correction{counts.pendingReq === 1 ? "" : "s"} awaiting global approval · <b>{counts.unverified}</b> never verified · <b>{counts.noProvider}</b> custom (no provider id)
          {(counts.pendingApi > 0 || counts.pendingReq > 0) && onOpenCourses && (
            <div style={{ marginTop: 6 }}><button style={{ ...btn(true), fontSize: 12 }} onClick={onOpenCourses}>Open Courses to review</button></div>
          )}
        </div>
      )}
      <div data-course-filters style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
        {([["review", "Review required", (r: AdminCourseRow) => statusOf(r).review], ["failed", "Failed / incomplete", (r: AdminCourseRow) => statusOf(r).failed],
           ["unchecked", "Not checked", (r: AdminCourseRow) => statusOf(r).notChecked], ["all", "All", () => true]] as const).map(([k, label, pred]) => (
          <button key={k} style={{ ...btn(filter === k), fontSize: 12 }} onClick={() => setFilter(k)}>{label} ({(rows || []).filter(pred).length})</button>
        ))}
      </div>
      {rows && shownRows().length === 0 && <div style={{ color: C.sage, fontSize: 13 }}>{filter === "all" ? "No courses." : "Nothing here."}</div>}
      {shownRows().map((r) => (
        <div key={r.course_id} data-admin-course-row style={{ background: C.greenLight, borderRadius: 12, padding: "13px 16px", marginBottom: 8 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
            <div style={{ color: C.cream, fontWeight: 800 }}>{r.course_name}{r.corrected ? <span style={{ color: C.sage, fontWeight: 500 }}> · hand-corrected</span> : null}</div>
            <div style={{ color: r.clubs === "No club" ? C.gold : C.sage, fontSize: 12 }}>{r.clubs}</div>
          </div>
          {(() => {
            const st = statusOf(r);
            const col = (t?: string) => (t === "action" || t === "problem" ? C.gold : C.sage);
            return (
              <div data-course-status={st.tone} style={{ marginTop: 6, lineHeight: 1.55 }}>
                <div style={{ color: st.tone === "ok" ? C.sage : st.tone === "quiet" ? C.sage : C.gold, fontSize: 13, fontWeight: 800 }}>{st.headline}</div>
                {st.lines.map((l, k) => <div key={k} style={{ color: col(l.tone), fontSize: 12.5, fontWeight: l.tone ? 700 : 400 }}>{l.text}</div>)}
              </div>
            );
          })()}
          <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
            {r.provider_id && <button style={{ ...btn(false), fontSize: 12, opacity: busy === r.course_id ? 0.5 : 1 }} disabled={busy === r.course_id} onClick={() => refreshNow(r)}>Refresh from API now (1 request)</button>}
            {r.freshness_status === "pending" && <button style={{ ...btn(true), fontSize: 12, opacity: busy === r.course_id ? 0.5 : 1 }} disabled={busy === r.course_id} onClick={() => apply(r)}>Update stored course</button>}
            {r.freshness_status === "pending" && <button style={{ ...btn(false), fontSize: 12, opacity: busy === r.course_id ? 0.5 : 1 }} disabled={busy === r.course_id} onClick={() => dismiss(r)}>Keep current</button>}
            {(r.pending_requests || 0) > 0 && onOpenCourses && <button style={{ ...btn(true), fontSize: 12 }} onClick={onOpenCourses}>Approve corrections in Courses</button>}
            <button style={{ ...btn(false), fontSize: 12 }} onClick={() => openDetails(r)}>{open[r.course_id] ? "Hide details" : statusOf(r).review ? "Review changes" : "Details & history"}</button>
          </div>
          {flash[r.course_id] && <div style={{ color: C.gold, fontSize: 12.5, marginTop: 8 }}>{flash[r.course_id]}</div>}
          {open[r.course_id] && (
            <div style={{ marginTop: 10 }}>
              {open[r.course_id].diff ? (
                <>
                  <div style={{ color: C.gold, fontSize: 11, fontWeight: 800, letterSpacing: 1.2, marginBottom: 6 }}>PROVIDER CHANGES AWAITING REVIEW</div>
                  <FreshnessDiffList diff={open[r.course_id].diff!} maxHeight={200} />
                </>
              ) : <div style={{ color: C.sage, fontSize: 12.5 }}>No provider changes awaiting review.</div>}
              <div style={{ color: C.gold, fontSize: 11, fontWeight: 800, letterSpacing: 1.2, margin: "10px 0 6px" }}>API ATTEMPTS (LAST 20, 90 DAYS)</div>
              {(open[r.course_id].log || []).length === 0 && <div style={{ color: C.sage, fontSize: 12.5 }}>No attempts recorded since the log began.</div>}
              {(open[r.course_id].log || []).map((l, i) => (
                <div key={i} style={{ color: l.status === "ok" ? C.sage : C.gold, fontSize: 12.5, lineHeight: 1.5 }}>
                  {new Date(l.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} · <b>{l.status}</b>{l.http_status ? ` ${l.http_status}` : ""} · {l.source}{l.note ? ` — ${l.note}` : ""}
                </div>
              ))}
              <CourseHistory courseId={r.course_id} clubs={r.clubs || ""} canRestore onRestored={() => void openDetails(r, true)} />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}


// Recent push deliveries (0172): what the webhook decided and what the push service answered.
function AdminPushDeliveries() {
  const [rows, setRows] = useState<Array<{ at: string; user_name: string; type: string | null; delivery: string; endpoints: number; sent: number; failed: number; result: string | null }> | null>(null);
  const [show, setShow] = useState(false);
  // bounded: function returns at most 200 (latest deliveries)
  useEffect(() => { if (!show) return; supabase.rpc("admin_push_delivery_log", { p_user: null, p_limit: 30 }).then(({ data }: any) => setRows((data || []) as any), () => setRows([])); }, [show]);
  return (
    <div style={{ marginTop: 10 }}>
      <button style={{ ...btn(false), fontSize: 12 }} onClick={() => setShow((v) => !v)}>{show ? "Hide recent push deliveries" : "Recent push deliveries (last 30)"}</button>
      {show && rows && rows.length === 0 && <div style={{ color: C.sage, fontSize: 12.5, marginTop: 6 }}>Nothing logged yet — the log starts with this release.</div>}
      {show && rows && rows.length > 0 && (
        <div style={{ background: C.greenLight, borderRadius: 12, padding: "13px 16px", marginTop: 8 }}>
          {rows.map((l, i) => (
            <div key={i} style={{ color: l.sent > 0 ? C.cream : C.sage, fontSize: 12.5, lineHeight: 1.55 }}>
              {new Date(l.at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} · <b>{l.user_name}</b> · {l.type || "—"} · {l.delivery} · {l.result}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

type SignupRow = { user_id: string; display_name: string | null; email: string | null; signed_up_at: string; last_sign_in: string | null; clubs: string | null; first_club_at: string | null };
const fmtDay = (iso: string | null | undefined) => iso ? new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : "—";

function AdminPanel({ user, showAnalytics = true }: { user: any; showAnalytics?: boolean }) {
  // When each member signed up for BNN (auth.users.created_at, via admin_member_signups 0165) and
  // when they joined each club. One call; keyed by user id for the player rows below.
  const [signups, setSignups] = useState<SignupRow[] | null>(null);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { data, error } = await rpcAll(supabase, "admin_member_signups", undefined, "user_id");
        if (!cancelled) setSignups(error ? [] : ((data || []) as SignupRow[]));
      } catch { if (!cancelled) setSignups([]); }
    })();
    return () => { cancelled = true; };
  }, []);
  const signupById = React.useMemo(() => new Map((signups || []).map((r) => [r.user_id, r])), [signups]);
  const [profiles, setProfiles] = useState<any[] | null>(null);
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [scoringFor, setScoringFor] = useState<any | null>(null);
  const [deletedCourses, setDeletedCourses] = useState<any[]>([]);
  const [allGroups, setAllGroups] = useState<any[]>([]);
  const [memberships, setMemberships] = useState<any[]>([]);
  const [manageGroupsFor, setManageGroupsFor] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [query, setQuery] = useState("");        // debounced/applied search term
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const PAGE = 50;

  // Load one page of players (search-filtered), and fetch group memberships only for those players.
  const loadProfiles = useCallback(async (from: number, q: string, existing: any[]) => {
    let qb = supabase.from("profiles").select("*").order("last_active", { ascending: false }).range(from, from + PAGE - 1);
    if (q.trim()) qb = qb.or(`display_name.ilike.%${q.trim()}%,email.ilike.%${q.trim()}%`);
    const { data } = await qb;
    const page = data || [];
    const merged = from === 0 ? page : [...existing, ...page];
    setProfiles(merged);
    setHasMore(page.length === PAGE);
    const ids = merged.map((p: any) => p.id);
    if (ids.length) {
      // 210.4: paged — a page of up to 1,000 users can hold more than 1,000 memberships.
      let mem: any[] = [];
      try { mem = await fetchAll<any>((f, t) => supabase.from("group_members").select("id, group_id, user_id, role, status").in("user_id", ids).neq("status", "removed").order("id").range(f, t)); } catch { mem = []; }
      setMemberships(mem);
    }
  }, []);

  const loadMorePlayers = async () => {
    setLoadingMore(true);
    const current = profiles || [];
    await loadProfiles(current.length, query, current);
    setLoadingMore(false);
  };

  const load = useCallback(async () => {
    await loadProfiles(0, query, []);
    // 210.4: paged — both lists grow with the system.
    let del: any[] = [], gs: any[] = [];
    try { del = await fetchAll<any>((f, t) => supabase.from("favorite_courses").select("*").eq("deleted", true).order("deleted_at", { ascending: false }).order("id").range(f, t)); } catch { del = []; }
    setDeletedCourses(del);
    try { gs = await fetchAll<any>((f, t) => supabase.from("groups").select("id, name, status").neq("status", "declined").order("name").order("id").range(f, t)); } catch { gs = []; }
    setAllGroups(gs);   // 210.12: every club (names for pending ones too); the add-to-club list filters to active
  }, [query]);
  useEffect(() => { load(); }, [load]);

  // --- Global player ↔ group management (admin governance) ---
  const addToGroup = async (p: any, groupId: string) => {
    const existing = memberships.find((m) => m.user_id === p.id && m.group_id === groupId);
    if (existing) return;
    await supabase.from("group_members").insert({
      group_id: groupId, user_id: p.id, email: (p.email || "").toLowerCase(), role: "member", status: "active",
    });
    await notify(p.id, `${await myLabel(user)} added you to ${allGroups.find((x) => x.id === groupId)?.name || "a club"}.`, null, groupId);
    await logActivity(supabase, { actor_id: user.id, actor_name: "Admin", action: "member_added", group_id: groupId, target_user_id: p.id, summary: `Added ${p.display_name || p.email} to a group` });
    await load();
  };

  const removeFromGroup = async (p: any, m: any, groupName: string) => {
    if (!(await askConfirm(`Remove ${p.display_name || p.email} from "${groupName}"?`))) return;
    await supabase.from("group_members").update({ status: "removed" }).eq("id", m.id);
    await notify(p.id, `${await myLabel(user)} removed you from ${groupName}.`, null, m.group_id);
    await logActivity(supabase, { actor_id: user.id, actor_name: "Admin", action: "member_removed", group_id: m.group_id, target_user_id: p.id, summary: `Removed ${p.display_name || p.email} from "${groupName}"` });
    await load();
  };

  // Deactivate: remove from all groups + block access, but keep their data.
  const deactivatePlayer = async (p: any) => {
    if (!(await askConfirm(`Deactivate ${p.display_name || p.email}?\n\nThey'll be removed from all clubs and blocked from using the app, but their rounds and history are kept. You can reactivate them later.`))) return;
    await supabase.from("group_members").update({ status: "removed" }).eq("user_id", p.id);
    await supabase.from("profiles").update({ deactivated: true }).eq("id", p.id);
    await logActivity(supabase, { actor_id: user.id, actor_name: "Admin", action: "player_deactivated", target_user_id: p.id, summary: `Deactivated ${p.display_name || p.email}` });
    await load();
  };

  const reactivatePlayer = async (p: any) => {
    await supabase.from("profiles").update({ deactivated: false }).eq("id", p.id);
    await logActivity(supabase, { actor_id: user.id, actor_name: "Admin", action: "player_reactivated", target_user_id: p.id, summary: `Reactivated ${p.display_name || p.email}` });
    await load();
  };

  // Flag/unflag any account as a test account (excluded from all analytics, fully functional).
  const toggleTestPlayer = async (p: any) => {
    const next = !p.is_test;
    const { error } = await supabase.rpc("admin_set_test", { p_user: p.id, p_is_test: next });
    if (error) { notifyError(failureMessage("Couldn't update test mode", error)); return; }
    await logActivity(supabase, { actor_id: user.id, actor_name: "Admin", action: next ? "player_test_on" : "player_test_off", target_user_id: p.id, summary: `${next ? "Marked" : "Unmarked"} ${p.display_name || p.email} as a test account` });
    await load();
  };

  // Hard delete: erase the player and all their data permanently.

  const restoreCourse = async (c: any) => {
    // Group B: the notify below tells another member their deleted course was restored. Sending
    // that after a failed update would be telling them something untrue.
    if (!(await write(
      supabase.from("favorite_courses").update({ deleted: false, deleted_by: null, deleted_at: null }).eq("id", c.id),
      "Couldn't restore this course"))) return;
    if (c.deleted_by && c.deleted_by !== user.id) {
      await notify(c.deleted_by, `${await myLabel(user)} restored the course "${c.name}" you deleted.`);
    }
    await load();
  };

  const now = Date.now();
  const active24 = (profiles || []).filter((p) => p.last_active && now - +new Date(p.last_active) < 86400000).length;
  const active7d = (profiles || []).filter((p) => p.last_active && now - +new Date(p.last_active) < 7 * 86400000).length;

  const saveHandicap = async (p: any) => {
    const raw = edits[p.id];
    if (raw === undefined) return;
    const idx = raw.trim() === "" ? null : parseFloat(raw);
    setSavingId(p.id);
    // The notifications below tell the player their handicap was set. Sending those after a
    // failed write would have them playing off a number the database does not hold.
    if (!(await write(supabase.from("profiles").update({ handicap_index: idx }).eq("id", p.id),
      "Couldn't save this player's handicap"))) { setSavingId(null); return; }
    // Notify both the player and the admin.
    const who = p.display_name || "a player";
    await notify(p.id, `${await myLabel(user)} set your handicap index to ${idx ?? "—"}${p.handicap_index != null ? ` (was ${p.handicap_index})` : ""}.`);
    await notify(user.id, `You changed ${who}'s handicap index to ${idx ?? "—"}${p.handicap_index != null ? ` (was ${p.handicap_index})` : ""}.`);
    await logActivity(supabase, { actor_id: user.id, actor_name: "Admin", action: "handicap_changed", target_user_id: p.id, summary: `Set ${who}'s handicap index to ${idx ?? "—"}` });
    setSavingId(null);
    await load();
  };

  if (scoringFor) {
    return <AdminScoreEditor admin={user} player={scoringFor} onBack={() => setScoringFor(null)} />;
  }

  return (
    <div style={{ marginTop: 24 }}>
      {showAnalytics && (
        <>
          <Eyebrow>★ ADMIN · ANALYTICS</Eyebrow>
          <AdminAnalytics />
          <AdminExtraStats />
          <AdminDailyReport />
          <AdminEngagement />
          <AdminPowerUsers />
          <OpsMetrics />
          <RoundSaveDiag />
          <div style={{ height: 22 }} />
        </>
      )}
      <Eyebrow>★ ADMIN · ALL PLAYERS</Eyebrow>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 8 }}>
        <div style={{ background: C.greenLight, borderRadius: 12, padding: "10px 14px", flex: 1, minWidth: 110 }}>
          <div style={{ color: C.cream, fontWeight: 800, fontSize: 22, fontFamily: "Georgia, serif" }}>{profiles?.length ?? "—"}{hasMore ? "+" : ""}</div>
          <div style={{ color: C.sage, fontSize: 11 }}>{query ? "Matches loaded" : "Users loaded"}</div>
        </div>
        <div style={{ background: C.greenLight, borderRadius: 12, padding: "10px 14px", flex: 1, minWidth: 110 }}>
          <div style={{ color: C.cream, fontWeight: 800, fontSize: 22, fontFamily: "Georgia, serif" }}>{active24}</div>
          <div style={{ color: C.sage, fontSize: 11 }}>Active 24h</div>
        </div>
        <div style={{ background: C.greenLight, borderRadius: 12, padding: "10px 14px", flex: 1, minWidth: 110 }}>
          <div style={{ color: C.cream, fontWeight: 800, fontSize: 22, fontFamily: "Georgia, serif" }}>{active7d}</div>
          <div style={{ color: C.sage, fontSize: 11 }}>Active 7d</div>
        </div>
      </div>
      {signups && signups.length > 0 && (
        <div style={{ background: C.greenLight, borderRadius: 12, padding: "13px 16px", marginTop: 10 }}>
          <div style={{ color: C.gold, fontSize: 11, fontWeight: 800, letterSpacing: 1.2 }}>RECENT SIGN-UPS</div>
          {signups.slice(0, 5).map((r) => (
            <div key={r.user_id} style={{ color: C.cream, fontSize: 12.5, marginTop: 6, lineHeight: 1.45 }}>
              <b>{r.display_name || (r.email || "").split("@")[0] || "Golfer"}</b>
              <span style={{ color: C.sage }}> · joined BNN {fmtDay(r.signed_up_at)}{r.clubs ? ` · ${r.clubs}` : " · no club yet"}</span>
            </div>
          ))}
        </div>
      )}
      <div style={{ color: C.sage, fontSize: 12, marginTop: 10 }}>Adjust any player's handicap; they (and you) get a notification. To edit a player's scores, use “Edit scores” to enter admin mode on their rounds.</div>

      <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") setQuery(search); }}
          placeholder="Search players by name or email…"
          style={{ ...inputStyle, flex: 1, minWidth: 200 }}
        />
        <button style={{ ...btn(true), fontSize: 13 }} onClick={() => setQuery(search)}>Search</button>
        {query && <button style={{ ...btn(false), fontSize: 13 }} onClick={() => { setSearch(""); setQuery(""); }}>Clear</button>}
      </div>

      {profiles === null && <div style={{ color: C.sage, marginTop: 12 }}>Loading…</div>}
      {profiles?.map((p) => (
        <div key={p.id} style={{ background: C.greenLight, borderRadius: 12, padding: "13px 16px", marginTop: 8, display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
          <Avatar src={p.avatar_url} name={p.display_name || p.email || "?"} size={32} />
          <div style={{ flex: 1, minWidth: 180 }}>
            <div style={{ color: C.cream, fontWeight: 700, fontSize: 15 }}>{p.display_name || "Golfer"}{p.id === user.id ? " (you)" : ""}{p.is_admin ? " ★" : ""}
              {p.account_status && p.account_status !== "active" ? (
                <span data-account-status={p.account_status} style={{ marginLeft: 8, background: p.account_status === "suspended" ? C.gold : p.account_status === "pending" || p.account_status === "new" ? C.greenMid : C.overRedDark,
                  color: p.account_status === "suspended" ? C.green : p.account_status === "pending" || p.account_status === "new" ? C.sage : C.cream, borderRadius: 999, padding: "4px 10px", fontSize: 11, fontWeight: 800, textTransform: "uppercase" }}>{p.account_status}</span>
              ) : null}
            </div>
            {p.account_status && p.account_status !== "active" && p.status_at ? (
              <div style={{ color: C.sage, fontSize: 12, marginTop: 2 }}>
                {p.account_status} {new Date(p.status_at).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}{p.status_reason ? ` · ${p.status_reason}` : ""}
                {p.account_status === "merged" || p.account_status === "removed" ? " · email blocked — can't sign in to BNN" : ""}
              </div>
            ) : null}
            <div style={{ color: C.sage, fontSize: 12 }}>
              {p.email || "no email"}{p.phone ? ` · ${p.phone}` : ""}{p.ghin_number ? ` · GHIN ${p.ghin_number}` : ""}
            </div>
            <div style={{ color: C.sage, fontSize: 12, marginTop: 2 }}>
              Handicap: {p.handicap_index != null ? p.handicap_index : "—"}
              {signupById.get(p.id) ? ` · Joined BNN ${fmtDay(signupById.get(p.id)!.signed_up_at)}` : ""}
              {/* 210.12: "last active" = the last time they opened the app (profiles.last_active, saved on every open);
                  "signed in" = the last time they picked their Google account — BNN keeps people signed in for weeks. */}
              {p.last_active ? ` · Last active ${fmtDay(p.last_active)}` : ""}
              {signupById.get(p.id)?.last_sign_in ? ` · signed in ${fmtDay(signupById.get(p.id)!.last_sign_in)}` : ""}
            </div>
            {(() => {
              const mine = memberships.filter((m) => m.user_id === p.id);
              if (mine.length === 0) return <div style={{ color: C.overRedDark, fontSize: 12, marginTop: 2 }}>Clubs: none</div>;
              return (
                <div style={{ color: C.cream, fontSize: 12, marginTop: 2, display: "flex", flexWrap: "wrap", gap: 6 }}>
                  <span style={{ color: C.sage }}>Clubs:</span>
                  {mine.map((m) => {
                    const g = allGroups.find((x) => x.id === m.group_id);
                    return (
                      <span key={m.id} style={{ background: C.greenLight, color: C.cream, borderRadius: 12, padding: "1px 9px", fontSize: 11, fontWeight: 700 }}>
                        {g?.name || "Club"}{m.role === "admin" ? " ★" : ""}{g?.status === "pending" ? " (pending)" : ""}
                      </span>
                    );
                  })}
                </div>
              );
            })()}
            <div style={{ color: C.sage, fontSize: 11, marginTop: 2 }}>active {timeAgo(p.last_active)}</div>
          </div>
          <div>
            <label style={{ color: C.sage, fontSize: 11 }}>Handicap index</label>
            <div style={{ display: "flex", gap: 6, marginTop: 2 }}>
              <input inputMode="decimal" defaultValue={p.handicap_index != null ? String(p.handicap_index) : ""}
                onChange={(e) => { const v = e.target.value; if (v === "" || /^\d*\.?\d*$/.test(v)) setEdits((m) => ({ ...m, [p.id]: v })); }}
                style={{ ...inputStyle, padding: "6px 8px", width: 80, textAlign: "center" }} />
              <button style={{ ...btn(true), padding: "6px 12px", fontSize: 12, opacity: savingId === p.id ? 0.62 : 1 }} disabled={savingId === p.id} onClick={() => saveHandicap(p)}>Save</button>
            </div>
          </div>
          <button style={{ ...btn(false), padding: "6px 12px", fontSize: 12 }} onClick={() => setScoringFor(p)}>Edit scores</button>
          <button style={{ ...btn(false), padding: "6px 12px", fontSize: 12 }} onClick={() => setManageGroupsFor(manageGroupsFor === p.id ? null : p.id)}>
            {manageGroupsFor === p.id ? "Close" : "Manage"}
          </button>
          {p.deactivated && <span style={{ color: C.overRedDark, fontSize: 11, fontWeight: 800 }}>DEACTIVATED</span>}

          {manageGroupsFor === p.id && (
            <div style={{ width: "100%", boxSizing: "border-box", background: C.greenLight, borderRadius: 10, padding: 12, marginTop: 8 }}>
              <Eyebrow>CLUBS</Eyebrow>
              {(() => {
                const mine = memberships.filter((m) => m.user_id === p.id);
                const myGroupIds = new Set(mine.map((m) => m.group_id));
                return (
                  <>
                    {mine.length === 0 && <div style={{ color: C.sage, fontSize: 12, marginTop: 6 }}>Not in any club.</div>}
                    {mine.map((m) => {
                      const g = allGroups.find((x) => x.id === m.group_id);
                      return (
                        <div key={m.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: `1px solid ${C.borderGreen}` }}>
                          <span style={{ flex: 1, color: C.cream, fontSize: 13 }}>{g?.name || "Club"}{m.role === "admin" ? " · admin" : ""}{g?.status === "pending" ? " · pending approval" : ""}</span>
                          <button style={{ ...btn(false), padding: "9px 10px", fontSize: 11, color: C.overRedDark }} onClick={() => removeFromGroup(p, m, g?.name || "this club")}>Remove</button>
                        </div>
                      );
                    })}
                    <div style={{ display: "flex", gap: 6, marginTop: 10, alignItems: "center", flexWrap: "wrap" }}>
                      <label style={{ color: C.sage, fontSize: 11 }}>Add to club:</label>
                      <select defaultValue="" onChange={(e) => { if (e.target.value) { addToGroup(p, e.target.value); e.target.value = ""; } }}
                        style={{ ...inputStyle, padding: "6px 8px", fontSize: 12, maxWidth: 180 }}>
                        <option value="">Select…</option>
                        {allGroups.filter((g) => !myGroupIds.has(g.id) && (g.status ?? "active") === "active").map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
                      </select>
                    </div>

                    <div style={{ borderTop: `1px solid ${C.borderGreen}`, marginTop: 12, paddingTop: 10 }}>
                      <Eyebrow>ANALYTICS</Eyebrow>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 8 }}>
                        <div style={{ flex: 1, color: C.cream, fontSize: 12 }}>
                          Test account {p.is_test ? "· ON" : "· off"}
                          <div style={{ color: C.sage, fontSize: 11, marginTop: 2 }}>Hidden from every analytics figure; the app works normally. Use for a second account you test with.</div>
                        </div>
                        <button style={{ ...btn(!!p.is_test), padding: "7px 12px", fontSize: 12, whiteSpace: "nowrap" }} onClick={() => toggleTestPlayer(p)}>{p.is_test ? "Turn off" : "Mark as test"}</button>
                      </div>
                    </div>

                    <div style={{ borderTop: `1px solid ${C.borderGreen}`, marginTop: 12, paddingTop: 10 }}>
                      <Eyebrow>REMOVE FROM APP</Eyebrow>
                      <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
                        {p.deactivated ? (
                          <button style={{ ...btn(true), padding: "7px 12px", fontSize: 12 }} onClick={() => reactivatePlayer(p)}>Reactivate</button>
                        ) : (
                          <button style={{ background: "#7A4E18", color: "#F6E9D6", border: "none", borderRadius: 8, padding: "7px 12px", fontWeight: 700, cursor: "pointer", fontSize: 12 }} onClick={() => deactivatePlayer(p)}>
                            Deactivate (keep data)
                          </button>
                        )}
                        {/* 208.0: "Delete permanently" removed — it deleted in five browser steps and could half-succeed
                            silently (it left Vimal's duplicate profile in place). Account actions live in Admin → Users. */}
                      </div>
                      <div style={{ color: C.sage, fontSize: 11, marginTop: 6 }}>
                        Deactivate removes them from all groups and blocks access but keeps history (reversible). To merge a duplicate, suspend or remove an account, use Admin → Users.
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
          )}
        </div>
      ))}
      {hasMore && (
        <button style={{ ...btn(false), marginTop: 10, fontSize: 13, opacity: loadingMore ? 0.62 : 1 }} disabled={loadingMore} onClick={loadMorePlayers}>
          {loadingMore ? "Loading…" : "Load more players"}
        </button>
      )}

      <div style={{ marginTop: 20 }}><AdminClubRequests user={user} /></div>

      <div style={{ marginTop: 24 }}>
        <Eyebrow>★ DELETED COURSES</Eyebrow>
        <div style={{ color: C.sage, fontSize: 12, marginTop: 8 }}>
          Courses anyone has deleted are archived here. Restore one to return it to the shared library.
        </div>
        {deletedCourses.length === 0 && (
          <div style={{ background: C.greenLight, borderRadius: 12, padding: 16, marginTop: 8, color: C.sage }}>No deleted courses.</div>
        )}
        {deletedCourses.map((c) => (
          <div key={c.id} style={{ background: C.greenLight, borderRadius: 12, padding: "12px 16px", marginTop: 8, display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: 160 }}>
              <div style={{ color: C.cream, fontWeight: 700 }}>{c.name}</div>
              <div style={{ color: C.sage, fontSize: 12 }}>{c.location ? c.location + " · " : ""}deleted {timeAgo(c.deleted_at)}</div>
            </div>
            <button style={{ ...btn(true), padding: "6px 14px", fontSize: 12 }} onClick={() => restoreCourse(c)}>Restore</button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ================= Notification bell =================
export function NotificationBell({ user, onSeeAll, onNavigate }: { user: any; onSeeAll?: () => void; onNavigate?: (link?: string | null) => void }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<any[]>([]);

  const load = useCallback(async () => {
    const { data } = await supabase.from("notifications").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(30);
    setItems(data || []);
  }, [user.id]);
  useEffect(() => { load(); }, [load]);

  const unread = items.filter((n) => !n.read).length;

  const openPanel = () => setOpen((v) => !v); // opening no longer auto-marks read — unread stays bold until acknowledged
  const markAllRead = async () => {
    setItems((xs) => xs.map((n) => ({ ...n, read: true })));
    await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
  };
  const markOne = async (id: string) => {
    setItems((xs) => xs.map((n) => (n.id === id ? { ...n, read: true } : n)));
    try { await supabase.from("notifications").update({ read: true }).eq("id", id); } catch { /* no-op */ }
  };
  const fmtNotifTime = (iso: string | null) => {
    if (!iso) return "";
    return `${timeAgo(iso)} · ${new Date(iso).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}`;
  };

  return (
    <div style={{ position: "relative" }}>
      <button onClick={openPanel} style={{ ...btn(false), fontSize: 14, padding: "8px 12px", position: "relative" }}>
        🔔
        {unread > 0 && (
          <span style={{ position: "absolute", top: -4, right: -4, background: C.birdie, color: "#fff", borderRadius: 10, fontSize: 11, fontWeight: 800, padding: "1px 6px" }}>{unread}</span>
        )}
      </button>
      {open && (
        <BottomSheet
          onClose={() => setOpen(false)}
          dismissOnBackdrop={false}
          maxWidth={440}
          scrim="rgba(0,0,0,0.5)"
          panelStyle={{ background: C.greenMid }}
          bodyStyle={{ padding: "2px 8px 12px" }}
          header={
            <>
              <div style={{ width: 40, height: 4, background: C.greenLight, borderRadius: 6, margin: "8px auto 4px" }} />
              <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 44px 10px 14px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                <Eyebrow style={{ margin: 0 }}>NOTIFICATIONS</Eyebrow>
                <span style={{ flex: 1 }} />
                {unread > 0 && (
                  <button onClick={markAllRead} style={{ background: "none", border: "none", color: C.sage, fontSize: 13, fontWeight: 700, cursor: "pointer", padding: "4px 6px" }}>Mark all read</button>
                )}
              </div>
            </>
          }
        >
          {items.length === 0 && <div style={{ color: C.sage, fontSize: 13, padding: 18, textAlign: "center" }}>Nothing yet.</div>}
          {items.map((n) => (
            <div key={n.id} onClick={() => { if (!n.read) markOne(n.id); if (n.link && onNavigate) { setOpen(false); onNavigate(n.link); } }}
              style={{ padding: "11px 8px", borderBottom: "1px solid rgba(255,255,255,0.07)", display: "flex", gap: 9, cursor: (n.link || !n.read) ? "pointer" : "default" }}>
              <span style={{ width: 7, height: 7, borderRadius: 6, background: n.read ? "transparent" : C.gold, marginTop: 5, flexShrink: 0 }} />
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ color: n.read ? "#CFC9B4" : C.cream, fontSize: 13, lineHeight: 1.4, fontWeight: n.read ? 500 : 800 }}>{n.message}</div>
                {n.detail ? <div style={{ color: "#CFC9B4", fontSize: 12, lineHeight: 1.4, marginTop: 3, whiteSpace: "pre-line", display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }}>{n.detail}</div> : null}
                <div style={{ color: C.sage, fontSize: 11, marginTop: 3 }}>{fmtNotifTime(n.created_at)}</div>
              </div>
              {n.link ? <span style={{ color: C.sage, fontSize: 18, alignSelf: "center", flexShrink: 0 }}>›</span> : null}
            </div>
          ))}
          {onSeeAll && (
            <button onClick={() => { setOpen(false); onSeeAll(); }} style={{ width: "100%", marginTop: 8, background: "none", border: "none", color: C.gold, fontSize: 13, fontWeight: 700, cursor: "pointer", padding: "10px 0" }}>See all notifications →</button>
          )}
        </BottomSheet>
      )}
    </div>
  );
}

// Exported so other parts of the app (e.g. admin score edits) can raise notifications.
export { notify };

// ================= Notifications screen (full history) =================
// A user's complete notification history, paginated. The bell shows the recent 30 as a quick
// peek; this is the durable record so nothing sent to a user is ever out of reach.
export function NotificationsScreen({ user, onNavigate }: { user: any; onNavigate?: (link?: string | null) => void }) {
  const [items, setItems] = useState<any[]>([]);
  const [limit, setLimit] = useState(30);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(false);

  const load = useCallback(async (lim: number) => {
    setLoading(true);
    const { data } = await supabase.from("notifications").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(lim);
    setItems(data || []);
    setHasMore((data || []).length === lim);
    setLoading(false);
  }, [user.id]);
  useEffect(() => { load(limit); }, [load, limit]);

  const unread = items.filter((n) => !n.read).length;
  const markAllRead = async () => {
    setItems((xs) => xs.map((n) => ({ ...n, read: true })));
    await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
  };
  const markOne = async (id: string) => {
    setItems((xs) => xs.map((n) => (n.id === id ? { ...n, read: true } : n)));
    try { await supabase.from("notifications").update({ read: true }).eq("id", id); } catch { /* no-op */ }
  };

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <h2 style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 22, fontWeight: 800 }}>Notifications</h2>
        <span style={{ flex: 1 }} />
        {unread > 0 && <button onClick={markAllRead} style={{ ...btn(false), fontSize: 13, padding: "7px 12px" }}>Mark all read</button>}
      </div>
      <div style={{ color: C.sage, fontSize: 13, marginTop: 4, marginBottom: 12 }}>{unread > 0 ? `${unread} unread` : "All caught up"}</div>
      {loading && items.length === 0 ? (
        <div style={{ color: C.sage, fontSize: 14, padding: 20, textAlign: "center" }}>Loading…</div>
      ) : items.length === 0 ? (
        <div style={{ background: C.greenLight, borderRadius: 14, padding: 28, color: C.sage, textAlign: "center" }}>No notifications yet. Anything sent your way will show up here.</div>
      ) : (
        <>
          {items.map((n) => (
            <div key={n.id} onClick={() => { if (!n.read) markOne(n.id); if (n.link && onNavigate) onNavigate(n.link); }}
              style={{ background: C.greenLight, borderRadius: 12, padding: "13px 16px", marginTop: 10, display: "flex", gap: 11, cursor: (n.link || !n.read) ? "pointer" : "default" }}>
              <span style={{ width: 8, height: 8, borderRadius: 6, background: n.read ? "transparent" : C.gold, marginTop: 6, flexShrink: 0 }} />
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ color: n.read ? C.sage : C.cream, fontSize: 14, lineHeight: 1.4, fontWeight: n.read ? 500 : 800 }}>{n.message}</div>
                {n.detail ? <div style={{ color: C.sage, fontSize: 12.5, lineHeight: 1.45, marginTop: 4, whiteSpace: "pre-line" }}>{n.detail}</div> : null}
                <div style={{ color: C.sage, fontSize: 11, marginTop: 3 }}>{notifWhen(n.created_at)}</div>
              </div>
              {n.link ? <span style={{ color: C.sage, fontSize: 20, alignSelf: "center", flexShrink: 0 }}>›</span> : null}
            </div>
          ))}
          {hasMore && (
            <button onClick={() => setLimit((l) => l + 30)} style={{ ...btn(false), width: "100%", marginTop: 12, fontSize: 13 }}>Load older</button>
          )}
        </>
      )}
      <div style={{ color: C.faint, fontSize: 12, textAlign: "center", marginTop: 18, lineHeight: 1.5 }}>
        Notifications are kept for 90 days, then removed automatically.
      </div>
    </div>
  );
}

// ================= Admin score editor =================
// Lets an admin browse a player's rounds and edit hole scores/putts.
// Saving notifies both the player and the admin.
function AdminScoreEditor({ admin, player, onBack }: { admin: any; player: any; onBack: () => void }) {
  const primary = useScoringDevice() === "primary";
  const [rounds, setRounds] = useState<Round[] | null>(null);
  const [editing, setEditing] = useState<Round | null>(null);
  const [holes, setHoles] = useState<Hole[]>([]);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    // 210.4: every row, paged — a request stops at 1,000 rows (holes reach that at ~55 rounds).
    let rs: any[] | null = null;
    try { rs = await fetchAll<any>((f, t) => supabase.from("rounds").select("*").eq("user_id", player.id).is("deleted_at", null).order("played_at", { ascending: false }).order("id").range(f, t)); }
    catch { try { rs = await fetchAll<any>((f, t) => supabase.from("rounds").select("*").eq("user_id", player.id).order("played_at", { ascending: false }).order("id").range(f, t)); } catch { rs = null; } }
    if (!rs) { setRounds([]); return; }
    const ids = rs.map((r: any) => r.id);
    let hs: any[] = [];
    try { hs = await fetchAllIn<any>(supabase, "holes", "round_id", ids); } catch { hs = []; }
    const byRound: Record<string, Hole[]> = {};
    (hs || []).forEach((h: any) => { (byRound[h.round_id] ||= []).push(h); });
    const merged: Round[] = rs.map((r: any) => ({
      ...r,
      holes: dedupeHoles(byRound[r.id] || []).sort((a, b) => a.hole_number - b.hole_number)
        // Through chBasis, exactly as a game does (0154). Reading r.course_handicap directly meant a
        // round had its own handicap rule: no manual override, and no nine-hole halving of a derived
        // figure. One function now serves rounds and games alike.
        .map((h, _i, all) => ({ ...h, recv: strokesReceived(h.stroke_index, roundCh(r, all.length), all) })),
    }));
    setRounds(merged);
  }, [player.id]);
  useEffect(() => { load(); }, [load]);

  const openRound = (r: Round) => { setEditing(r); setHoles(r.holes.map((h) => ({ ...h }))); setMsg(null); setChEdit(null); };

  /** Set or clear a round's manual course handicap, mirroring the game-side control (0154). */
  const saveRoundHandicap = async (value: number | null) => {
    if (!editing || !isPrimaryScoringDevice()) return;
    const patch = value == null
      ? { course_handicap_source: "derived", course_handicap_set_by: null, course_handicap_set_at: null }
      : { course_handicap: value, course_handicap_source: "manual", course_handicap_set_by: player.id, course_handicap_set_at: new Date().toISOString() };
    const { error } = await supabase.from("rounds").update(patch).eq("id", editing.id);
    if (error) { setMsg(error.message); return; }
    setChEdit(null);
    await load();
    setMsg("Course handicap updated.");
  };
  const [chEdit, setChEdit] = useState<string | null>(null);
  const setHole = (i: number, patch: Partial<Hole>) => { if (isPrimaryScoringDevice()) setHoles((hs) => hs.map((h, j) => (j === i ? { ...h, ...patch } : h))); };

  const saveRound = async () => {
    if (!editing || !isPrimaryScoringDevice()) return;
    setSaving(true); setMsg(null);
    try {
      for (const h of holes) {
        const { error } = await supabase.from("holes")
          .update({ strokes: h.strokes, putts: h.putts, fairway: h.fairway, penalties: h.penalties })
          .eq("round_id", editing.id).eq("hole_number", h.hole_number);
        if (error) throw error;
      }
      const who = player.display_name || "the player";
      // Say WHICH holes changed and from what: the player can check the card against it.
      const changes = holes.flatMap((h) => {
        const o = editing.holes.find((x) => x.hole_number === h.hole_number);
        const parts: string[] = [];
        if (o && (o.strokes ?? null) !== (h.strokes ?? null)) parts.push(`${o.strokes ?? "—"}→${h.strokes ?? "—"}`);
        if (o && (o.putts ?? null) !== (h.putts ?? null)) parts.push(`putts ${o.putts ?? "—"}→${h.putts ?? "—"}`);
        return parts.length ? [`hole ${h.hole_number}: ${parts.join(", ")}`] : [];
      });
      const detail = changes.length ? changes.join("; ") : "no hole values changed";
      const adminName = await myLabel(admin);
      await notify(player.id, `${adminName} edited your scores for ${editing.course} (${fmtDate(editing.played_at)}): ${changes.length} hole${changes.length === 1 ? "" : "s"} changed.`, detail);
      await notify(admin.id, `You edited ${who}'s scores for ${editing.course} (${fmtDate(editing.played_at)}).`, detail);
      setMsg("Saved & player notified ✓");
      await load();
      setEditing(null);
    } catch (e: any) {
      setMsg(failureMessage("Couldn't save", e));
    } finally {
      setSaving(false);
    }
  };

  if (editing) {
    return (
      <div style={{ marginTop: 24 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <button style={btn(false)} onClick={() => setEditing(null)}>‹ Back</button>
          <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 20 }}>Admin edit · {player.display_name}</div>
        </div>
        <div style={{ background: C.danger, color: "#F6DEDB", borderRadius: 10, padding: "8px 12px", marginTop: 10, fontSize: 12 }}>
          ⚠ Admin mode — you are editing another player's official scores. They will be notified.
        </div>
        <div style={{ color: C.sage, fontSize: 13, marginTop: 10 }}>{editing.course}{editing.tee_name ? ` · ${editing.tee_name}` : ""} · {fmtDate(editing.played_at)}</div>
        {(() => {
          // Manual course handicap for a ROUND (0154). Labelled with the round's own hole count: the
          // number entered IS the figure for that many holes and is used as given, so an 18-hole
          // number typed against a nine is wrong by a factor of two and looks entirely plausible.
          const holes = editing.holes?.length === 9 ? 9 : 18;
          const isManual = editing.course_handicap_source === "manual";
          const derived = Math.round(chBasis({ ...editing, course_handicap_source: "derived" }, editing.course_par, holes));
          return (
            <div style={{ background: C.card, borderRadius: 12, padding: 12, marginTop: 10 }}>
              <label style={{ color: C.faint, fontSize: 11, letterSpacing: 1 }}>{holes}-HOLE COURSE HANDICAP</label>
              <div style={{ display: "flex", gap: 6, alignItems: "center", marginTop: 4 }}>
                <input
                  inputMode="decimal"
                  placeholder={String(derived)}
                  value={chEdit ?? (isManual && editing.course_handicap != null ? String(editing.course_handicap) : "")}
                  onChange={(e) => { const v = e.target.value; if (v === "" || /^-?\d*\.?\d*$/.test(v)) setChEdit(v); }}
                  style={{ ...inputStyle, padding: "8px 12px", width: 74, textAlign: "center" }}
                />
                <button style={btn(true)} disabled={!primary} onClick={() => saveRoundHandicap(chEdit === "" || chEdit == null ? null : Number(chEdit))}>
                  {chEdit === "" ? "Clear" : "Set"}
                </button>
                {/* This card is CREAM. C.sage and C.gold are tuned for the dark green ground and
                    measure 1.7:1 and ~2.3:1 here — the same trap that made the group scorecard's
                    second dot row invisible. Ink and faint are the light-ground pair. */}
                <span style={{ color: isManual ? C.ink : C.faint, fontWeight: isManual ? 700 : 400, fontSize: 12 }}>
                  {isManual ? `manual \u00b7 used as entered for ${holes} holes` : `derived: ${derived}`}
                </span>
              </div>
            </div>
          );
        })()}
        <div style={{ background: C.card, borderRadius: 12, padding: 12, marginTop: 10 }}>
          <div style={{ display: "grid", gridTemplateColumns: "44px 40px 1fr 1fr", gap: 6, padding: "0 2px 6px", color: C.faint, fontSize: 11, letterSpacing: 1, fontWeight: 700, borderBottom: `1px solid ${C.borderCard}` }}>
            <div>HOLE</div><div style={{ textAlign: "center" }}>PAR</div><div style={{ textAlign: "center" }}>SCORE</div><div style={{ textAlign: "center" }}>PUTTS</div>
          </div>
          {holes.map((h, i) => {
            const subtotalAfter = (i === 8 && holes.length > 9) || i === holes.length - 1;
            const segStart = i < 9 ? 0 : 9;
            const seg = holes.slice(segStart, i + 1);
            const sPar = seg.reduce((s, x) => s + (x.par || 0), 0);
            const sScore = seg.reduce((s, x) => s + (x.strokes || 0), 0);
            const sPutts = seg.reduce((s, x) => s + (x.putts || 0), 0);
            return (
              <React.Fragment key={i}>
                <div style={{ display: "grid", gridTemplateColumns: "44px 40px 1fr 1fr", gap: 6, alignItems: "center", padding: "5px 2px", borderBottom: `1px solid ${C.borderCard}` }}>
                  <div style={{ color: C.ink, fontWeight: 800, fontSize: 15 }}>{h.hole_number}</div>
                  <div style={{ textAlign: "center", color: C.parBlue, fontWeight: 700 }}>{h.par}</div>
                  <div style={{ textAlign: "center" }}>
                    <NumPicker value={h.strokes} from={1} to={maxHoleScore(h.par)} onChange={(v) => setHole(i, { strokes: v })} width={52} />
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <NumPicker value={h.putts} from={0} to={h.strokes && h.strokes > 0 ? Math.min(h.strokes, 6) : 6} onChange={(v) => setHole(i, { putts: v })} width={52} />
                  </div>
                </div>
                {subtotalAfter && (
                  <div style={{ display: "grid", gridTemplateColumns: "44px 40px 1fr 1fr", gap: 6, padding: "6px 2px", background: C.greenLight, borderTop: `2px solid ${C.borderGreen}`, fontWeight: 800 }}>
                    <div style={{ color: C.gold, fontSize: 11 }}>{segStart === 0 ? "OUT" : "IN"}</div>
                    <div style={{ textAlign: "center", color: C.cream }}>{sPar}</div>
                    <div style={{ textAlign: "center", color: C.cream }}>{sScore || "–"}</div>
                    <div style={{ textAlign: "center", color: C.sage }}>{sPutts || "–"}</div>
                  </div>
                )}
              </React.Fragment>
            );
          })}
          {holes.length > 9 && (() => {
            const tot = holes.reduce((s, x) => s + (x.strokes || 0), 0);
            const totPutts = holes.reduce((s, x) => s + (x.putts || 0), 0);
            return (
              <div style={{ display: "grid", gridTemplateColumns: "44px 40px 1fr 1fr", gap: 6, padding: "7px 2px", background: C.green, fontWeight: 800 }}>
                <div style={{ color: C.cream, fontSize: 11 }}>TOTAL</div>
                <div />
                <div style={{ textAlign: "center", color: "#fff" }}>{tot || "–"}</div>
                <div style={{ textAlign: "center", color: C.cream }}>{totPutts || "–"}</div>
              </div>
            );
          })()}
        </div>
        {msg && <div style={{ color: C.gold, fontSize: 12, marginTop: 8 }}>{msg}</div>}
        <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
          <button style={btn(false)} onClick={() => setEditing(null)}>Cancel</button>
          <button style={{ ...btn(true), opacity: saving ? 0.62 : 1 }} disabled={saving || !primary} onClick={saveRound}>{saving ? "Saving…" : "Save changes"}</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ marginTop: 24 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <button style={btn(false)} onClick={onBack}>‹ Players</button>
        <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 20 }}>{player.display_name}'s rounds</div>
      </div>
      {rounds === null && <div style={{ color: C.sage, marginTop: 12 }}>Loading…</div>}
      {rounds?.length === 0 && <div style={{ color: C.sage, marginTop: 12 }}>This player has no rounds.</div>}
      {rounds?.map((r) => (
        <div key={r.id} onClick={() => openRound(r)} style={{ background: C.card, borderRadius: 12, padding: "12px 16px", marginTop: 8, cursor: "pointer", display: "flex", alignItems: "center" }}>
          <div style={{ flex: 1 }}>
            <div style={{ color: C.ink, fontWeight: 700 }}>{r.course}</div>
            <div style={{ color: C.faint, fontSize: 12 }}>{fmtDate(r.played_at)} · {played(r).length} holes</div>
          </div>
          <div style={{ color: C.green, fontWeight: 800, fontFamily: "Georgia, serif", fontSize: 18 }}>{played(r).length ? strokesOf(r) : "—"}</div>
        </div>
      ))}
    </div>
  );
}

// ================= Players directory =================
// Everyone can see who else has access: name, handicap (if set), and phone to reach them.
export function PlayersTab({ user, activeGroupId, isGroupAdmin, onChanged, directoryTools = false, onSummary, summaryNow }: { user: any; activeGroupId: string; isGroupAdmin: boolean; onChanged?: () => void; directoryTools?: boolean; onSummary?: (value: ClubDirectorySummary | null) => void; summaryNow?: number }) {
  const [players, setPlayers] = useState<any[] | null>(null);
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [cardMember, setCardMember] = useState<any | null>(null);

  const [loadError, setLoadError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "admin" | "invited" | "handicap">("all");
  const request = React.useRef(0);
  const load = useCallback(async () => {
    const version = ++request.current;
    setLoadError(null);
    try {
      const rows = await loadClubDirectory(supabase, activeGroupId);
      if (version === request.current) setPlayers(rows);
    } catch (e: any) {
      if (version === request.current) setLoadError(failureMessage("Couldn't load the club members", e));
    }
  }, [activeGroupId]);
  useEffect(() => {
    setPlayers(null); setQuery(""); setFilter("all"); setEdits({}); setCardMember(null);
    void load();
    return () => { request.current++; };
  }, [load]);
  const summary = React.useMemo(() => players ? clubDirectorySummary(players, summaryNow ?? 0) : null, [players, summaryNow]);
  useEffect(() => { onSummary?.(summary); }, [onSummary, summary]);
  const visible = directoryTools && players ? filterClubDirectory(players, query, filter) : players;

  // Group admin: set a member's handicap index (updates their profile; notifies them).
  const saveHandicap = async (row: any) => {
    const raw = edits[row.id];
    if (!isGroupAdmin || raw === undefined || !row.user_id) return;
    const idx = raw.trim() === "" ? null : parseFloat(raw);
    setBusyId(row.id); setMsg(null);
    const { error } = await supabase.from("profiles").update({ handicap_index: idx }).eq("id", row.user_id);
    // Raw provider text ("TypeError: Load failed" on Safari) says nothing a user can act on.
    if (error) { setMsg(failureMessage("Couldn't save this handicap", error)); setBusyId(null); return; }
    if (row.user_id !== user.id) await notify(row.user_id, `Your handicap index was set to ${idx ?? "—"} by a group admin.`);
    await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Group admin", action: "handicap_changed", group_id: activeGroupId, target_user_id: row.user_id, summary: `Set ${row.profiles?.display_name || row.email}'s handicap to ${idx ?? "—"}` });
    setBusyId(null);
    await load();
    setMsg("Handicap updated.");
  };

  // Group admin: promote/demote within the group.
  const toggleRole = async (row: any) => {
    if (!isGroupAdmin || row.user_id === user.id) return;
    setBusyId(row.id); setMsg(null);
    const { error } = await supabase.from("group_members").update({ role: row.role === "admin" ? "member" : "admin" }).eq("id", row.id);
    if (error) { setMsg(failureMessage("Couldn't change this role", error)); setBusyId(null); return; }
    await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Group admin", action: "role_changed", group_id: activeGroupId, target_user_id: row.user_id, summary: `Changed ${row.profiles?.display_name || row.email} to ${row.role === "admin" ? "member" : "club admin"}` });
    setBusyId(null);
    await load(); onChanged?.();
  };

  // Group admin: remove a member from THIS group (does not delete their account or other groups).
  const removeFromGroup = async (row: any) => {
    if (!isGroupAdmin || row.user_id === user.id) return;
    if (!(await askConfirm(`Remove ${row.profiles?.display_name || row.email} from this club?\n\nThis only affects this club — their account and other clubs are untouched.`))) return;
    setBusyId(row.id); setMsg(null);
    const { error } = await supabase.from("group_members").update({ status: "removed" }).eq("id", row.id);
    if (error) { setMsg(failureMessage("Couldn't remove this member", error)); setBusyId(null); return; }
    if (row.user_id && row.user_id !== user.id) await notify(row.user_id, `You were removed from a group by an admin.`);
    await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Group admin", action: "member_removed", group_id: activeGroupId, target_user_id: row.user_id, summary: `Removed ${row.profiles?.display_name || row.email} from a group` });
    setBusyId(null);
    await load(); onChanged?.();
  };

  return (
    <div>
      <Eyebrow>{directoryTools ? "MEMBERS" : "PLAYERS · CURRENT CLUB"}</Eyebrow>
      <div style={{ color: C.sage, fontSize: 12, marginTop: 8 }}>
        Members and invited players in the selected group. Tap a phone number to call or text.
        {isGroupAdmin ? " As a club admin you can set handicaps, change roles, and remove players from this club." : ""}
      </div>
      {msg && <div style={{ color: C.gold, fontSize: 12, marginTop: 10 }}>{msg}</div>}
      {directoryTools && <div style={{ marginTop: 12 }}>
        <input aria-label="Search club members" placeholder="Search by name, email, phone or GHIN" value={query} onChange={(e) => setQuery(e.target.value)} style={{ ...inputStyle, width: "100%", fontSize: 14 }} />
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 10 }}>
          {([["all", "All"], ["admin", "Club admins"], ["invited", "Invited"], ...(isGroupAdmin ? [["handicap", "Missing handicap"]] : [])] as [typeof filter, string][]).map(([id, text]) => <button key={id} type="button" aria-pressed={filter === id} onClick={() => setFilter(id)} style={{ ...btn(filter === id), fontSize: 11, padding: "8px 12px", minHeight: 30 }}>{text}</button>)}
        </div>
        {isGroupAdmin && <div style={{ color: C.sage, fontSize: 11, marginTop: 8 }}>Invited players have not joined yet. Shared invitation links are not included in this count.</div>}
      </div>}
      {loadError && <div role="alert" style={{ color: C.cream, background: C.greenLight, borderRadius: 8, padding: 12, marginTop: 12 }}>{loadError} <button type="button" style={{ ...btn(false), fontSize: 12 }} onClick={() => void load()}>Retry</button></div>}
      {players === null && !loadError && <div style={{ color: C.sage, marginTop: 14 }}>Loading…</div>}
      {players?.length === 0 && <div style={{ color: C.sage, marginTop: 14 }}>No players yet.</div>}
      {players && players.length > 0 && visible?.length === 0 && <div style={{ color: C.sage, marginTop: 14 }}>No matching members.</div>}
      {visible?.map((row: any) => {
        const p = row.profiles || {};
        const self = row.user_id === user.id;
        return (
          <div key={row.id} style={{ background: C.greenLight, borderRadius: 12, padding: "12px 16px", marginTop: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
              <button
                onClick={() => row.user_id && setCardMember(row)}
                disabled={!row.user_id}
                title={row.user_id ? "View player card" : undefined}
                style={{ display: "flex", alignItems: "center", gap: 12, flex: 1, minWidth: 150, background: "transparent", border: "none", padding: 0, textAlign: "left", cursor: row.user_id ? "pointer" : "default" }}
              >
                <Avatar src={row.avatar_url} name={p.display_name || row.email || "?"} size={32} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ color: C.cream, fontWeight: 700, fontSize: 15 }}>{p.display_name || row.email}{self ? " (you)" : ""}{row.role === "admin" ? " · admin" : ""}</div>
                  <div style={{ color: C.sage, fontSize: 12 }}>
                    {p.handicap_index != null ? `Handicap ${p.handicap_index}` : row.status === "invited" ? "Invited" : "No handicap set"}
                    {p.ghin_number ? ` · GHIN ${p.ghin_number}` : ""}
                  </div>
                </div>
              </button>
              {p.phone ? (
                <a href={`tel:${p.phone}`} style={{ color: C.cream, fontWeight: 700, fontSize: 14, textDecoration: "none", background: C.greenLight, borderRadius: 8, padding: "8px 12px" }}>{p.phone}</a>
              ) : !p.display_name ? (
                <span style={{ color: C.sage, fontSize: 12 }}>{row.email}</span>
              ) : null}
            </div>

            {isGroupAdmin && row.user_id && (
              <div style={{ display: "flex", gap: 8, marginTop: 10, alignItems: "flex-end", flexWrap: "wrap", borderTop: `1px solid ${C.borderCard}`, paddingTop: 10 }}>
                <div>
                  <label style={{ color: C.sage, fontSize: 11 }}>Handicap index</label>
                  <div style={{ display: "flex", gap: 6, marginTop: 2 }}>
                    <input inputMode="decimal" defaultValue={p.handicap_index != null ? String(p.handicap_index) : ""}
                      onChange={(e) => { const v = e.target.value; if (v === "" || /^\d*\.?\d*$/.test(v)) setEdits((m) => ({ ...m, [row.id]: v })); }}
                      style={{ ...inputStyle, padding: "6px 8px", width: 78, textAlign: "center" }} />
                    <button style={{ ...btn(true), padding: "6px 10px", fontSize: 12, opacity: busyId === row.id ? 0.62 : 1 }} disabled={busyId === row.id} onClick={() => saveHandicap(row)}>Set</button>
                  </div>
                </div>
                <div style={{ flex: 1 }} />
                {!self && (
                  <>
                    <button style={{ ...btn(false), padding: "7px 10px", fontSize: 12 }} disabled={busyId === row.id} onClick={() => toggleRole(row)}>{row.role === "admin" ? "Remove club admin" : "Make club admin"}</button>
                    <button style={{ ...btn(false), padding: "7px 10px", fontSize: 12, color: C.overRedDark }} disabled={busyId === row.id} onClick={() => removeFromGroup(row)}>Remove</button>
                  </>
                )}
              </div>
            )}
          </div>
        );
      })}
      {cardMember && <PeerCardModal member={cardMember} groupId={activeGroupId} viewerUserId={user.id} onClose={() => setCardMember(null)} />}
    </div>
  );
}

// ================= Admin Activity (audit trail) =================
// System tools (master admin): test-account toggle + course yardage backfill.
function SystemTools({ user }: { user: any }) {
  const [isTest, setIsTest] = useState<boolean | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => {
    supabase.from("profiles").select("is_test").eq("id", user.id).maybeSingle().then(({ data }: any) => setIsTest(!!data?.is_test));
  }, [user.id]);
  return (
    <div>
      <div style={{ background: C.greenLight, borderRadius: 12, padding: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div style={{ color: C.cream, fontSize: 13, fontWeight: 700 }}>Test account {isTest == null ? "" : isTest ? "· ON" : "· off"}</div>
            <div style={{ color: C.sage, fontSize: 12, lineHeight: 1.5, marginTop: 3 }}>
              When on, this account works normally but is excluded from every analytics figure — use it for feature testing so your stats stay clean.
            </div>
          </div>
          <button
            onClick={async () => {
              const next = !isTest; setIsTest(next);
              const { error } = await supabase.rpc("admin_set_test", { p_user: user.id, p_is_test: next });
              if (error) { setIsTest(!next); setMsg(failureMessage("Couldn't update test mode", error)); }
            }}
            style={{ ...btn(!!isTest), fontSize: 12, padding: "8px 14px", whiteSpace: "nowrap" }}
          >{isTest ? "Turn off" : "Turn on"}</button>
        </div>
        {msg && <div style={{ color: C.gold, fontSize: 12, marginTop: 10 }}>{msg}</div>}
      </div>
      <div style={{ marginTop: 14 }}><YardageBackfill /></div>
    </div>
  );
}

// Consolidated admin hub. Two tiers: Club admin (any admin of the active club, scoped to
// that club) and System Admin (master only). Reuses every existing panel;
// club cards jump to the shared tabs, system cards render the panel inline.
// ★ Stage-2 analytics: new drillable summary tiles (platform, notifications, sharing, guests).
// Counts from get_admin_extra_stats (0091); every tile drills via the shared engine (0090).
export function AdminExtraStats() {
  const read = useAnalyticsRpc(supabase, "get_admin_extra_stats");
  const x = read.data;
  if (!x) return <AnalyticsReadStatus {...read} />;

  const tile = (n: React.ReactNode, l: string, stat: string, cap?: string, arg?: string) => (
    <button onClick={() => openStatDrill({ stat, title: l, cap, arg })}
      style={{ background: C.greenLight, border: "none", borderRadius: 12, padding: "11px 12px", flex: 1, minWidth: 92, textAlign: "left", color: C.cream, cursor: "pointer", position: "relative" }}>
      <span style={{ position: "absolute", right: 8, top: 8, color: C.gold, fontSize: 11, fontWeight: 800 }}>who ›</span>
      <div style={{ color: C.cream, fontWeight: 800, fontSize: 22, fontFamily: "Georgia, serif" }}>{n}</div>
      <div style={{ color: C.sage, fontSize: 11 }}>{l}</div>
    </button>
  );
  const hdr = (t: string, c: string) => (
    <div style={{ margin: "18px 0 8px" }}>
      <span style={{ fontFamily: "Georgia, serif", fontSize: 16, fontWeight: 700, color: C.cream }}>{t}</span>
      <span style={{ color: C.sage, fontSize: 11 }}> · {c}</span>
    </div>
  );

  const mutes: Record<string, number> = x.mutes || {};
  const mutedTypes = NOTIF_TYPES.map((t) => ({ ...t, n: mutes[t.key] || 0 })).filter((t) => t.n > 0).sort((a, b) => b.n - a.n);

  return (
    <div><AnalyticsReadStatus {...read} />
      {hdr("Platform", "how people open BNN")}
      <div style={{ display: "flex", gap: 10 }}>
        {tile(x.installed ?? 0, "Last opened as app", "installed", "Latest open = home-screen app")}
        {tile(x.browser ?? 0, "Last opened in browser", "browser", "Latest open = browser tab")}
      </div>
      <div style={{ color: C.faint, fontSize: 11, marginTop: 6 }}>
        {x.platform_unknown ? `${x.platform_unknown} not yet recorded \u00b7 ` : ""}counts forward from launch — no backfill.
      </div>

      {hdr("Notifications", "push reach & health")}
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        {tile(x.notif_on ?? 0, "Notifications on", "notif_on", "Has an active push device")}
        {tile(x.notif_off ?? 0, "Off / none", "notif_off", "No active push device")}
      </div>
      <AdminPushDeliveries />
      <div style={{ display: "flex", gap: 10, marginTop: 10, flexWrap: "wrap" }}>
        {tile(x.push?.failing_endpoints ?? 0, "Failing devices", "push_failing", "3+ delivery failures or disabled")}
        {tile(x.push?.dormant_endpoints ?? 0, "Dormant endpoints", "push_dormant", `Not seen 14+ days · ${x.push?.dormant_users ?? 0} user${(x.push?.dormant_users ?? 0) === 1 ? "" : "s"} with no current device · pruned after ${x.push?.prune_after_days ?? 60} days`)}
      </div>
      {mutedTypes.length ? (
        <>
          <div style={{ color: C.sage, fontSize: 12, marginTop: 12, marginBottom: 2 }}>Most-muted types (tap for who)</div>
          <div style={{ background: C.greenLight, borderRadius: 12, padding: 6 }}>
            {mutedTypes.map((t, i) => (
              <div key={t.key} onClick={() => openStatDrill({ stat: "mute", arg: t.key, title: t.label, cap: "Users who set this to Off" })}
                style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 10px", borderTop: i ? `1px solid ${C.greenMid}` : "none", cursor: "pointer" }}>
                <span style={{ fontSize: 13, color: C.cream }}>{t.label}</span>
                <span style={{ color: C.gold, fontFamily: "Georgia, serif", fontWeight: 800, fontSize: 15 }}>{t.n} ›</span>
              </div>
            ))}
          </div>
        </>
      ) : null}

      {hdr("Profile sharing", "peer-visible player card")}
      <div style={{ display: "flex", gap: 10 }}>
        {tile(x.share_on ?? 0, "Sharing on", "share_on", "Card visible to peers")}
        {tile(x.share_off ?? 0, "Turned off", "share_off", "Opted out of the card")}
      </div>

      {hdr("Guests", "non-registered players")}
      <div style={{ display: "flex", gap: 10 }}>
        {tile(x.guests ?? 0, x.guest_hosts ? `Guest rounds \u00b7 ${x.guest_hosts} hosts` : "Guest rounds", "guests", "Hosts who brought guests")}
      </div>
    </div>
  );
}

// ★ Stage-3 analytics: Daily report. Pick a day; see active users + that day's rounds, both
// drillable. Reuses engine branches active_day / rounds_day (0090) — no new migration. Counts
// are just the length of those lists; the inline list is the rounds_day rows color-coded by status.
export function AdminDailyReport() {
  const [days, setDays] = useState<{ label: string; iso: string }[]>([]);
  const [sel, setSel] = useState<string>("");
  const activeRead = useAnalyticsRpc(supabase, "admin_stat_users", { p_stat: "active_day", p_arg: null, p_date: sel || null }, ["name", "detail", "tag"]);
  const roundsRead = useAnalyticsRpc(supabase, "admin_stat_users", { p_stat: "rounds_day", p_arg: null, p_date: sel || null }, ["name", "detail", "tag"]);
  const active: any[] | null = activeRead.data;
  const rounds: any[] | null = roundsRead.data;

  useEffect(() => {
    // Days are US Eastern (America/New_York) for everyone — "Today" is the same midnight-to-midnight
    // window no matter the viewer's device timezone, matching the DAU tiles (which now anchor ET too).
    const east = new Intl.DateTimeFormat("en-CA", { timeZone: "America/New_York" }).format(new Date()); // YYYY-MM-DD
    const [Y, M, D] = east.split("-").map(Number);
    const arr: { label: string; iso: string }[] = [];
    for (let i = 0; i < 7; i++) {
      const dt = new Date(Date.UTC(Y, M - 1, D)); dt.setUTCDate(dt.getUTCDate() - i);
      const iso = dt.toISOString().slice(0, 10);
      arr.push({ iso, label: i === 0 ? "Today" : i === 1 ? "Yesterday" : dt.toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" }) });
    }
    setDays(arr); setSel(arr[0].iso);
  }, []);

  const dotColor = (tag: string) =>
    tag === "completed" ? "#5BBE7E" : tag === "in progress" ? C.gold : tag === "auto-finished" ? "#5AA9E6" : tag === "deleted" ? C.birdie : C.sage;
  const selLabel = days.find((d) => d.iso === sel)?.label || sel;
  const dot = (bg: string) => <span style={{ display: "inline-block", width: 8, height: 8, borderRadius: "50%", background: bg, marginRight: 4 }} />;

  return (
    <div><AnalyticsReadStatus {...activeRead} /><AnalyticsReadStatus {...roundsRead} />
      <div style={{ margin: "18px 0 8px" }}>
        <span style={{ fontFamily: "Georgia, serif", fontSize: 16, fontWeight: 700, color: C.cream }}>Daily report</span>
        <span style={{ color: C.sage, fontSize: 11 }}> · pick a day</span>
      </div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        {days.map((d) => (
          <button key={d.iso} onClick={() => setSel(d.iso)}
            style={{ fontSize: 11, fontWeight: 700, borderRadius: 999, padding: "5px 11px", border: "none", cursor: "pointer",
              background: sel === d.iso ? C.gold : C.greenLight, color: sel === d.iso ? C.green : C.cream }}>{d.label}</button>
        ))}
        <input type="date" value={sel} max={days[0]?.iso} onChange={(e) => setSel(e.target.value)}
          style={{ ...inputStyle, fontSize: 11, padding: "4px 8px", width: "auto", WebkitAppearance: "none", appearance: "none" }} />
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
        <button onClick={() => openStatDrill({ stat: "active_day", title: `Active · ${selLabel}`, cap: "Users who opened BNN that day", date: sel })}
          style={{ flex: 1, background: C.greenLight, border: "none", borderRadius: 12, padding: "11px 12px", textAlign: "left", cursor: "pointer", position: "relative" }}>
          <span style={{ position: "absolute", right: 8, top: 8, color: C.gold, fontSize: 11, fontWeight: 800 }}>who ›</span>
          <div style={{ color: C.cream, fontWeight: 800, fontSize: 22, fontFamily: "Georgia, serif" }}>{active ? active.length : "…"}</div>
          <div style={{ color: C.sage, fontSize: 11 }}>Active users</div>
        </button>
        <button onClick={() => openStatDrill({ stat: "rounds_day", title: `Rounds · ${selLabel}`, cap: "Round records that day", date: sel })}
          style={{ flex: 1, background: C.greenLight, border: "none", borderRadius: 12, padding: "11px 12px", textAlign: "left", cursor: "pointer", position: "relative" }}>
          <span style={{ position: "absolute", right: 8, top: 8, color: C.gold, fontSize: 11, fontWeight: 800 }}>list ›</span>
          <div style={{ color: C.cream, fontWeight: 800, fontSize: 22, fontFamily: "Georgia, serif" }}>{rounds ? rounds.length : "…"}</div>
          <div style={{ color: C.sage, fontSize: 11 }}>Round records</div>
        </button>
      </div>

      {rounds && rounds.length > 0 ? (
        <div style={{ background: C.greenLight, borderRadius: 12, padding: 6, marginTop: 10 }}>
          {rounds.map((r: any, i: number) => (
            <div key={i} onClick={() => openStatDrill({ stat: "rounds_day", title: `Rounds · ${selLabel}`, cap: "Round records that day", date: sel })}
              style={{ display: "flex", alignItems: "center", gap: 8, padding: "9px 8px", borderTop: i ? `1px solid ${C.greenMid}` : "none", cursor: "pointer" }}>
              <span style={{ width: 8, height: 8, borderRadius: "50%", flex: "0 0 8px", background: dotColor(r.tag) }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13, color: C.cream, fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.name}</div>
                <div style={{ fontSize: 11, color: C.sage }}>{r.detail} · {r.tag}</div>
              </div>
            </div>
          ))}
        </div>
      ) : rounds && rounds.length === 0 ? (
        <div style={{ color: C.faint, fontSize: 12, marginTop: 10 }}>No rounds played on {selLabel}.</div>
      ) : null}

      <div style={{ color: C.faint, fontSize: 11, marginTop: 8, lineHeight: 1.7 }}>
        {dot("#5BBE7E")}completed &nbsp; {dot(C.gold)}in progress &nbsp; {dot("#5AA9E6")}auto-finished &nbsp; {dot(C.birdie)}deleted / issue
        <div style={{ marginTop: 4 }}>Days run midnight–midnight US Eastern. Round records include unfinished/deleted records for diagnosis; they are separate from completed-participation totals.</div>
      </div>
    </div>
  );
}

// ★ Friction review: the daily integrity sweep's findings, with review + resolve. Reads
// get_friction_items / get_friction_rounds and writes via resolve_friction (all is_admin-gated).
const FRICTION_KIND: Record<string, { label: string; bg: string; fg: string }> = {
  dup_day:     { label: "duplicate",   bg: "#5AA9E6",   fg: "#06251a" },
  dup_game:    { label: "game dup",    bg: "#C58BE0",   fg: "#06251a" },
  multi_draft: { label: "multi-draft", bg: C.gold,      fg: C.green },
  integrity:   { label: "integrity",   bg: C.birdie,    fg: "#ffffff" },
};

function FrictionItem({ it, onDone }: { it: any; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [rounds, setRounds] = useState<any[] | null>(null);
  const [keep, setKeep] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const isCluster = it.kind === "dup_day" || it.kind === "dup_game" || it.kind === "multi_draft";
  const meta = FRICTION_KIND[it.kind] || { label: it.kind, bg: C.greenMid, fg: C.cream };
  const resolved = it.status === "cleared" || it.status === "auto_resolved" || it.status === "needs_action";

  const expand = async () => {
    const next = !open; setOpen(next);
    if (next && !rounds && isCluster) {
      const { data } = await rpcAll(supabase, "get_friction_rounds", { p_id: it.id }, "round_id");
      const rows = data || []; setRounds(rows);
      const rec = rows.find((r: any) => r.recommended); if (rec) setKeep(rec.round_id);
    }
  };
  const resolve = async (status: string, soft: boolean) => {
    setBusy(true);
    await supabase.rpc("resolve_friction", { p_id: it.id, p_status: status, p_reason: note || null, p_keep: keep, p_soft_delete: soft });
    setBusy(false); onDone();
  };
  const when = it.first_seen ? new Date(it.first_seen).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "";

  return (
    <div style={{ background: C.greenLight, borderRadius: 14, padding: 12, marginBottom: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontWeight: 700, fontSize: 15, color: C.cream }}>{it.subject_name}</span>
        <span style={{ marginLeft: "auto", fontSize: 11, fontWeight: 800, borderRadius: 6, padding: "1px 6px", background: meta.bg, color: meta.fg }}>{meta.label}</span>
      </div>
      <div style={{ color: C.cream, fontSize: 12.5, margin: "8px 0 3px", lineHeight: 1.5 }}>{it.detail}</div>
      {resolved ? (
        <div style={{ color: C.sage, fontSize: 11, marginTop: 4 }}>
          {it.status === "auto_resolved" ? "Auto-resolved — the data was cleaned up." : `${it.status === "cleared" ? "Cleared" : "Needs action"}${it.reason ? " · " + it.reason : ""}`}
          {it.reviewed_at ? " · " + new Date(it.reviewed_at).toLocaleDateString(undefined, { month: "short", day: "numeric" }) : ""}
        </div>
      ) : (
        <>
          <div style={{ color: C.sage, fontSize: 11, marginBottom: 8 }}>first seen {when}</div>
          <button onClick={expand} style={{ background: C.gold, color: C.green, border: "none", borderRadius: 8, padding: "7px 14px", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
            {open ? "Close" : "Review \u2192"}
          </button>
          {open ? (
            <div style={{ borderTop: `1px solid ${C.borderGreen}`, marginTop: 10, paddingTop: 10 }}>
              {isCluster ? (
                <>
                  <div style={{ color: C.sage, fontSize: 11, marginBottom: 6 }}>{it.kind === "multi_draft" ? "Which draft to keep (if any)?" : "Which round to keep?"}</div>
                  <div style={{ background: C.green, borderRadius: 8, padding: 6, marginBottom: 8 }}>
                    {(rounds || []).map((r: any) => {
                      const sel = keep === r.round_id;
                      return (
                        <div key={r.round_id} onClick={() => setKeep(r.round_id)}
                          style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 6px", cursor: "pointer" }}>
                          <span style={{ width: 14, height: 14, borderRadius: "50%", flex: "0 0 14px", border: `2px solid ${sel ? C.gold : C.sage}`, background: sel ? C.gold : "transparent" }} />
                          <span style={{ fontSize: 11.5, color: sel ? C.cream : C.sage, flex: 1 }}>
                            {r.course || "round"} · {new Date(r.created_at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} · {r.scored} holes{r.gross != null ? " \u00b7 gross " + r.gross : ""} · {r.status}
                          </span>
                          {sel ? <span style={{ fontSize: 11, fontWeight: 800, color: C.gold }}>keep</span> : null}
                        </div>
                      );
                    })}
                    {it.kind === "multi_draft" ? (
                      <div onClick={() => setKeep(null)} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 6px", cursor: "pointer", borderTop: `1px solid ${C.borderGreen}` }}>
                        <span style={{ width: 14, height: 14, borderRadius: "50%", flex: "0 0 14px", border: `2px solid ${keep === null ? C.gold : C.sage}`, background: keep === null ? C.gold : "transparent" }} />
                        <span style={{ fontSize: 11.5, color: keep === null ? C.cream : C.sage }}>Keep none — remove all these drafts</span>
                      </div>
                    ) : null}
                  </div>
                </>
              ) : null}
              <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} placeholder="Optional note (e.g. 'v1.135 in-progress inflation bug')"
                style={{ ...inputStyle, fontSize: 13, padding: "8px 12px", marginBottom: 8, fontFamily: "inherit" }} />
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {isCluster ? (
                  <>
                    <button disabled={busy} onClick={() => resolve("cleared", true)} style={btnPrimary}>Confirm bug — remove{it.kind === "multi_draft" && keep === null ? " all" : " the rest"}</button>
                    <button disabled={busy} onClick={() => resolve("cleared", false)} style={btnGhost}>Not a problem — keep all</button>
                  </>
                ) : (
                  <button disabled={busy} onClick={() => resolve("cleared", false)} style={btnPrimary}>Acknowledge / fixed</button>
                )}
                <button disabled={busy} onClick={() => resolve("needs_action", false)} style={btnGhost}>Needs action</button>
              </div>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
const btnPrimary: React.CSSProperties = { background: "#5BBE7E", color: "#06251a", border: "none", borderRadius: 8, padding: "8px 12px", fontSize: 12, fontWeight: 800, cursor: "pointer" };
const btnGhost: React.CSSProperties = { background: "transparent", color: C.cream, border: "1px solid #6f8a7e", borderRadius: 8, padding: "8px 12px", fontSize: 12, fontWeight: 700, cursor: "pointer" };

function AdminFrictionReview() {
  const [tab, setTab] = useState<"open" | "needs_action" | "resolved">("open");
  const [items, setItems] = useState<any[] | null>(null);
  const [gone, setGone] = useState(false);
  const [sweeping, setSweeping] = useState(false);
  const load = useCallback(() => {
    rpcAll(supabase, "get_friction_items", { p_status: null }, "id").then(({ data, error }: any) => {
      if (error) { setGone(true); return; }
      setItems(data || []);
    });
  }, []);
  useEffect(() => { load(); }, [load]);
  if (gone) return null; // hidden until 0092 is deployed

  const list = items || [];
  const groups = {
    open: list.filter((i) => i.status === "open"),
    needs_action: list.filter((i) => i.status === "needs_action"),
    resolved: list.filter((i) => i.status === "cleared" || i.status === "auto_resolved"),
  };
  const runNow = async () => { setSweeping(true); try { await supabase.rpc("sweep_friction", { p_force: true }); } catch { /* ignore */ } setSweeping(false); load(); };
  const cur = groups[tab];

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", margin: "18px 0 4px" }}>
        <span style={{ fontFamily: "Georgia, serif", fontSize: 16, fontWeight: 700, color: C.cream }}>Friction review</span>
        <button onClick={runNow} disabled={sweeping} style={{ marginLeft: "auto", background: C.greenLight, color: C.sage, border: `1px solid ${C.borderGreen}`, borderRadius: 8, padding: "9px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
          {sweeping ? "Checking\u2026" : "Run check now"}
        </button>
      </div>
      <div style={{ color: C.sage, fontSize: 11.5, marginBottom: 10, lineHeight: 1.5 }}>
        States the app shouldn’t be able to produce. Swept daily; a flag is a to-do, not a mark against a player. Cleared items stay cleared; fixed ones auto-resolve.
      </div>
      <div style={{ marginBottom: 10 }}>
        <Segmented ariaLabel="Friction status" onCard equal value={tab} onChange={setTab}
          options={([["open", "Open"], ["needs_action", "Needs action"], ["resolved", "Resolved"]] as ["open" | "needs_action" | "resolved", string][]).map(([key, label]) => ({ key, label: <>{label} <b>{groups[key].length}</b></> }))} />
      </div>
      {items === null ? (
        <div style={{ color: C.faint, fontSize: 12, padding: "16px 4px" }}>Loading…</div>
      ) : cur.length === 0 ? (
        <div style={{ color: C.faint, fontSize: 13, textAlign: "center", padding: "22px 10px" }}>
          {tab === "open" ? "Nothing to review \u2014 the data looks clean." : tab === "needs_action" ? "No items flagged for follow-up." : "No resolved items yet."}
        </div>
      ) : (
        cur.map((it) => <FrictionItem key={it.id} it={it} onDone={load} />)
      )}
    </div>
  );
}

// Sandbaggers: entered (GHIN) index vs the app's scoring-derived index, flagged at >=20% apart
// once a player has >=18 posted rounds (below that the record is too thin to judge).
function AdminSandbaggers() {
  const [rows, setRows] = useState<any[] | null>(null);
  const [err, setErr] = useState(false);
  useEffect(() => {
    rpcAll(supabase, "admin_sandbaggers", undefined, "user_id").then(({ data, error }: any) => { if (error) setErr(true); else setRows(data || []); });
  }, []);
  if (err) return <div style={{ color: C.sage, fontSize: 13 }}>Couldn’t load — the admin_sandbaggers migration (0101) may not be applied yet.</div>;
  if (!rows) return <div style={{ color: C.sage, fontSize: 13 }}>Loading…</div>;
  return (
    <div>
      <div style={{ color: C.sage, fontSize: 12.5, lineHeight: 1.55, marginBottom: 12 }}>
        Players whose entered index differs from what their scoring in the app implies by 20% or more, once they have at least 18 posted rounds. An entered index higher than their scoring warrants (“index looks high”) is the classic sandbag — more strokes than their game deserves. The entered (GHIN) index always wins for display; this is only a flag to review. Under 18 rounds, nobody is judged.
      </div>
      {rows.length === 0 ? (
        <div style={{ background: C.greenLight, borderRadius: 12, padding: 16, color: C.sage, fontSize: 13 }}>No one flagged — every player with 18+ rounds has an entered index within 20% of their scoring.</div>
      ) : rows.map((r) => (
        <div key={r.user_id} style={{ background: C.greenLight, borderRadius: 12, padding: "12px 14px", marginTop: 8, display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: C.cream, fontWeight: 800, fontSize: 14 }}>{r.name}</div>
            <div style={{ color: C.sage, fontSize: 12, marginTop: 2 }}>Entered {Number(r.entered).toFixed(1)} · scoring says {Number(r.calc).toFixed(1)} · {r.rounds} rounds</div>
          </div>
          <div style={{ textAlign: "right", flexShrink: 0 }}>
            <div style={{ color: r.direction === "entered_high" ? C.overRedDark : C.gold, fontWeight: 800, fontSize: 15 }}>{r.diff_pct}%</div>
            <div style={{ color: C.sage, fontSize: 11 }}>{r.direction === "entered_high" ? "index looks high" : "index looks low"}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

export function AdminHome({ user, profile, activeGroupName, activeGroupRole, onGoto, onOpenGame, onEnterGroup, onExitGroup, onGroupsChanged }: {
  user: any; profile: any; activeGroupName?: string | null; activeGroupRole?: string | null;
  onGoto: (tab: string) => void;
  onOpenGame: (gameId: string) => void;
  onEnterGroup: (g: any) => Promise<void>; onExitGroup: (g: any) => Promise<void>; onGroupsChanged: () => void;
}) {
  const isMaster = !!profile?.is_admin;
  const isClubAdmin = activeGroupRole === "admin";
  const [view, setView] = useState<string | null>(null);
  // 210.8: club requests, counted for the Admin card (admin_club_requests — system admins see every request).
  const [clubReqCount, setClubReqCount] = useState(0);
  useEffect(() => { void supabase.rpc("admin_club_requests").then(({ data }: any) => setClubReqCount(Array.isArray(data) ? data.length : 0)); }, [supabase, view]);
  const [todos, setTodos] = useState<any>({});
  useEffect(() => {
    if (!isMaster) return;
    supabase.rpc("get_admin_todos").then(({ data }: any) => setTodos((t: any) => ({ ...t, ...(data || {}) })), () => {});
    rpcAll(supabase, "get_friction_items", { p_status: "open" }, "id").then(
      ({ data }: any) => setTodos((t: any) => ({ ...t, friction_open: (data || []).length })), () => {});
  }, [isMaster]);

  const Card = ({ icon, name, cap, onClick, badge }: { icon: string; name: string; cap: string; onClick: () => void; badge?: number }) => (
    <button onClick={onClick} style={{ textAlign: "left", background: C.greenLight, border: `1px solid #2c6b54`, borderRadius: 14, padding: "13px 13px 14px", cursor: "pointer", position: "relative" }}>
      {badge && badge > 0
        ? <span style={{ position: "absolute", top: 10, right: 10, minWidth: 20, height: 20, padding: "0 6px", borderRadius: 999, background: C.gold, color: "#0e3a2c", fontSize: 11.5, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center" }}>{badge}</span>
        : <span style={{ position: "absolute", top: 12, right: 12, color: C.sage, fontSize: 14 }}>›</span>}
      <div style={{ fontSize: 20, lineHeight: 1 }}>{icon}</div>
      <div style={{ color: C.cream, fontWeight: 800, fontSize: 13.5, marginTop: 8 }}>{name}</div>
      <div style={{ color: C.sage, fontSize: 11, marginTop: 3, lineHeight: 1.35 }}>{cap}</div>
    </button>
  );
  const grid = (children: React.ReactNode) => (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 10 }}>{children}</div>
  );
  const tierHead = (title: string, badge: string, badgeSuper: boolean, desc: string) => (
    <>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 20 }}>
        <span style={{ fontFamily: "Georgia, serif", fontSize: 15, fontWeight: 700, color: C.cream }}>{title}</span>
        <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: "0.04em", padding: "2px 8px", borderRadius: 999, color: badgeSuper ? "#0e3a2c" : C.sage, background: badgeSuper ? C.gold : "#173a2c", border: badgeSuper ? "none" : "1px solid #37624f" }}>{badge}</span>
      </div>
      <div style={{ color: C.faint, fontSize: 11, marginTop: 4 }}>{desc}</div>
    </>
  );

  if (view) {
    let title = ""; let panel: React.ReactNode = null;
    switch (view) {
      case "analytics": title = "Analytics"; panel = <><AdminAnalytics /><AdminExtraStats /><AdminDailyReport /><AdminEngagement /><AdminPowerUsers /></>; break;
      case "friction": title = "Friction review"; panel = <AdminFrictionReview />; break;
      case "operations": title = "Operations"; panel = <OpsMetrics />; break;
      case "games": title = "Games oversight"; panel = <AdminGamesOversight onOpenGame={onOpenGame} />; break;
      case "diagnostics": title = "Diagnostics"; panel = <><PhoneDiagnosticsPanel /><StorageMeter /><SaveTraceToggle /><RoundSaveDiag /></>; break;   // 212.27 / 212.28: storage meter + the score-save trace switch
      case "clubreports": title = "Club reports"; panel = <AdminClubReport />; break;
      case "clubrequests": title = "Club requests"; panel = <AdminClubRequests user={user} onCount={setClubReqCount} />; break;
      case "activity": title = "Activity log"; panel = <ActivityTab />; break;
      case "oversight": title = "Clubs oversight"; panel = <AdminGroupsTab user={user} onEnterGroup={onEnterGroup} onExitGroup={onExitGroup} onGroupsChanged={onGroupsChanged} />; break;
      case "users": title = "Users"; panel = <AdminUsersTab user={user} isOwner={!!profile?.is_owner} />; break;
      case "players": title = "Player admin"; panel = <AdminPanel user={user} showAnalytics={false} />; break;
      case "coursedata": title = "Course data"; panel = <AdminCourseData onOpenCourses={() => onGoto("courses")} />; break;
      case "feedback": title = "Feedback"; panel = <AdminFeedbackTab />; break;
      case "sandbaggers": title = "Sandbaggers & standout watch"; panel = <><AdminSandbaggers /><div style={{ marginTop: 22 }}><Eyebrow>STANDOUT WATCH</Eyebrow><div style={{ marginTop: 8 }}><AdminStandoutWatch /></div></div></>; break;
      case "systools": title = "System tools"; panel = <SystemTools user={user} />; break;
    }
    return (
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
          <button onClick={() => setView(null)} style={{ ...btn(false), fontSize: 12, padding: "5px 11px" }}>‹ Admin</button>
          <div style={{ fontFamily: "Georgia, serif", fontSize: 20, fontWeight: 700, color: C.cream }}>{title}</div>
        </div>
        {panel}
      </div>
    );
  }

  return (
    <div>
      <div style={{ fontFamily: "Georgia, serif", fontSize: 26, fontWeight: 700, color: C.cream }}>Admin</div>
      <div style={{ color: C.sage, fontSize: 12.5, marginTop: 2 }}>Everything that manages the club or the system, in one place.</div>

      {isClubAdmin && (
        <>
          {tierHead("Club admin", (activeGroupName || "This club").toUpperCase(), false, "Scoped to the club you're in. Any admin of this club sees this.")}
          {grid(<>
            <Card icon="👥" name="Members" cap="Handicaps, roles, add / remove players" onClick={() => onGoto("players")} />
            <Card icon="⚙︎" name="Club settings" cap="Name, default club, invite links" onClick={() => onGoto("groups")} />
          </>)}
        </>
      )}

      {isMaster && (
        <>
          {tierHead("System", "SYSTEM ADMIN", true, "Cross-club and system-wide. System admins only.")}
          {grid(<>
            <Card icon="📊" name="Analytics" cap="Usage, engagement & golf cadence" onClick={() => setView("analytics")} />
            <Card icon="🧭" name="Operations" cap="Nudge funnel, auto-finish, stale rounds & games" onClick={() => setView("operations")} badge={todos.stale_ready} />
            <Card icon="⛳" name="Games oversight" cap="Find, inspect and repair any Game" onClick={() => setView("games")} />
            <Card icon="⚠︎" name="Friction review" cap="Data-integrity flags to review & clear" onClick={() => setView("friction")} badge={todos.friction_open} />
            <Card icon="📜" name="Activity log" cap="Audit trail across all clubs" onClick={() => setView("activity")} />
            <Card icon="🏟" name="Clubs oversight" cap="Approve clubs, support sessions" onClick={() => setView("oversight")} badge={todos.pending_clubs} />
            <Card icon="🧑‍🤝‍🧑" name="Users" cap="Global roster, suspend, merge" onClick={() => setView("users")} />
            <Card icon="🏳️" name={`Club requests${clubReqCount ? ` (${clubReqCount})` : ""}`} cap={clubReqCount ? "New clubs waiting for your approval" : "New clubs waiting for approval — none right now"} onClick={() => setView("clubrequests")} />
            <Card icon="🗂" name="Player admin" cap="Handicaps, scores, memberships, courses" onClick={() => setView("players")} />
            <Card icon="💬" name="Feedback" cap="User-submitted feedback" onClick={() => setView("feedback")} badge={todos.new_feedback} />
            <Card icon="⛳" name="Course data" cap="API verification, pending updates, corrections awaiting approval" onClick={() => setView("coursedata")} />
            <Card icon="🚩" name="Sandbaggers" cap="Entered index vs scoring (18+ rounds)" onClick={() => setView("sandbaggers")} />
            <Card icon="📋" name="Club reports" cap="Preview a club's report for any period" onClick={() => setView("clubreports")} />
            <Card icon="🩺" name="Diagnostics" cap="Phone storage, score-save trace, round-save log" onClick={() => setView("diagnostics")} />
            <Card icon="🔧" name="System tools" cap="Test account, yardage backfill" onClick={() => setView("systools")} />
          </>)}
        </>
      )}

      {!isClubAdmin && !isMaster && (
        <div style={{ color: C.sage, fontSize: 13, marginTop: 20 }}>You don't have admin access to anything here.</div>
      )}
    </div>
  );
}

export function ActivityTab() {
  const [rows, setRows] = useState<any[] | null>(null);
  const [filter, setFilter] = useState<string>("all");

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("activity_log").select("*").not("action", "like", "analytics_%").order("created_at", { ascending: false }).limit(300);
      setRows(data || []);
    })();
  }, []);

  const cats: Record<string, string[]> = {
    all: [],
    rounds: ["round_completed", "round_deleted"],
    players: ["handicap_changed", "member_added", "member_removed", "role_changed", "score_edited"],
    courses: ["course_created", "course_vetted", "course_unvetted", "course_removed"],
    games: ["game_created", "game_deleted"],
  };
  const shown = (rows || []).filter((r) => filter === "all" || cats[filter]?.includes(r.action));

  return (
    <div>
      <Eyebrow>★ ACTIVITY · AUDIT TRAIL</Eyebrow>
      <div style={{ color: C.sage, fontSize: 12, marginTop: 8 }}>
        Major changes across the app — who did what, and when. Newest first. Logging began when this feature was deployed, so earlier history isn't shown.
      </div>
      <div style={{ display: "flex", gap: 6, marginTop: 12, flexWrap: "wrap" }}>
        {["all", "rounds", "players", "courses", "games"].map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            style={{ ...btn(filter === f), fontSize: 12, padding: "6px 12px", textTransform: "capitalize" }}>{f}</button>
        ))}
      </div>
      {rows === null && <div style={{ color: C.sage, marginTop: 14 }}>Loading…</div>}
      {rows !== null && shown.length === 0 && (
        <div style={{ background: C.greenLight, borderRadius: 12, padding: 20, marginTop: 14, color: C.sage, textAlign: "center" }}>
          No activity recorded yet{filter !== "all" ? " in this category" : ""}.
        </div>
      )}
      {shown.map((r) => (
        <div key={r.id} style={{ background: C.greenLight, borderRadius: 12, padding: "11px 14px", marginTop: 8 }}>
          <div style={{ color: C.cream, fontSize: 14 }}>{r.summary}</div>
          <div style={{ color: C.sage, fontSize: 11, marginTop: 3 }}>
            {r.actor_name || "Someone"} · {fmtDate(r.created_at)} at {new Date(r.created_at).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })} · {timeAgo(r.created_at)}
          </div>
        </div>
      ))}
    </div>
  );
}

// ================= Master-admin oversight: all groups =================
export function AdminGroupsTab({ user, onEnterGroup, onExitGroup, onGroupsChanged }: {
  user: any;
  onEnterGroup?: (g: { group_id: string; name: string }) => Promise<void>;
  onExitGroup?: (g: { group_id: string; name: string }) => Promise<void>;
  onGroupsChanged?: () => Promise<void> | void;
}) {
  const [rows, setRows] = useState<any[] | null>(null);
  const [filter, setFilter] = useState<"active" | "archived" | "all">("active");
  const [busy, setBusy] = useState<string | null>(null);
  const [mergeSrc, setMergeSrc] = useState<string | null>(null);
  const [mergeTo, setMergeTo] = useState("");

  const load = async () => {
    // Opportunistically clear any forgotten support sessions before showing the overview.
    await supabase.rpc("expire_support_sessions", { p_max_hours: 12 }).then(() => {}, () => {});
    const { data } = await rpcAll(supabase, "admin_group_overview", undefined, "group_id");
    const base = Array.isArray(data) ? data : [];
    let flags: any[] = [];
    try { flags = await fetchAll<any>((f, t) => supabase.from("groups").select("id, is_test").order("id").range(f, t)); } catch { flags = []; }
    const tmap = new Map((flags || []).map((f: any) => [f.id, !!f.is_test]));
    setRows(base.map((r: any) => ({ ...r, is_test: tmap.get(r.group_id) ?? false })));
  };
  useEffect(() => { load(); }, []);

  const shown = (rows || []).filter((r) =>
    filter === "all" || (filter === "archived" ? r.status === "archived" : r.status !== "archived"));

  const setStatus = async (g: any, next: "active" | "archived") => {
    const verb = next === "archived" ? "Archive" : "Restore";
    if (!(await askConfirm(`${verb} the club "${g.name}"?${next === "archived" ? " It disappears from members' club pickers — nothing is deleted, and you can restore it." : ""}`))) return;
    setBusy(g.group_id);
    try {
      const { error } = await supabase.rpc("admin_set_group_status", { p_group: g.group_id, p_status: next });
      if (error) { notifyError(failureMessage("Couldn't update", error)); return; }
      await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Master admin", action: next === "archived" ? "group_archived" : "group_restored", group_id: g.group_id, summary: `${next === "archived" ? "Archived" : "Restored"} group "${g.name}"` });
      await load();
    } finally { setBusy(null); }
  };

  const delGroup = async (g: any) => {
    const hasData = (g.rounds_count || 0) > 0 || (g.games_count || 0) > 0;
    const msg = hasData
      ? `Delete "${g.name}"? This removes the club for everyone. Its ${g.games_count} game(s) will be deleted; ${g.rounds_count} posted round(s) stay in players' history but lose the club tag. This can't be undone.`
      : `Delete "${g.name}"? It has no rounds or games. This removes it for everyone and can't be undone.`;
    if (!(await askConfirm(msg))) return;
    setBusy(g.group_id);
    try {
      const { error } = await supabase.rpc("admin_delete_group", { p_group: g.group_id });
      if (error) { notifyError(failureMessage("Couldn't delete that", error)); return; }
      await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Master admin", action: "group_deleted", group_id: null, summary: `Deleted group "${g.name}" (admin)` });
      await load();
      if (onGroupsChanged) await onGroupsChanged();
    } finally { setBusy(null); }
  };

  const setDefault = async (g: any) => {
    if (!(await askConfirm(`Make "${g.name}" the app's default club? New or stranded users (and their untagged rounds) will land here. This replaces any current default.`))) return;
    setBusy(g.group_id);
    try {
      const { error } = await supabase.rpc("admin_set_default_group", { p_group: g.group_id });
      if (error) { notifyError(failureMessage("Couldn't set default", error)); return; }
      await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Master admin", action: "group_set_default", group_id: g.group_id, summary: `Set "${g.name}" as the default group` });
      await load();
    } finally { setBusy(null); }
  };

  const wipeGroup = async (g: any) => {
    const typed = (await askText(`Wipe ALL data in test club "${g.name}"? This deletes its games, rounds and money ledger but KEEPS the club and its members. Type the club name to confirm:`));
    if (typed == null) return;
    if (typed.trim() !== g.name) { notifyError("Name didn't match — nothing was wiped."); return; }
    setBusy(g.group_id);
    try {
      const { data, error } = await supabase.rpc("admin_wipe_group", { p_group: g.group_id });
      if (error) { notifyError(failureMessage("Couldn't wipe", error)); return; }
      if (data === "wiped") {
        await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Master admin", action: "group_wiped", group_id: g.group_id, summary: `Wiped test club "${g.name}" data` });
        notifyError(`Wiped all data in "${g.name}".`);
        await load();
        if (onGroupsChanged) await onGroupsChanged();
      } else if (data === "not_test") notifyError("Refused — this isn't a test club.");
      else notifyError("Couldn't wipe (permission or not found).");
    } finally { setBusy(null); }
  };

  const revokeInvites = async (g: any) => {
    if (!(await askConfirm(`Revoke all outstanding invite links for "${g.name}"? Existing members stay; only unused links stop working.`))) return;
    setBusy(g.group_id);
    try {
      const { error } = await supabase.rpc("admin_revoke_group_invites", { p_group: g.group_id });
      if (error) { notifyError(failureMessage("Couldn't revoke", error)); return; }
      await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Master admin", action: "group_invites_revoked", group_id: g.group_id, summary: `Revoked invite links for "${g.name}"` });
    } finally { setBusy(null); }
  };

  const doMerge = async (src: any) => {
    const target = (rows || []).find((r) => r.group_id === mergeTo);
    if (!target) return;
    if (!(await askConfirm(`Merge "${src.name}" INTO "${target.name}"? All of "${src.name}"'s members, rounds and games move into "${target.name}", then "${src.name}" is deleted. This can't be undone.`))) return;
    setBusy(src.group_id);
    try {
      const { error } = await supabase.rpc("admin_merge_group", { p_source: src.group_id, p_target: mergeTo });
      if (error) { notifyError(failureMessage("Couldn't merge those", error)); return; }
      await logActivity(supabase, { actor_id: user.id, actor_name: user.email || "Master admin", action: "group_merged", group_id: mergeTo, summary: `Merged "${src.name}" into "${target.name}"` });
      setMergeSrc(null); setMergeTo("");
      await load();
      if (onGroupsChanged) await onGroupsChanged();
    } finally { setBusy(null); }
  };

  return (
    <div>
      <Eyebrow>★ OVERSIGHT · ALL CLUBS</Eyebrow>
      <div style={{ color: C.sage, fontSize: 12, marginTop: 8 }}>
        Every group in Birdie Num Num, most recent activity first. Archiving hides a stale or abusive group from members&apos; pickers — it&apos;s reversible and deletes nothing. Counts are read-only; deeper tools arrive in later phases.
      </div>
      <div style={{ display: "flex", gap: 6, marginTop: 12, flexWrap: "wrap" }}>
        {(["active", "archived", "all"] as const).map((f) => (
          <button key={f} onClick={() => setFilter(f)}
            style={{ ...btn(filter === f), fontSize: 12, padding: "6px 12px", textTransform: "capitalize" }}>{f}</button>
        ))}
      </div>
      {rows === null && <div style={{ color: C.sage, marginTop: 14 }}>Loading…</div>}
      {rows !== null && shown.length === 0 && (
        <div style={{ background: C.greenLight, borderRadius: 12, padding: 20, marginTop: 14, color: C.sage, textAlign: "center" }}>
          No {filter !== "all" ? filter : ""} groups.
        </div>
      )}
      {shown.map((g) => {
        const archived = g.status === "archived";
        return (
          <div key={g.group_id} style={{ background: C.greenLight, borderRadius: 12, padding: "12px 14px", marginTop: 8, opacity: archived ? 0.62 : 1 }}>
            <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
              <div style={{ color: C.cream, fontWeight: 800, fontSize: 15 }}>{g.name}</div>
              {g.is_default && <span style={{ color: C.gold, fontSize: 11, fontWeight: 800, textTransform: "uppercase" }}>★ default</span>}
              {archived && <span style={{ color: C.sage, fontSize: 11, fontWeight: 700, textTransform: "uppercase" }}>· archived</span>}
              <div style={{ flex: 1 }} />
              {g.my_support ? (
                <button disabled={busy === g.group_id}
                  onClick={async () => { setBusy(g.group_id); try { await onExitGroup?.({ group_id: g.group_id, name: g.name }); await load(); } finally { setBusy(null); } }}
                  style={{ ...btn(true), fontSize: 12, padding: "5px 11px" }}>In session · Exit</button>
              ) : (
                <button disabled={busy === g.group_id}
                  onClick={async () => { setBusy(g.group_id); try { await onEnterGroup?.({ group_id: g.group_id, name: g.name }); } finally { setBusy(null); } }}
                  style={{ ...btn(false), fontSize: 12, padding: "5px 11px", opacity: busy === g.group_id ? 0.62 : 1 }}>Enter</button>
              )}
              <button disabled={busy === g.group_id} onClick={() => setStatus(g, archived ? "active" : "archived")}
                style={{ ...btn(false), fontSize: 12, padding: "5px 11px", opacity: busy === g.group_id ? 0.62 : 1 }}>
                {archived ? "Restore" : "Archive"}
              </button>
            </div>
            <div style={{ color: C.sage, fontSize: 12, marginTop: 4 }}>Admin: {g.admin_names || "—"}</div>
            <div style={{ color: C.sage, fontSize: 12, marginTop: 2 }}>
              {g.member_count} member{g.member_count === 1 ? "" : "s"} · {g.rounds_count} round{g.rounds_count === 1 ? "" : "s"} · {g.games_count} game{g.games_count === 1 ? "" : "s"} · last activity {g.last_activity ? fmtDate(g.last_activity) : "—"}
            </div>
            <div style={{ marginTop: 8, display: "flex", justifyContent: "flex-end", gap: 8, flexWrap: "wrap" }}>
              <button disabled={busy === g.group_id} onClick={() => revokeInvites(g)}
                style={{ background: "transparent", color: C.sage, border: `1px solid ${C.borderCard}`, borderRadius: 8, fontSize: 11, fontWeight: 700, padding: "9px 10px", cursor: "pointer", opacity: busy === g.group_id ? 0.62 : 1 }}>
                Revoke invites
              </button>
              <button disabled={busy === g.group_id} onClick={() => { setMergeSrc(mergeSrc === g.group_id ? null : g.group_id); setMergeTo(""); }}
                style={{ background: "transparent", color: C.sage, border: `1px solid ${C.borderCard}`, borderRadius: 8, fontSize: 11, fontWeight: 700, padding: "9px 10px", cursor: "pointer", opacity: busy === g.group_id ? 0.62 : 1 }}>
                Merge…
              </button>
              {!g.is_default && (
                <button disabled={busy === g.group_id} onClick={() => setDefault(g)}
                  style={{ background: "transparent", color: C.sage, border: `1px solid ${C.borderCard}`, borderRadius: 8, fontSize: 11, fontWeight: 700, padding: "9px 10px", cursor: "pointer", opacity: busy === g.group_id ? 0.62 : 1 }}>
                  Set as default
                </button>
              )}
              <button disabled={busy === g.group_id} onClick={() => delGroup(g)}
                style={{ background: "transparent", color: C.overRedDark, border: `1px solid ${C.birdie}`, borderRadius: 8, fontSize: 11, fontWeight: 700, padding: "9px 10px", cursor: "pointer", opacity: busy === g.group_id ? 0.62 : 1 }}>
                Delete group
              </button>
              {g.is_test && (
                <button disabled={busy === g.group_id} onClick={() => wipeGroup(g)}
                  style={{ background: "transparent", color: C.gold, border: `1px solid ${C.gold}`, borderRadius: 8, fontSize: 11, fontWeight: 700, padding: "9px 10px", cursor: "pointer", opacity: busy === g.group_id ? 0.62 : 1 }}>
                  Wipe data
                </button>
              )}
            </div>
            {mergeSrc === g.group_id && (
              <div style={{ marginTop: 8, display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", background: C.greenLight, borderRadius: 8, padding: 8 }}>
                <span style={{ color: C.sage, fontSize: 12 }}>Merge into:</span>
                <select value={mergeTo} onChange={(e) => setMergeTo(e.target.value)}
                  style={{ ...inputStyle, width: "auto", fontSize: 12, padding: "4px 10px" }}>
                  <option value="">Select target…</option>
                  {(rows || []).filter((r) => r.group_id !== g.group_id).map((r) => (
                    <option key={r.group_id} value={r.group_id}>{r.name}</option>
                  ))}
                </select>
                <button disabled={!mergeTo || busy === g.group_id} onClick={() => doMerge(g)}
                  style={{ background: C.gold, color: C.green, border: "none", borderRadius: 8, fontSize: 12, fontWeight: 800, padding: "5px 12px", cursor: "pointer", opacity: mergeTo ? 1 : 0.62 }}>Merge & delete source</button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ================= Master-admin oversight: all users =================
export function AdminUsersTab({ user, isOwner }: { user: any; isOwner?: boolean }) {
  // 208.0: rebuilt as components/admin-players (sign-up queue, statuses, merge / suspend / restore / remove).
  return (
    <div>
      <Eyebrow>★ OVERSIGHT · ALL PLAYERS</Eyebrow>
      <div style={{ color: C.sage, fontSize: 12, marginTop: 8, marginBottom: 12, lineHeight: 1.5 }}>
        Every account. A duplicate is <b>merged</b> into the member&apos;s real account; a stranger is <b>rejected</b>; a member who leaves is <b>suspended</b> (history kept);
        only an account with no activity can be <b>removed</b>.{isOwner ? " As the owner, you can also grant or remove system-admin access." : ""}
      </div>
      <AdminPlayers user={user} isOwner={isOwner} />
    </div>
  );
}

export function HelpPage({ isAdmin, user, displayName, groupId }: { isAdmin: boolean; user: any; displayName: string; groupId: string | null }) {
  const [fbPrefill, setFbPrefill] = useState<FeedbackPrefill>(null);
  const fbRef = React.useRef<HTMLDivElement>(null);
  const sendAsQuestion = (q: string) => {
    setFbPrefill({ kind: "question", message: q });
    setTimeout(() => fbRef.current?.scrollIntoView({ behavior: "smooth", block: "center" }), 60);
  };
  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div style={{ background: C.greenLight, borderRadius: 14, padding: 16, marginTop: 12 }}>
      <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 18, fontWeight: 700 }}>{title}</div>
      <div style={{ color: C.sage, fontSize: 13, marginTop: 8, lineHeight: 1.55 }}>{children}</div>
    </div>
  );
  return (
    <div>
      <Eyebrow>HELP · HOW BIRDIE NUM NUM WORKS</Eyebrow>
      <div style={{ color: C.sage, fontSize: 12, marginTop: 8 }}>A quick guide to the basics. Use the bottom tabs and More menu to move around.</div>

      {(() => {
        const isTGC = effectiveGroupId(groupId) === TGC_GROUP_ID;
        const edition = isTGC ? "tgc" : "club";
        const cards = (capabilities.cards as { title: string; body: string; editions: string[] }[])
          .filter((c) => c.editions.includes("all") || c.editions.includes(edition));
        const pdf = isTGC ? "/BNN-onepager-tgc.pdf" : "/BNN-onepager-club.pdf";
        const exclusives = capabilities.tgcExclusives as { title: string; body: string }[];
        return (
          <div style={{ background: C.greenLight, borderRadius: 14, padding: 16, marginTop: 12 }}>
            <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexWrap: "wrap" }}>
              <div style={{ color: C.cream, fontFamily: "Georgia, serif", fontSize: 18, fontWeight: 700, flex: "1 1 240px" }}>What Birdie Num Num can do</div>
              <a href={pdf} target="_blank" rel="noopener noreferrer" style={{ background: C.gold, color: C.green, fontWeight: 800, fontSize: 12, borderRadius: 8, padding: "7px 12px", textDecoration: "none", whiteSpace: "nowrap" }}>Download one-pager (PDF)</a>
            </div>
            <div style={{ color: C.sage, fontSize: 12, marginTop: 4, lineHeight: 1.5 }}>{capabilities.tagline}</div>
            <div style={{ marginTop: 10, display: "grid", gap: 9 }}>
              {cards.map((c, i) => (
                <div key={i}>
                  <div style={{ color: C.cream, fontSize: 13, fontWeight: 700 }}>{c.title}</div>
                  <div style={{ color: C.sage, fontSize: 12, lineHeight: 1.5 }}>{c.body}</div>
                </div>
              ))}
              {isTGC && (
                <div style={{ marginTop: 2, borderTop: `1px solid ${C.borderGreen}`, paddingTop: 9 }}>
                  <div style={{ color: C.gold, fontSize: 11, fontWeight: 800, letterSpacing: 1 }}>★ EXCLUSIVE TO YOUR CLUB</div>
                  {exclusives.map((x, i) => (
                    <div key={i} style={{ marginTop: 7 }}>
                      <div style={{ color: C.cream, fontSize: 13, fontWeight: 700 }}>{x.title}</div>
                      <div style={{ color: C.sage, fontSize: 12, lineHeight: 1.5 }}>{x.body}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        );
      })()}

      <HelpSearch onSendQuestion={sendAsQuestion} />

      <div ref={fbRef}>
        <FeedbackForm user={user} displayName={displayName} groupId={groupId} prefill={fbPrefill} onConsumePrefill={() => setFbPrefill(null)} />
      </div>

      <Section title="Recording a round">
        Tap <b>＋ New round</b>, pick a course and tee, set the date, then enter your score. You can go <b>hole-by-hole</b> (full stats: GIR, putts, penalties, Stableford) or enter a <b>quick total score</b> for a past round. Quick totals still count toward your handicap and scoring average — you can add hole detail later from the round.
      </Section>

      <Section title="Your handicap">
        As you log rounds, the app calculates a running handicap using the standard "best 8 of your last 20" differentials. You can also type in a handicap index on your Profile if you already have one. Your <b>My Dashboard</b> shows your trend, scoring averages, and stats.
      </Section>

      <Section title="Games with friends">
        In <b>Games</b>, an organizer chooses a format - including Scramble, Alternate Shot, Stableford, stroke play or match play - and shares a 6-digit code. Players enter the code to join, or the organizer adds them. Tap the code to copy it for a text. The organizer can set everyone's handicap and manage the roster.
      </Section>

      <Section title="Courses">
        Browse <b>All App Courses</b> to see every saved course in Birdie Num Num, then add courses to your club library. Editing a course saves the correction for your club immediately and submits it to an app admin for global approval before other clubs see it.
      </Section>

      <Section title="Clubs">
        A club keeps games, players, and courses together for the people you play with. Club admins invite members with a one-time link, set roles, and manage players from the <b>Players</b> tab. Your dashboard and rounds always cover all of your clubs together.
      </Section>

      {isAdmin && (
        <Section title="Admin tools (you only)">
          As an app admin you can mark courses as vetted community courses (the ★), adjust any player's handicap, edit scores, and review the <b>Activity</b> tab — an audit trail of major changes across the app.
        </Section>
      )}

      <UpdateChecker />
    </div>
  );
}



import { diagnosticError, recordPhoneDiagnostic } from "./phone-diagnostics";
import { scoringStorage, tidyScoringStorage, noteStorageWriteFailure, registerStorageTidy } from "./scoring-device";
// In-progress round draft, stored in the browser's localStorage.
// localStorage writes are SYNCHRONOUS — they complete before the phone can lock
// or the tab can be evicted, so an in-progress round survives a lock or refresh
// even if the user locks the screen the instant after tapping a score.
//
// This is the durability mechanism for live score entry. The round is written to
// the database only when the user taps "Finish round" (the official record).

import type { Round } from "@/lib/golf";

const KEY = "bnn_round_draft_v1";

export function sameDraftRound(a: Round, b: Round): boolean {
  const aId = a.id || a.draft_session_id;
  const bId = b.id || b.draft_session_id;
  return !!aId && aId === bId;
}

export function saveDraft(round: Round, force = false): void {
  try {
    if (typeof window === "undefined") return;
    // Safety: never overwrite an existing draft that HAS scores with one that has
    // NONE (e.g. a transient empty state after a remount). Losing entered scores is
    // far worse than keeping a slightly stale draft.
    const incomingScored = (round.holes || []).some((h) => h.strokes != null);
    if (!force && !incomingScored) {
      const existing = loadDraft();
      const existingScored = (existing?.round?.holes || []).some((h: any) => h.strokes != null);
      if (existingScored && existing && sameDraftRound(existing.round, round)) return;
    }
    scoringStorage().setItem(KEY, JSON.stringify({ savedAt: Date.now(), round }));
    recordPhoneDiagnostic("storage.saved", { phase: "round", entityId: round.id || round.draft_session_id, holeCount: round.holes?.length || 0 });
  } catch (error) {
    recordPhoneDiagnostic("storage.failed", diagnosticError(error));
    // Storage can be unavailable (private mode, quota). Fail silently — DB save on
    // Finish is still the backstop.
  }
}

export function loadDraft(): { savedAt: number; round: Round } | null {
  try {
    if (typeof window === "undefined") return null;
    const raw = scoringStorage().getItem(KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed?.round) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function clearDraft(roundId?: string): void {
  try {
    if (typeof window === "undefined") return;
    if (roundId) {
      const existing = loadDraft();
      if (existing && (existing.round.id || existing.round.draft_session_id) !== roundId) return;
    }
    scoringStorage().removeItem(KEY);
    scoringStorage().removeItem(DHKEY);
  } catch {}
}

// Remembers the hole the user was last on in the individual round editor, keyed by
// round id so a lock/refresh returns them to it (same option-3 restore as the group card).
const DHKEY = "bnn_draft_hole_v1";
export function saveDraftHole(roundKey: string, holeIdx: number): void {
  try { if (typeof window === "undefined") return; scoringStorage().setItem(DHKEY, JSON.stringify({ roundKey, holeIdx })); } catch {}
}
export function loadDraftHole(roundKey: string): number | null {
  try {
    if (typeof window === "undefined") return null;
    const p = JSON.parse(scoringStorage().getItem(DHKEY) || "null");
    return p?.roundKey === roundKey && typeof p.holeIdx === "number" ? p.holeIdx : null;
  } catch { return null; }
}

// --- Generic in-progress EDIT draft (forms: course rating/slope/yardage, round setup, …) ---
// Persist a form's serializable state under a key so a phone lock / background / refresh
// doesn't lose unsaved edits. Restore on mount, clear on save or explicit discard. The
// synchronous localStorage write is what survives an involuntary background (no warning is
// possible then — beforeunload doesn't fire on mobile lock).
export function saveEditorDraft(key: string, data: unknown): void {
  try { if (typeof window === "undefined") return; scoringStorage().setItem("bnn_edit_" + key, JSON.stringify({ at: Date.now(), data })); } catch {}
}
export function loadEditorDraft<T = any>(key: string, maxAgeMs = 12 * 60 * 60 * 1000): T | null {
  try {
    if (typeof window === "undefined") return null;
    const raw = scoringStorage().getItem("bnn_edit_" + key);
    if (!raw) return null;
    const p = JSON.parse(raw);
    if (!p || !("data" in p)) return null;
    if (typeof p.at === "number" && Date.now() - p.at > maxAgeMs) return null; // stale — ignore
    return p.data as T;
  } catch { return null; }
}
export function clearEditorDraft(key: string): void {
  try { if (typeof window === "undefined") return; scoringStorage().removeItem("bnn_edit_" + key); } catch {}
}

// --- Active course edit (Manage → Courses) resume marker ---
// Remembers that the user was editing a course in the library (and which one) so a lock/
// refresh reopens the app INTO that editor instead of the dashboard. The edited data itself
// is persisted separately by the editor's form-draft; this just restores the navigation.
const CEKEY = "bnn_active_course_edit_v1";
export function saveActiveCourseEdit(v: unknown): void {
  try { if (typeof window === "undefined") return; scoringStorage().setItem(CEKEY, JSON.stringify({ at: Date.now(), v })); } catch {}
}
export function loadActiveCourseEdit<T = any>(maxAgeMs = 12 * 60 * 60 * 1000): T | null {
  try {
    if (typeof window === "undefined") return null;
    const raw = scoringStorage().getItem(CEKEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    if (typeof p?.at === "number" && Date.now() - p.at > maxAgeMs) return null;
    return p && "v" in p ? (p.v as T) : null;
  } catch { return null; }
}
export function clearActiveCourseEdit(): void {
  try { if (typeof window === "undefined") return; scoringStorage().removeItem(CEKEY); } catch {}
}

// True if the draft has at least one hole with a score entered.
export function draftHasScores(round: Round | null | undefined): boolean {
  if (!round?.holes?.length) return false;
  return round.holes.some((h) => h.strokes != null && (h.strokes as number) > 0);
}

// --- Active game resume (game room) ---
// Remembers which game room the user was in (and which sub-tab) so a lock or
// refresh returns them to the scorecard instead of the games list.
const GKEY = "bnn_active_game_v1";

export function saveActiveGame(gameId: string, tab: "play" | "setup"): void {
  try {
    if (typeof window === "undefined") return;
    // Preserve a previously-saved holeIdx for the SAME game so re-entering the room
    // (which calls this) doesn't wipe where the user was scoring.
    let holeIdx: number | undefined;
    try { const p = JSON.parse(scoringStorage().getItem(GKEY) || "null"); if (p?.gameId === gameId && typeof p.holeIdx === "number") holeIdx = p.holeIdx; } catch {}
    scoringStorage().setItem(GKEY, JSON.stringify({ gameId, tab, holeIdx, at: Date.now() }));
  } catch {}
}

// Remember the hole the user was last scoring in this game, so a lock/refresh returns
// them to it (see GroupScorecard restore). Merges into the active-game record without
// clobbering the tab; a different/absent game defaults the tab to "play".
export function saveActiveHole(gameId: string, holeIdx: number): void {
  try {
    if (typeof window === "undefined") return;
    let tab: "play" | "setup" = "play";
    try { const p = JSON.parse(scoringStorage().getItem(GKEY) || "null"); if (p?.gameId === gameId && p.tab === "setup") tab = "setup"; } catch {}
    scoringStorage().setItem(GKEY, JSON.stringify({ gameId, tab, holeIdx, at: Date.now() }));
  } catch {}
}

export function loadActiveGame(): { gameId: string; tab: "play" | "setup"; holeIdx?: number } | null {
  try {
    if (typeof window === "undefined") return null;
    const raw = scoringStorage().getItem(GKEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    if (!p?.gameId) return null;
    return { gameId: p.gameId, tab: p.tab === "setup" ? "setup" : "play", holeIdx: typeof p.holeIdx === "number" ? p.holeIdx : undefined };
  } catch { return null; }
}

export function clearActiveGame(): void {
  try {
    if (typeof window === "undefined") return;
    scoringStorage().removeItem(GKEY);
  } catch {}
}

// --- In-progress GAME score backup (per game, per device) ---
// Game scores normally write straight to the database on each tap, but an
// immediate screen lock can freeze that network write before it lands. This
// synchronous localStorage backup captures the latest scores instantly so a
// hole entered right before a lock isn't lost; on reopen we reconcile it to the DB.
function gameScoreKey(gameId: string, playerId: string) {
  return `bnn_game_scores_${gameId}_${playerId}`;
}

/** 212.26: set when a score backup couldn't be written even after tidying (the save then goes from memory). */
export let backupWriteFailed = false;
export function saveGameScores(
  gameId: string,
  playerId: string,
  data: { scores: any[]; putts: any[]; fairways: any[]; penalties?: any[]; sand?: any[] },
  force = false,
  observedAt?: number,
  scoringVersion?: number,
): void {
  try {
    if (typeof window === "undefined") return;
    if (!force) {
      // Passive saves (load/reconcile mirrors) must never overwrite a scored
      // backup with an empty one — a transient empty state during init could
      // otherwise wipe offline scores. Deliberate user edits pass force=true so
      // an intentional deletion (even down to empty) DOES update the backup and
      // can't be resurrected by the merge on reload.
      const scored = (data.scores || []).some((s) => s != null);
      if (!scored) {
        const existing = loadGameScores(gameId, playerId);
        if (existing && (existing.scores || []).some((s) => s != null)) return;
      }
    }
    const value = JSON.stringify({ scoringVersion: scoringVersion ?? loadGameScores(gameId, playerId)?.scoringVersion, at: observedAt ?? (force ? Date.now() : loadGameScores(gameId, playerId)?.at ?? Date.now()), ...data });
    // 212.26: a full storage area made this throw, silently — the backup never existed, nothing was sent and the
    // entry vanished. Tidy the storage and retry once; if it still fails, report it (the writer then sends from memory).
    try { scoringStorage().setItem(gameScoreKey(gameId, playerId), value); }
    catch { tidyScoringStorage(); try { scoringStorage().setItem(gameScoreKey(gameId, playerId), value); } catch (e) { backupWriteFailed = true; noteStorageWriteFailure(); throw e; } }
    recordPhoneDiagnostic("storage.saved", { phase: "game", entityId: playerId, holeCount: data.scores?.length || 0 });
  } catch {}
}

export function loadGameScores(
  gameId: string,
  playerId: string,
): { scores: any[]; putts: any[]; fairways: any[]; penalties: any[]; sand: any[]; at: number; scoringVersion?: number } | null {
  try {
    if (typeof window === "undefined") return null;
    const raw = scoringStorage().getItem(gameScoreKey(gameId, playerId));
    if (!raw) return null;
    const p = JSON.parse(raw);
    return { scoringVersion: Number.isInteger(p.scoringVersion) ? p.scoringVersion : undefined, scores: p.scores || [], putts: p.putts || [], fairways: p.fairways || [], penalties: p.penalties || [], sand: p.sand || [], at: typeof p.at === "number" ? p.at : 0 };
  } catch { return null; }
}

export function clearGameScores(gameId: string, playerId: string): void {
  try {
    if (typeof window === "undefined") return;
    scoringStorage().removeItem(gameScoreKey(gameId, playerId));
  } catch {}
}

// Remove EVERY local score backup for a game on this device (all player rows).
// Used by the master reset so a pre-game test wipe leaves no backup behind that
// could resurface — including the rows a marker backed up for other players.
export function clearAllGameScores(gameId: string): void {
  try {
    if (typeof window === "undefined") return;
    const prefix = `bnn_game_scores_${gameId}_`;
    const keys: string[] = [];
    for (let i = 0; i < scoringStorage().length; i++) {
      const k = scoringStorage().key(i);
      if (k && k.startsWith(prefix)) keys.push(k);
    }
    keys.forEach((k) => scoringStorage().removeItem(k));
    // Drop watermarks for this game too, so a reset can't leave "already synced" markers.
    const wmPrefix = `bnn_game_wm_${gameId}_`;
    const wmKeys: string[] = [];
    for (let i = 0; i < scoringStorage().length; i++) {
      const k = scoringStorage().key(i);
      if (k && k.startsWith(wmPrefix)) wmKeys.push(k);
    }
    wmKeys.forEach((k) => scoringStorage().removeItem(k));
    clearGameSnapshot(gameId);
  } catch {}
}

// --- Per-user daily AI analysis cap (client-side) ---
// Limits how many AI analyses a user can run per day, as the first line of cost
// defense. Stored per device; the server also enforces a global daily cap.
const AI_KEY = "bnn_ai_uses";
const AI_DAILY_LIMIT = 2;

export function aiUsesLeft(): number {
  try {
    if (typeof window === "undefined") return AI_DAILY_LIMIT;
    const today = new Date().toISOString().slice(0, 10);
    const raw = scoringStorage().getItem(AI_KEY);
    const p = raw ? JSON.parse(raw) : null;
    if (!p || p.day !== today) return AI_DAILY_LIMIT;
    return Math.max(0, AI_DAILY_LIMIT - (p.count || 0));
  } catch { return AI_DAILY_LIMIT; }
}

export function recordAiUse(): void {
  try {
    if (typeof window === "undefined") return;
    const today = new Date().toISOString().slice(0, 10);
    const raw = scoringStorage().getItem(AI_KEY);
    const p = raw ? JSON.parse(raw) : null;
    const count = p && p.day === today ? (p.count || 0) + 1 : 1;
    scoringStorage().setItem(AI_KEY, JSON.stringify({ day: today, count }));
  } catch {}
}

export const AI_DAILY_LIMIT_VALUE = AI_DAILY_LIMIT;

// --- Active game snapshot (full boot payload for offline cold-launch) ---
// Captured while ONLINE so the round stays fully usable with no signal: the game
// row, all player rows, and the course tee yardages. Merged on save so the game
// room can write {game,players} and the tees effect can add {courseTees} later.
function gameSnapKey(gameId: string) { return `bnn_game_snap_${gameId}`; }
export function saveGameSnapshot(gameId: string, partial: { game?: any; players?: any[]; courseTees?: any[]; courseHoles?: any[]; altShotScores?: any[] }): void {
  try {
    if (typeof window === "undefined") return;
    const existing = loadGameSnapshot(gameId) || {};
    scoringStorage().setItem(gameSnapKey(gameId), JSON.stringify({ ...existing, ...partial, at: Date.now() }));
  } catch {}
}
export function loadGameSnapshot(gameId: string): { game?: any; players?: any[]; courseTees?: any[]; courseHoles?: any[]; altShotScores?: any[]; at?: number } | null {
  try {
    if (typeof window === "undefined") return null;
    const raw = scoringStorage().getItem(gameSnapKey(gameId));
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}
export function clearGameSnapshot(gameId: string): void {
  try { if (typeof window === "undefined") return; scoringStorage().removeItem(gameSnapKey(gameId)); } catch {}
}

// --- App boot cache (profile + groups + active group) for offline cold-launch ---
// Lets Home render the right group offline so the user can reach the game room.
const BOOT_KEY = "bnn_boot_cache_v1";
export function saveAppBootCache(data: { profile?: any; groups?: any[]; activeGroupId?: string | null }): void {
  try {
    if (typeof window === "undefined") return;
    const existing = loadAppBootCache() || {};
    scoringStorage().setItem(BOOT_KEY, JSON.stringify({ ...existing, ...data, at: Date.now() }));
  } catch {}
}
export function loadAppBootCache(): { profile?: any; groups?: any[]; activeGroupId?: string | null; at?: number } | null {
  try { if (typeof window === "undefined") return null; const raw = scoringStorage().getItem(BOOT_KEY); return raw ? JSON.parse(raw) : null; } catch { return null; }
}

// --- Last session identity (so a cold offline launch renders without a live token) ---
const SESS_KEY = "bnn_last_session_v1";
export function saveLastSession(user: any): void {
  try {
    if (typeof window === "undefined" || !user) return;
    scoringStorage().setItem(SESS_KEY, JSON.stringify({ user: { id: user.id, email: user.email, user_metadata: user.user_metadata }, at: Date.now() }));
  } catch {}
}
export function loadLastSession(): { user: any } | null {
  try { if (typeof window === "undefined") return null; const raw = scoringStorage().getItem(SESS_KEY); const p = raw ? JSON.parse(raw) : null; return p?.user ? { user: p.user } : null; } catch { return null; }
}

// True when the browser reports no connectivity. Best-effort signal only.
export function isOffline(): boolean {
  try { return typeof navigator !== "undefined" && navigator.onLine === false; } catch { return false; }
}

// --- Sync watermark + pending detection (offline outbox, Phase 2) ---
// The watermark is the arrays we've CONFIRMED landed on the server for a row.
// A row is "pending" when its local backup differs from its watermark. This is
// derived state (no separate outbox list to drift): dirty = backup !== watermark.
function wmKey(gameId: string, rowId: string) { return `bnn_game_wm_${gameId}_${rowId}`; }
export function saveSyncedWatermark(
  gameId: string,
  rowId: string,
  data: { scores: any[]; putts: any[]; fairways: any[]; penalties?: any[]; sand?: any[] },
): void {
  try {
    if (typeof window === "undefined") return;
    scoringStorage().setItem(wmKey(gameId, rowId), JSON.stringify({
      scores: data.scores || [], putts: data.putts || [], fairways: data.fairways || [],
      penalties: data.penalties || [], sand: data.sand || [],
    }));
  } catch {}
}
// Drop a single row's synced watermark — used when a reset invalidates a row so a
// stale "already synced" marker can't suppress re-pushing fresh post-reset scores.
export function clearSyncedWatermark(gameId: string, rowId: string): void {
  try {
    if (typeof window === "undefined") return;
    scoringStorage().removeItem(wmKey(gameId, rowId));
  } catch {}
}
export function loadSyncedWatermark(gameId: string, rowId: string): { scores: any[]; putts: any[]; fairways: any[]; penalties: any[]; sand: any[] } | null {
  try {
    if (typeof window === "undefined") return null;
    const raw = scoringStorage().getItem(wmKey(gameId, rowId));
    if (!raw) return null;
    const p = JSON.parse(raw);
    return { scores: p.scores || [], putts: p.putts || [], fairways: p.fairways || [], penalties: p.penalties || [], sand: p.sand || [] };
  } catch { return null; }
}

// Count holes whose local backup differs from the watermark (any tracked field).
// With no watermark yet, every entered hole counts as pending.
export function rowPendingHoles(
  backup: { scores: any[]; putts: any[]; fairways: any[]; penalties: any[]; sand: any[] } | null,
  wm: { scores: any[]; putts: any[]; fairways: any[]; penalties: any[]; sand: any[] } | null,
): number {
  if (!backup) return 0;
  const w = wm || { scores: [], putts: [], fairways: [], penalties: [], sand: [] };
  const n = Math.max(
    backup.scores?.length || 0, backup.putts?.length || 0, backup.fairways?.length || 0,
    backup.penalties?.length || 0, backup.sand?.length || 0,
    w.scores?.length || 0, w.putts?.length || 0, w.fairways?.length || 0,
    w.penalties?.length || 0, w.sand?.length || 0,
  );
  let c = 0;
  for (let i = 0; i < n; i++) {
    const diff =
      (backup.scores?.[i] ?? null) !== (w.scores?.[i] ?? null) ||
      (backup.putts?.[i] ?? null) !== (w.putts?.[i] ?? null) ||
      (backup.fairways?.[i] ?? null) !== (w.fairways?.[i] ?? null) ||
      (backup.penalties?.[i] ?? null) !== (w.penalties?.[i] ?? null) ||
      (backup.sand?.[i] ?? null) !== (w.sand?.[i] ?? null);
    // Deletions and stats-only edits also require server confirmation.
    if (diff) c++;
  }
  return c;
}

// clearAllLocalState (sign-out's sweep of every bnn_* key) was RETIRED in 212.130: it removed other identities' unsynced
// scores and the recovery archive, before the sign-out was known to have succeeded. Sign out goes through lib/sign-out
// (an awaited sign-out, then a cleanup scoped to that identity); ci/check_sign_out_contract.py keeps it there.

// A confirmed backup is a display cache, not unsynced work. Only actual edits may
// outrank a later server read on the same primary device.
export function personalRoundFingerprint(round: Round): string {
  return JSON.stringify([round.played_at?.slice(0,10), round.rating, round.slope,
    round.course_handicap, round.course_handicap_source,
    round.holes.map(h => [h.hole_number,h.strokes,h.putts,h.fairway,h.penalties ?? 0,h.sand ?? false])]);
}
export function savePersonalRoundAck(round: Round): void {
  scoringStorage().setItem("bnn_round_sync_v1", JSON.stringify({ id: round.id || round.draft_session_id, signature: personalRoundFingerprint(round) }));
}
export function personalDraftIsPending(round: Round): boolean {
  try {
    const ack = JSON.parse(scoringStorage().getItem("bnn_round_sync_v1") || "null");
    return ack?.id !== (round.id || round.draft_session_id) || ack.signature !== personalRoundFingerprint(round);
  } catch { return true; }
}

/**
 * Should opening the app return to the game room the member was last in? (210.11, owner: "go to an unfinished game
 * if still in progress, but not all the time") Only while that game is still being played. `serverStatus` is the
 * game's status from the server (undefined = couldn't ask, e.g. offline; null = the game no longer exists);
 * `snapshotStatus` is this phone's saved copy, used only when the server couldn't be asked.
 */
export function shouldResumeGame(serverStatus: string | null | undefined, snapshotStatus: string | null | undefined): boolean {
  if (serverStatus === null) return false;                       // the game no longer exists
  const status = serverStatus !== undefined ? serverStatus : snapshotStatus;
  return status !== "ended";                                     // active (or unknown offline) → resume; ended → don't
}


// 212.28 — a game's score backups stayed on the phone forever (cleared only by a course change, match-length change,
// reset or delete — never when the game ended): one backup and one confirmed copy per player per game scored. The
// storage tidy removes a pair once it is FULLY SYNCED (nothing pending) and over 30 days old; anything not yet
// uploaded is never touched.
const SYNCED_BACKUP_DAYS = 30;
export function tidySyncedGameBackups(): number {
  if (typeof window === "undefined") return 0;
  const st = scoringStorage();
  const cutoff = Date.now() - SYNCED_BACKUP_DAYS * 86400000;
  const keys = Array.from({ length: st.length }, (_, i) => st.key(i)).filter((k): k is string => !!k && k.startsWith("bnn_game_scores_"));
  let removed = 0;
  for (const k of keys) {
    try {
      const b = JSON.parse(st.getItem(k) || "null");
      if (!b || typeof b.at !== "number" || b.at >= cutoff) continue;
      const wk = "bnn_game_wm_" + k.slice("bnn_game_scores_".length);
      const wmRaw = st.getItem(wk);
      const wm = wmRaw ? JSON.parse(wmRaw) : null;
      if (!wm || rowPendingHoles(b, wm) !== 0) continue;   // unsynced work stays
      st.removeItem(k); st.removeItem(wk); removed += 2;
    } catch { /* leave it */ }
  }
  return removed;
}
registerStorageTidy(tidySyncedGameBackups);

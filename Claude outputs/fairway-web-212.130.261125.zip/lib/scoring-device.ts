"use client";

// One runtime token per tab. Resume rotates the previous token, fencing duplicate tabs.
// A known primary can work offline; the server always decides whether its writes land.
export type DeviceState = "checking" | "primary" | "viewer";
let deviceError = "";
export const scoringDeviceError = () => deviceError;
function setDeviceError(message: string) { deviceError = message; listeners.forEach(f => f()); }
let state: DeviceState = "checking";
let token = "";
let userId = "";
let previous: string | null = null;
let initialized = false;
let request: Promise<void> | null = null;
const listeners = new Set<() => void>();
const OWNER_KEY = "bnn_primary_scoring_owner_v1";
const ARCHIVE_KEY = "bnn_scoring_recovery_v1";
// 212.130: named for lib/sign-out, which must keep the archive and other identities' outboxes when clearing local state.
export const SCORING_OWNER_KEY = OWNER_KEY, SCORING_ARCHIVE_KEY = ARCHIVE_KEY;
export const subscribeScoringDevice = (listener: () => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; };
export const scoringDeviceState = () => state;
export const scoringDeviceToken = () => token;
export const isPrimaryScoringDevice = () => state === "primary";
function publish(next: DeviceState) { state = next; listeners.forEach(f => f()); }
function owner(): { user: string; token: string } | null {
  try { return JSON.parse(window.localStorage.getItem(OWNER_KEY) || "null"); } catch { return null; }
}
export function markScoringDeviceRevoked() { publish("viewer"); }
export function isDeviceRejection(error: { message?: string } | null | undefined) {
  return !!error?.message?.includes("Scoring is active on another device");
}
function scoreKey(key: string) {
  return key === "bnn_round_draft_v1" || key === "bnn_round_sync_v1" || key === "bnn_draft_hole_v1" ||
    key.startsWith("bnn_edit_round:") || key.startsWith("bnn_game_scores_") || key.startsWith("bnn_game_wm_") ||
    key.startsWith("bnn:altshot-side-drafts:");
}
const PREFIX = "bnn_device_scores:";
function pendingKey(key: string) { return scoreKey(key) ? `${PREFIX}${userId}:${token}:${key}` : key; }
// Pending work is isolated by runtime token. An old tab cannot contaminate the new
// primary tab's outbox through shared localStorage. Snapshots/preferences remain shared.
export function scoringStorage(): Storage {
  const storage = window.localStorage;
  const keys = () => Array.from({ length: storage.length }, (_, i) => storage.key(i)!).filter(k =>
    !k.startsWith(PREFIX) || k.startsWith(`${PREFIX}${userId}:${token}:`)).map(k => k.startsWith(PREFIX) ? k.slice(`${PREFIX}${userId}:${token}:`.length) : k);
  return {
    get length() { return keys().length; },
    key: i => keys()[i] ?? null,
    getItem: key => storage.getItem(pendingKey(key)),
    setItem: (key, value) => storage.setItem(pendingKey(key), value),
    removeItem: key => storage.removeItem(pendingKey(key)),
    clear: () => keys().forEach(key => storage.removeItem(pendingKey(key))),
  };
}
function resumeBackups(oldToken: string | null) {
  if (!oldToken || oldToken === token) return;
  const storage = window.localStorage, oldPrefix = `${PREFIX}${userId}:${oldToken}:`;
  const keys = Array.from({ length: storage.length }, (_, i) => storage.key(i)!).filter(k => k.startsWith(oldPrefix));
  // 212.29b: MOVE, not copy — the copy was kept under the old token, so every relaunch of the home-screen app
  // duplicated every backup (owner, Oct 23: 8.7 MB of score backups on a staging phone). The old token is this same
  // installation's previous session (the server accepted the resume); its work now lives under the new token.
  for (const key of keys) {
    storage.setItem(`${PREFIX}${userId}:${token}:${key.slice(oldPrefix.length)}`, storage.getItem(key)!);
    storage.removeItem(key);
  }
}
export function archiveScoringBackups(clear = false, uid: string = userId) {
  // Saving the archive must succeed before removing any working backup. `uid` (212.130): sign-out archives the
  // signed-out member's outbox even on a screen where the scoring-device check never ran (the paused-account page).
  const storage = window.localStorage, data: Record<string, string> = {};
  for (let i = 0; i < storage.length; i++) {
    const key = storage.key(i)!;
    if (scoreKey(key) || key.startsWith(`${PREFIX}${uid}:`)) data[key] = storage.getItem(key)!;
  }
  if (Object.keys(data).length) {
    const archives = trimArchives(JSON.parse(storage.getItem(ARCHIVE_KEY) || "[]"));
    archives.push({ user: uid, at: new Date().toISOString(), data });
    storage.setItem(ARCHIVE_KEY, JSON.stringify(trimArchives(archives)));
    if (clear) Object.keys(data).filter(k => !k.startsWith(PREFIX) || k.startsWith(`${PREFIX}${userId}:${token}:`)).forEach(k => storage.removeItem(k));
    // 212.26: other identities' backups are NOT removed here — another tab or a phone that scored offline may resume
    // them (ci/test-scoring-device). The runaway growth was the archive itself, now capped (trimArchives).
  }
}
export function downloadScoringRecovery() {
  archiveScoringBackups();
  const blob = new Blob([window.localStorage.getItem(ARCHIVE_KEY) || "[]"], { type: "application/json" });
  const url = URL.createObjectURL(blob), a = document.createElement("a");
  a.href = url; a.download = "BNN-saved-scores.json"; a.click(); URL.revokeObjectURL(url);
}
// Same-browser liveness. Two tabs of one browser share localStorage, so the owner token alone
// cannot tell "the app was relaunched" from "a second tab was opened". A primary tab answers pings
// on a per-user channel; a tab that gets an answer carrying the owner's token is a duplicate.
const CHANNEL = (uid: string) => `bnn_scoring_device_${uid}`;
let siblings: BroadcastChannel | null = null;
function listenForSiblings(uid: string) {
  if (typeof BroadcastChannel === "undefined") return;
  siblings?.close();
  siblings = new BroadcastChannel(CHANNEL(uid));
  (siblings as unknown as { unref?: () => void }).unref?.();
  siblings.onmessage = (e: MessageEvent) => {
    if (e.data?.type === "ping" && state === "primary") siblings?.postMessage({ type: "alive", token });
  };
}
function liveSiblingTab(uid: string, ownerToken: string): Promise<boolean> {
  if (typeof BroadcastChannel === "undefined") return Promise.resolve(false);
  return new Promise((resolve) => {
    const ch = new BroadcastChannel(CHANNEL(uid));
    (ch as unknown as { unref?: () => void }).unref?.();
    const done = (alive: boolean) => { clearTimeout(timer); ch.close(); resolve(alive); };
    const timer = setTimeout(() => done(false), 250);
    ch.onmessage = (e: MessageEvent) => { if (e.data?.type === "alive" && e.data.token === ownerToken) done(true); };
    ch.postMessage({ type: "ping" });
  });
}
// Test and teardown hook: a runtime that will no longer answer pings (the tab is closing).
export function releaseScoringDeviceRuntime() { siblings?.close(); siblings = null; }
type Client = { rpc: (name: string, args: Record<string, unknown>) => PromiseLike<{ data: any; error: any }> };
export async function checkScoringDevice(client: Client, uid: string, takeover = false): Promise<void> {
  if (!uid || typeof window === "undefined") return;
  if (request) { await request; if (!takeover) return; }
  if (userId !== uid) {
    userId = uid; initialized = false; publish("checking");
    try { previous = window.sessionStorage.getItem(`bnn_primary_tab_${uid}`); } catch { previous = null; }
    // A fully closed mobile app loses sessionStorage (iOS discards it for a standalone PWA on
    // every cold launch). The installation's identity survives in localStorage: the token of its
    // last successful claim. Present that as the previous token ONLINE as well as offline, so the
    // same phone reopening resumes silently instead of asking "make this device primary?" on
    // every launch. The server still decides: it resumes only if that token is the one it holds,
    // so a different device - whose localStorage holds a different or no token - still sees the
    // prompt. Before 193.3 this was offline-only and every relaunch presented as a second device.
    // ...unless the previous runtime is still ALIVE in another tab of this same browser. Then this
    // is a duplicate tab, not a relaunch: it stays a viewer and the open tab keeps scoring. A live
    // tab answers a BroadcastChannel ping within 250ms; a killed app cannot.
    if (!previous && owner()?.user === uid && !(await liveSiblingTab(uid, owner()!.token))) previous = owner()!.token;
    listenForSiblings(uid);
    token = navigator.onLine === false && previous ? previous : crypto.randomUUID();
  }
  if (navigator.onLine === false) {
    if (!initialized && previous && owner()?.user === uid && owner()?.token === token) publish("primary");
    return;
  }
  if (!initialized && token === previous) token = crypto.randomUUID();
  request = (async () => {
    try {
      const resumeToken = takeover && owner()?.user === uid ? owner()!.token : previous;
      const { data, error } = await client.rpc("claim_scoring_device", {
        p_token: token, p_previous: takeover ? resumeToken : initialized ? null : previous, p_takeover: takeover,
      });
      if (error || !data) { setDeviceError("Could not confirm your primary device. Your saved scores are still available; reconnect and try again."); return; } // Never interpret a failed read as a transfer.
      setDeviceError("");
      const wasInitialized = initialized;
      initialized = true;
      if (!data.active) { publish("viewer"); return; }
      const oldOwner = owner();
      // The server superseded a holder that had been silent for its idle window (0166). This device
      // did not resume anything; it starts from the server's scores like a takeover, so any outbox
      // it kept from an earlier session is archived, never replayed.
      const superseded = data.superseded === true;
      if (!wasInitialized && !takeover && !superseded) resumeBackups(previous);
      // A successful takeover starts from the current server scores. Old pending work
      // remains downloadable, but can never become an automatic stale outbox.
      if (takeover || superseded || (!previous && !wasInitialized) || (oldOwner?.user === uid && oldOwner.token !== token && oldOwner.token !== previous)) archiveScoringBackups(true);
      // Explicitly resuming this same installation's still-current server token
      // recovers its own pending mobile work. A transfer from a different device
      // never replays the old local outbox.
      if (takeover && data.resumed === true) resumeBackups(resumeToken);
      window.sessionStorage.setItem(`bnn_primary_tab_${uid}`, token);
      window.localStorage.setItem(OWNER_KEY, JSON.stringify({ user: uid, token }));
      try { tidyScoringStorage(); } catch { /* best effort */ }   // 212.26
      publish("primary");
      if (takeover) window.location.reload();
    } catch { setDeviceError("Could not change or restore this scoring device. Saved scores were retained; reconnect and try again."); }
  })();
  try { await request; } finally { request = null; }
}


// ── 212.26 — keep the site's storage from filling (owner, Oct 23: on staging every score backup failed silently once
// it was full, and entered scores vanished). The recovery archive keeps its 3 newest entries from the last 30 days;
// game snapshots not opened for 30 days go; another identity's backup goes only when over 30 days old (it may be a
// phone's offline work waiting to resume — never removed while recent).
const ARCHIVE_KEEP = 3, ARCHIVE_DAYS = 30, SNAPSHOT_DAYS = 30;
type ArchiveEntry = { at?: string; user?: string; data?: Record<string, string | null> };
function trimArchives(list: ArchiveEntry[]): ArchiveEntry[] {
  const cutoff = Date.now() - ARCHIVE_DAYS * 86400000;
  return (Array.isArray(list) ? list : []).filter((a) => !a.at || Date.parse(a.at) >= cutoff).slice(-ARCHIVE_KEEP);
}
/** Tidy the site's storage; returns how many entries were removed. Safe to call any time. */
export function tidyScoringStorage(): number {
  if (typeof window === "undefined") return 0;
  const storage = window.localStorage;
  let removed = 0;
  try {
    const raw = storage.getItem(ARCHIVE_KEY);
    if (raw) { const before = JSON.parse(raw); const after = trimArchives(before); if (after.length !== before.length) { storage.setItem(ARCHIVE_KEY, JSON.stringify(after)); removed += before.length - after.length; } }
  } catch { try { storage.removeItem(ARCHIVE_KEY); removed++; } catch {} }
  const cutoff = Date.now() - SNAPSHOT_DAYS * 86400000;
  const keys = Array.from({ length: storage.length }, (_, i) => storage.key(i)).filter((k): k is string => !!k);
  for (const k of keys) {
    try {
      if (k.startsWith("bnn_game_snap_")) {
        const at = JSON.parse(storage.getItem(k) || "{}")?.at;
        if (!at || at < cutoff) { storage.removeItem(k); removed++; }
      } else if (k.startsWith(PREFIX) && token && userId && k.startsWith(`${PREFIX}${userId}:`) && !k.includes(`:${token}:`)) {
        // another identity's backup. 212.29b: (1) an exact duplicate of the current identity's copy goes, whatever its
        // age (resume used to copy, never move); (2) a FULLY UPLOADED game backup (its own confirmed copy matches)
        // goes after 2 days; (3) otherwise kept — it may be live pending work — unless over 30 days old.
        const rest = k.slice(`${PREFIX}${userId}:`.length);
        const sub = rest.slice(rest.indexOf(":") + 1);   // the key within that identity
        const mine = storage.getItem(`${PREFIX}${userId}:${token}:${sub}`);
        const val = storage.getItem(k);
        if (mine != null && mine === val) { storage.removeItem(k); removed++; continue; }
        const parsed = (() => { try { return JSON.parse(val || "null"); } catch { return null; } })();
        const at = parsed?.at;
        if (sub.startsWith("bnn_game_scores_") && typeof at === "number" && at < Date.now() - 2 * 86400000) {
          const tokenPart = rest.slice(0, rest.indexOf(":"));
          const wmRaw = storage.getItem(`${PREFIX}${userId}:${tokenPart}:bnn_game_wm_${sub.slice("bnn_game_scores_".length)}`);
          const wm = (() => { try { return JSON.parse(wmRaw || "null"); } catch { return null; } })();
          const same = (a: unknown[] | undefined, b: unknown[] | undefined) => JSON.stringify(a || []) === JSON.stringify(b || []);
          if (wm && ["scores", "putts", "fairways", "penalties", "sand"].every((c) => same(parsed?.[c], wm?.[c]))) {
            storage.removeItem(k); storage.removeItem(`${PREFIX}${userId}:${tokenPart}:bnn_game_wm_${sub.slice("bnn_game_scores_".length)}`); removed += 2; continue;
          }
        }
        if (typeof at === "number" && at < cutoff) { storage.removeItem(k); removed++; }
      }
    } catch { /* leave it */ }
  }
  removed += runStorageTidyHooks();   // 212.28: e.g. synced game backups over 30 days old (lib/draft)
  return removed;
}

// 212.28: one place to note that a backup could not be written even after tidying (score backups, team-score
// drafts) — the scorecard shows a warning at the top; the score is still sent.
let storageFailed = false;
export const storageWriteFailed = () => storageFailed;
export function noteStorageWriteFailure() { storageFailed = true; listeners.forEach((f) => f()); }
// Extra tidy steps registered by modules that own their keys (lib/draft: synced game backups) — avoids an import cycle.
const tidyHooks: (() => number)[] = [];
export function registerStorageTidy(fn: () => number) { tidyHooks.push(fn); }
export function runStorageTidyHooks(): number { return tidyHooks.reduce((n, f) => { try { return n + f(); } catch { return n; } }, 0); }

/** Test hook only — set the settled identity the storage tidy measures "another identity" against. */
export function __setScoringIdentityForTest(uid: string, tok: string) { userId = uid; token = tok; }
